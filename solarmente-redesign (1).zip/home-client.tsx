"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import FacturasModal from "./components/FacturasModal"
import {
  Zap,
  BarChart3,
  Shield,
  ArrowRight,
  CheckCircle2,
  Clock,
  ChevronDown,
  Network,
  Sun,
  Cpu,
  LineChart,
  Lightbulb,
  DollarSign,
  Home,
  CalendarDays,
} from "lucide-react"

// Nuevo componente de animación solar
const SolarAnimation = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Líneas horizontales flotantes */}
      {[...Array(6)].map((_, i) => (
        <div
          key={`h-line-${i}`}
          className="solar-line"
          style={{
            top: `${15 + i * 15}%`,
            animation: `floatHorizontal ${25 + i * 5}s ease-in-out infinite ${i * 2}s`,
          }}
        />
      ))}

      {/* Líneas verticales flotantes */}
      {[...Array(6)].map((_, i) => (
        <div
          key={`v-line-${i}`}
          className="solar-line-vertical"
          style={{
            left: `${15 + i * 15}%`,
            animation: `floatVertical ${25 + i * 5}s ease-in-out infinite ${i * 2}s`,
          }}
        />
      ))}

      {/* Círculos solares */}
      {[...Array(12)].map((_, i) => {
        const size = 40 + Math.random() * 80
        return (
          <div
            key={`sun-${i}`}
            className="solar-circle"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${Math.random() * 90}%`,
              top: `${Math.random() * 90}%`,
              opacity: 0.1 + Math.random() * 0.3,
              animation: `pulseSun ${8 + Math.random() * 7}s infinite ease-in-out ${Math.random() * 5}s`,
            }}
          />
        )
      })}

      {/* Rayos solares */}
      {[...Array(8)].map((_, i) => {
        const angle = (i * 45) % 360
        return (
          <div
            key={`ray-${i}`}
            className="solar-ray"
            style={{
              width: "1px",
              height: "100px",
              left: "50%",
              top: "50%",
              transform: `translateX(-50%) translateY(-50%) rotate(${angle}deg)`,
              animation: `rotateSun 60s linear infinite, fadeInOut ${10 + Math.random() * 5}s infinite ease-in-out`,
            }}
          />
        )
      })}

      {/* Círculos solares grandes con efecto de logo */}
      {[...Array(3)].map((_, i) => {
        const size = 150 + Math.random() * 100
        return (
          <div
            key={`logo-sun-${i}`}
            className="solar-circle"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${20 + Math.random() * 60}%`,
              top: `${20 + Math.random() * 60}%`,
              opacity: 0.05 + Math.random() * 0.1,
              animation: `pulseSun ${15 + Math.random() * 10}s infinite ease-in-out ${Math.random() * 5}s`,
            }}
          >
            {/* Rayos del logo */}
            {[...Array(8)].map((_, j) => {
              const rayAngle = (j * 45) % 360
              const raySize = size * 0.4
              return (
                <div
                  key={`logo-ray-${i}-${j}`}
                  className="absolute"
                  style={{
                    width: "2px",
                    height: `${raySize}px`,
                    left: "50%",
                    top: "50%",
                    background: "rgba(255, 106, 0, 0.2)",
                    transform: `translateX(-50%) translateY(-50%) rotate(${rayAngle}deg)`,
                    transformOrigin: "center",
                  }}
                />
              )
            })}
          </div>
        )
      })}
    </div>
  )
}

// Definición de interfaces para tipos
interface FacturasModalProps {
  isOpen: boolean
  closeModal: () => void
  projectId: string | null
}

export default function HomeClient() {
  const router = useRouter()
  const [scrollY, setScrollY] = useState(0)
  const [demoStep, setDemoStep] = useState(1)
  const [count, setCount] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [currentProject, setCurrentProject] = useState<string | null>(null)
  const targetCount = 180 // Número de instalaciones
  const mainRef = useRef<HTMLDivElement>(null)
  const heroRef = useRef<HTMLDivElement>(null)

  // Valores para la animación de inyección cero
  const [powerValues, setPowerValues] = useState({
    pv: 5.4,
    load: 5.5,
    grid: 0.1,
  })

  // Animación de partículas
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Función openModal con useCallback para evitar recreaciones innecesarias
  const openModal = useCallback((projectId: string) => {
    // Guardar posición actual del scroll antes de abrir el modal
    const scrollPosition = window.scrollY

    // Añadir clase para bloquear scroll
    document.body.classList.add("modal-open")
    document.body.setAttribute("data-scroll", scrollPosition.toString())

    // Actualizar estado
    setCurrentProject(projectId)
    setModalOpen(true)
  }, [])

  // Función closeModal con useCallback
  const closeModal = useCallback(() => {
    // Restaurar scroll cuando se cierra el modal
    const scrollPosition = Number.parseInt(document.body.getAttribute("data-scroll") || "0")
    document.body.classList.remove("modal-open")
    window.scrollTo(0, scrollPosition)

    // Actualizar estado
    setModalOpen(false)
  }, [])

  // Funciones específicas para los manejadores de eventos de cada proyecto
  const handleOpenDsvModal = useCallback(() => {
    openModal("dsv")
  }, [openModal])

  // Inicializar animación de partículas
  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Ajustar tamaño del canvas
    const resizeCanvas = () => {
      if (heroRef.current) {
        canvas.width = heroRef.current.offsetWidth
        canvas.height = heroRef.current.offsetHeight
      }
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Crear partículas
    const particles: Particle[] = []
    const particleCount = 100

    interface Particle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string
      opacity: number
      life: number
      maxLife: number
    }

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        color: `hsl(${Math.random() * 30 + 20}, 100%, 50%)`,
        opacity: Math.random() * 0.3 + 0.1,
        life: 0,
        maxLife: Math.random() * 100 + 50,
      })
    }

    // Animar partículas
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Actualizar y dibujar partículas
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i]

        p.life++
        if (p.life >= p.maxLife) {
          // Reiniciar partícula
          p.x = Math.random() * canvas.width
          p.y = Math.random() * canvas.height
          p.life = 0
          p.opacity = Math.random() * 0.3 + 0.1
        }

        p.x += p.speedX
        p.y += p.speedY

        // Mantener partículas dentro del canvas
        if (p.x < 0 || p.x > canvas.width) p.speedX *= -1
        if (p.y < 0 || p.y > canvas.height) p.speedY *= -1

        // Dibujar partícula
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = p.color
        ctx.globalAlpha = p.opacity * (1 - p.life / p.maxLife)
        ctx.fill()
        ctx.globalAlpha = 1
      }

      // Dibujar conexiones entre partículas cercanas
      ctx.strokeStyle = "rgba(255, 120, 0, 0.1)"
      ctx.lineWidth = 0.3
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 100) {
            ctx.beginPath()
            ctx.moveTo(particles[i].x, particles[i].y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.globalAlpha = 0.1 * (1 - distance / 100)
            ctx.stroke()
            ctx.globalAlpha = 1
          }
        }
      }

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  useEffect(() => {
    // Efecto para la animación inicial
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 500)

    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)

    // Iniciar contador cuando estamos en la vista correcta
    const counterInterval = setInterval(() => {
      setCount((prev) => {
        const increment = Math.ceil(targetCount / 30)
        const newValue = prev + increment
        if (newValue >= targetCount) {
          clearInterval(counterInterval)
          return targetCount
        }
        return newValue
      })
    }, 80)

    // Actualizar los valores de energía para la animación de inyección cero
    const powerUpdateInterval = setInterval(() => {
      // Generar valores aleatorios dentro de rangos específicos
      // PV: Entre 5.2 y 5.6 kW
      const pvValue = Number((5.2 + Math.random() * 0.4).toFixed(1))

      // Load: Entre 5.3 y 5.7 kW
      const loadValue = Number((5.3 + Math.random() * 0.4).toFixed(1))

      // Grid siempre será la diferencia (asegurando inyección cero)
      const gridValue = Number(Math.abs(loadValue - pvValue).toFixed(1))

      setPowerValues({
        pv: pvValue,
        load: loadValue,
        grid: gridValue,
      })
    }, 2000)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      clearTimeout(timer)
      clearInterval(counterInterval)
      clearInterval(powerUpdateInterval)
    }
  }, [])

  // Función para dar formato al número con comas para miles
  const formatNumber = (num: number): string => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  }

  return (
    <div ref={mainRef} className="overflow-x-hidden bg-white text-gray-800 font-[Mulish,sans-serif]">
      {/* Hero Section con fondo futurista */}
      <div ref={heroRef} className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
        {/* Canvas para animación de partículas */}
        <canvas ref={canvasRef} className="absolute inset-0 z-0"></canvas>

        {/* Animación solar */}
        <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
          <SolarAnimation />
        </div>

        {/* Fondo con grid pattern futurista */}
        <div className="absolute inset-0 bg-white">
          {/* Grid Pattern - Estilo futurista */}
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `
              radial-gradient(circle at 50% 50%, rgba(255, 100, 0, 0.03) 0%, transparent 25%),
              linear-gradient(0deg, rgba(230, 230, 240, 0.5) 1px, transparent 1px), 
              linear-gradient(90deg, rgba(230, 230, 240, 0.5) 1px, transparent 1px)
            `,
              backgroundSize: "100% 100%, 40px 40px, 40px 40px",
              backgroundPosition: "0 0, 0 0, 0 0",
              opacity: 0.7,
            }}
          ></div>

          {/* Efecto de luz solar */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#ff6a0010] via-transparent to-transparent opacity-30"></div>

          {/* Efecto de holograma */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#ff6a0010] via-transparent to-[#ff6a0010] animate-pulse-slow opacity-20"></div>
        </div>

        <div
          className={`relative z-10 container mx-auto px-4 transition-all duration-1000 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-10"}`}
        >
          <div className="text-center max-w-4xl mx-auto hero-content">
            <div className="mb-6 inline-block bg-white/80 backdrop-blur-md px-4 py-1 rounded-full border border-[#ff6a00]/20">
              <span className="text-sm text-gray-700 flex items-center justify-center gap-2">
                <span className="w-2 h-2 bg-[#ff6a00] rounded-full animate-pulse"></span>
                Primera empresa solar en Panamá con IA
              </span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-bold mb-2 tracking-tight text-gray-900">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h1>

            {/* Logo con texto "Por:" */}
            <div className="flex items-center justify-center mb-6">
              <span className="text-gray-500 mr-2">Por:</span>
              <div className="h-12 w-auto relative">
                <img
                  src="/images/logo.png"
                  alt="Logo SolarMente"
                  className="h-full object-contain"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement
                    target.onerror = null
                    target.src = "/placeholder.svg?height=48&width=120"
                  }}
                />
              </div>
            </div>

            <h2 className="text-xl sm:text-2xl mb-6 font-light text-gray-700">
              Cambiando la forma de{" "}
              <span className="relative">
                <span className="relative z-10 text-[#ff6a00] font-medium">cotizar, comprar e instalar</span>
                <span className="absolute bottom-0 left-1 h-2 w-full bg-[#ff6a00]/20 z-0"></span>
              </span>{" "}
              paneles solares
            </h2>

            <p className="text-gray-600 mb-10 max-w-2xl mx-auto">
              Ahorra hasta un 100% en tu factura eléctrica con energía limpia y renovable.
              <span className="block mt-2">Obtén propuestas personalizadas en tiempo real generadas por IA.</span>
            </p>

            <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-16">
              <Link
                href="/propuesta"
                className="group flex-1 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] py-4 px-6 text-white font-bold rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center gap-2 relative overflow-hidden"
              >
                <span className="relative z-10">Cotizador IA</span>
                <Zap className="relative z-10" />
                <div className="absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              </Link>

              <Link
                href="/proyectos"
                className="flex-1 bg-transparent hover:bg-gray-100 text-gray-800 font-bold py-4 px-6 border-2 border-gray-300 hover:border-[#ff6a00]/70 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 group relative overflow-hidden"
              >
                <span className="relative z-10">Ver Proyectos</span>
                <ArrowRight className="relative z-10 transform group-hover:translate-x-1 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-r from-[#ff6a00]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Link>
            </div>
          </div>

          {/* Stats flotantes con diseño futurista - Versión mejorada e interactiva */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {/* Card 1 - Propuesta IA */}
            <div className="stat-card bg-white/80 backdrop-blur-lg border border-gray-200 rounded-xl p-5 text-center transform hover:scale-105 transition-all duration-500 hover:shadow-lg hover:shadow-[#ff6a00]/20 group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* Efecto de partículas */}
              <div className="absolute inset-0 overflow-hidden">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={`particle-1-${i}`}
                    className="absolute w-1 h-1 rounded-full bg-[#ff6a00]"
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      opacity: 0.3 + Math.random() * 0.4,
                      animation: `floatParticle ${5 + Math.random() * 5}s linear infinite ${Math.random() * 5}s`,
                    }}
                  ></div>
                ))}
              </div>

              {/* Icono animado */}
              <div className="mb-2 flex justify-center">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#ff6a00] to-[#ff9500] flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-500">
                  <Zap className="h-5 w-5 text-white" />
                </div>
              </div>

              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 relative z-10 group-hover:text-[#ff6a00] transition-colors duration-300">
                30s
              </h3>
              <p className="text-xs md:text-sm text-gray-500 relative z-10">Propuesta IA</p>

              {/* Efecto de brillo en hover */}
              <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-[#ff6a00]/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
            </div>

            {/* Card 2 - Ahorro Posible */}
            <div className="stat-card bg-white/80 backdrop-blur-lg border border-gray-200 rounded-xl p-5 text-center transform hover:scale-105 transition-all duration-500 hover:shadow-lg hover:shadow-[#ff6a00]/20 group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* Efecto de contador */}
              <div className="absolute inset-0 overflow-hidden">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={`particle-2-${i}`}
                    className="absolute w-1 h-1 rounded-full bg-[#ff6a00]"
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      opacity: 0.3 + Math.random() * 0.4,
                      animation: `floatParticle ${5 + Math.random() * 5}s linear infinite ${Math.random() * 5}s`,
                    }}
                  ></div>
                ))}
              </div>

              {/* Icono animado */}
              <div className="mb-2 flex justify-center">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#ff6a00] to-[#ff9500] flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-500">
                  <DollarSign className="h-5 w-5 text-white" />
                </div>
              </div>

              <div className="relative z-10">
                <h3 className="text-2xl md:text-3xl font-bold text-gray-900 group-hover:text-[#ff6a00] transition-colors duration-300 flex items-center justify-center">
                  <span className="counter-animation">100</span>
                  <span>%</span>
                </h3>
              </div>
              <p className="text-xs md:text-sm text-gray-500 relative z-10">Ahorro Posible</p>

              {/* Efecto de brillo en hover */}
              <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-[#ff6a00]/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
            </div>

            {/* Card 3 - Instalaciones */}
            <div className="stat-card bg-white/80 backdrop-blur-lg border border-gray-200 rounded-xl p-5 text-center transform hover:scale-105 transition-all duration-500 hover:shadow-lg hover:shadow-[#ff6a00]/20 group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* Efecto de partículas */}
              <div className="absolute inset-0 overflow-hidden">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={`particle-3-${i}`}
                    className="absolute w-1 h-1 rounded-full bg-[#ff6a00]"
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      opacity: 0.3 + Math.random() * 0.4,
                      animation: `floatParticle ${5 + Math.random() * 5}s linear infinite ${Math.random() * 5}s`,
                    }}
                  ></div>
                ))}
              </div>

              {/* Icono animado */}
              <div className="mb-2 flex justify-center">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#ff6a00] to-[#ff9500] flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-500">
                  <Home className="h-5 w-5 text-white" />
                </div>
              </div>

              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 relative z-10 group-hover:text-[#ff6a00] transition-colors duration-300">
                {formatNumber(count)}+
              </h3>
              <p className="text-xs md:text-sm text-gray-500 relative z-10">Instalaciones</p>

              {/* Efecto de brillo en hover */}
              <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-[#ff6a00]/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
            </div>

            {/* Card 4 - Años Experiencia */}
            <div className="stat-card bg-white/80 backdrop-blur-lg border border-gray-200 rounded-xl p-5 text-center transform hover:scale-105 transition-all duration-500 hover:shadow-lg hover:shadow-[#ff6a00]/20 group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* Efecto de partículas */}
              <div className="absolute inset-0 overflow-hidden">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={`particle-4-${i}`}
                    className="absolute w-1 h-1 rounded-full bg-[#ff6a00]"
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      opacity: 0.3 + Math.random() * 0.4,
                      animation: `floatParticle ${5 + Math.random() * 5}s linear infinite ${Math.random() * 5}s`,
                    }}
                  ></div>
                ))}
              </div>

              {/* Icono animado */}
              <div className="mb-2 flex justify-center">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#ff6a00] to-[#ff9500] flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-500">
                  <CalendarDays className="h-5 w-5 text-white" />
                </div>
              </div>

              <div className="relative z-10">
                <h3 className="text-2xl md:text-3xl font-bold text-gray-900 group-hover:text-[#ff6a00] transition-colors duration-300 flex items-center justify-center">
                  <span className="counter-animation">12</span>
                </h3>
              </div>
              <p className="text-xs md:text-sm text-gray-500 relative z-10">Años Experiencia</p>

              {/* Efecto de brillo en hover */}
              <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-[#ff6a00]/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-bounce">
          <div className="w-10 h-10 flex items-center justify-center text-gray-500 bg-white/80 backdrop-blur-md rounded-full border border-gray-200">
            <ChevronDown className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Sección de Ahorro Garantizado con estilos futuristas */}
      <section className="py-20 bg-gray-50 border-t border-gray-200 relative overflow-hidden">
        {/* Fondo con elementos futuristas */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-[#ff6a00]/5 to-transparent opacity-30"></div>
          <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-gradient-to-b from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-gradient-to-t from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col items-center mb-12">
            <span className="bg-white/80 text-[#ff6a00] text-sm px-4 py-1 rounded-full border border-gray-200">
              BENEFICIOS
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-center mt-4 mb-2 relative text-gray-900">
              <span>AHORRO</span> <span className="text-[#ff6a00]">GARANTIZADO</span>
              <span className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-gradient-to-r from-[#ff6a00] to-[#ff9500]"></span>
            </h2>

            <p className="text-center text-gray-600 max-w-2xl mt-6">
              Instala energía solar en tu hogar o negocio y comienza a ahorrar desde el primer día con tecnología
              inteligente que optimiza tu consumo.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="group bg-white/80 backdrop-blur-md rounded-xl shadow-lg p-6 h-full transform transition-all duration-500 hover:scale-105 hover:shadow-xl border border-gray-200 hover:border-[#ff6a00]/30 flex flex-col relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="w-16 h-16 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-lg flex items-center justify-center mb-6 transform group-hover:rotate-6 transition-transform duration-500 relative z-10">
                <Sun className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900 relative z-10">Hasta 100% de Ahorro</h3>
              <p className="text-gray-600 relative z-10">
                Reduce drásticamente o elimina por completo tu factura eléctrica con nuestros sistemas solares
                personalizados por IA.
              </p>
            </div>

            <div className="group bg-white/80 backdrop-blur-md rounded-xl shadow-lg p-6 h-full transform transition-all duration-500 hover:scale-105 hover:shadow-xl border border-gray-200 hover:border-[#ff6a00]/30 flex flex-col relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="w-16 h-16 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-lg flex items-center justify-center mb-6 transform group-hover:rotate-6 transition-transform duration-500 relative z-10">
                <LineChart className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900 relative z-10">Retorno de Inversión Rápido</h3>
              <p className="text-gray-600 relative z-10">
                Recupera tu inversión en 2-3 años mientras disfrutas de energía gratuita por décadas. Monitorea en
                tiempo real.
              </p>
            </div>

            <div className="group bg-white/80 backdrop-blur-md rounded-xl shadow-lg p-6 h-full transform transition-all duration-500 hover:scale-105 hover:shadow-xl border border-gray-200 hover:border-[#ff6a00]/30 flex flex-col relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="w-16 h-16 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-lg flex items-center justify-center mb-6 transform group-hover:rotate-6 transition-transform duration-500 relative z-10">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900 relative z-10">Garantía Completa</h3>
              <p className="text-gray-600 relative z-10">
                Paneles con 30 años y 10 años en inversores. Incluye mantenimiento preventivo y soporte técnico 24/7.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Sección de IA estilo futurista */}
      <section className="py-20 bg-white relative overflow-hidden border-t border-gray-200">
        {/* Fondo con elementos futuristas */}
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-bl from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-gradient-to-tr from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>

          {/* Líneas de circuito */}
          <div className="absolute inset-0">
            <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
              <path d="M0,50 L100,50" stroke="rgba(255, 106, 0, 0.05)" strokeWidth="0.1" />
              <path d="M50,0 L50,100" stroke="rgba(255, 106, 0, 0.05)" strokeWidth="0.1" />
              <path d="M25,0 L25,100" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
              <path d="M75,0 L75,100" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
              <path d="M0,25 L100,25" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
              <path d="M0,75 L100,75" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
            </svg>
          </div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <span className="inline-block bg-white/80 text-[#ff6a00] text-sm px-4 py-1 rounded-full border border-gray-200 mb-4">
                TECNOLOGÍA EXCLUSIVA
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Revolucionando la Energía Solar con <br />
                <span className="text-[#ff6a00]">Inteligencia Artificial</span>
              </h2>
              <p className="text-xl text-gray-600">
                Primera empresa en Panamá en integrar IA para diseñar sistemas solares personalizados en segundos
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
              <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 order-2 md:order-1 border border-gray-200 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900 relative z-10">
                  Tu sistema solar, diseñado por IA
                </h3>
                <ul className="space-y-4 relative z-10">
                  <li className="flex items-start">
                    <div className="text-[#ff6a00] flex-shrink-0 mt-0.5 mr-3">
                      <CheckCircle2 />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Propuestas en 30 segundos</h4>
                      <p className="text-gray-600">No más esperas de días para recibir una cotización</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="text-[#ff6a00] flex-shrink-0 mt-0.5 mr-3">
                      <CheckCircle2 />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Diseño optimizado por IA</h4>
                      <p className="text-gray-600">Maximiza la eficiencia según tu consumo y espacio disponible</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="text-[#ff6a00] flex-shrink-0 mt-0.5 mr-3">
                      <CheckCircle2 />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Predicción de ahorro precisa</h4>
                      <p className="text-gray-600">Basada en tu historial de consumo y datos climáticos locales</p>
                    </div>
                  </li>
                </ul>

                <Link
                  href="/propuesta"
                  className="mt-8 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] py-3 px-6 text-white font-bold rounded-lg shadow-lg transition-all duration-300 flex items-center gap-2 relative z-10 overflow-hidden group"
                >
                  <Zap className="relative z-10" />
                  <span className="relative z-10">Probar Cotizador IA</span>
                  <div className="absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                </Link>
              </div>

              <div className="relative md:order-2">
                <div className="bg-white/80 rounded-xl border border-gray-200 shadow-xl overflow-hidden transform rotate-2 hover:rotate-0 transition-all duration-500 group">
                  {/* Usamos div con background-image en lugar de Image para simplificar */}
                  <div
                    className="w-full h-64 md:h-80 bg-cover bg-center relative"
                    style={{ backgroundImage: "url('/images/ai-solar-design.jpg')" }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-[#ff6a00]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  </div>

                  {/* Overlay with code-like elements - Estilo futurista */}
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white/80 flex flex-col justify-end p-4">
                    <div className="text-[#ff6a00] text-xs opacity-80 font-mono">
                      <div className="flex items-center gap-2">
                        <Cpu className="w-3 h-3" />
                        <span>{">> iniciando análisis solar con IA"}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Network className="w-3 h-3" />
                        <span>{">> calculando ubicación óptima de paneles"}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <BarChart3 className="w-3 h-3" />
                        <span>{">> estimando ROI y ahorros..."}</span>
                      </div>
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{">> propuesta lista: 28.4 segundos"}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] text-white font-bold px-4 py-2 rounded-lg shadow-lg transform rotate-6 animate-pulse">
                  ¡En tiempo real!
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección de Proyectos con estilo futurista */}
      <section className="py-20 bg-gray-50 border-t border-gray-200 relative overflow-hidden">
        {/* Fondo con elementos futuristas */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-1/3 h-1/3 bg-gradient-to-br from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-1/4 h-1/4 bg-gradient-to-tl from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>

          {/* Patrón de hexágonos */}
          <div className="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
              <pattern id="hexagons" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <path
                  d="M10,1 L19,6 L19,16 L10,21 L1,16 L1,6 Z"
                  fill="none"
                  stroke="rgba(255, 106, 0, 0.5)"
                  strokeWidth="0.2"
                />
              </pattern>
              <rect x="0" y="0" width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col items-center mb-12">
            <span className="bg-white/80 text-[#ff6a00] text-sm px-4 py-1 rounded-full border border-gray-200">
              EXPERIENCIA COMPROBADA
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-center mt-4 mb-2 relative text-gray-900">
              <span>Nuestros</span> <span className="text-[#ff6a00]">Proyectos</span>
              <span className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-gradient-to-r from-[#ff6a00] to-[#ff9500]"></span>
            </h2>
            <p className="text-center text-gray-600 max-w-2xl mt-6">
              Más de {formatNumber(count)} instalaciones residenciales y comerciales respaldan nuestra experiencia.
              Conoce algunos de nuestros proyectos destacados.
            </p>
          </div>

          {/* Grid de proyectos con diseño futurista */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Proyecto 1 - DSV */}
            <div
              className="bg-white/80 backdrop-blur-md rounded-xl border border-gray-200 overflow-hidden group transition-all duration-500 hover:border-[#ff6a00]/50 hover:shadow-xl h-full flex flex-col relative"
              id="dsv-project"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
              <div className="h-56 overflow-hidden relative">
                <div
                  className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700 bg-cover bg-center"
                  style={{ backgroundImage: "url('/images/38.jpg')" }}
                ></div>
                <div className="absolute inset-0 bg-gradient-to-t from-white/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute inset-0 bg-white/80 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center p-4">
                  <img src="/images/dsv.jpg" alt="DSV Logo" className="max-w-[80%] max-h-[80%] object-contain" />
                </div>
              </div>
              <div className="p-5 flex flex-col flex-grow relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Proyecto Comercial - DSV</h3>
                  <span className="text-xs font-medium bg-gradient-to-r from-[#ff6a00] to-[#ff9500] text-white px-4 py-1.5 rounded-full whitespace-nowrap">
                    218.36 kW
                  </span>
                </div>
                <div className="h-16 mb-4">
                  <p className="text-sm text-gray-600">
                    367 paneles solares de última generación con sistema de monitoreo en tiempo real.
                  </p>
                </div>
                <div className="mt-auto">
                  <div className="flex justify-between text-sm mb-4">
                    <span className="text-gray-500">Ahorro mensual:</span>
                    <span className="font-bold text-green-600">$4,500</span>
                  </div>
                  <button
                    onClick={handleOpenDsvModal}
                    className="w-full text-[#ff6a00] hover:text-white inline-flex items-center justify-center text-sm font-medium py-2 border border-[#ff6a00]/30 rounded-lg hover:bg-gradient-to-r hover:from-[#ff6a00] hover:to-[#ff9500] transition-all duration-300 group"
                  >
                    <span>Ver resultados de ahorro</span>
                    <ArrowRight className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </div>
            </div>

            {/* Proyecto 2 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl border border-gray-200 overflow-hidden group transition-all duration-500 hover:border-[#ff6a00]/50 hover:shadow-xl h-full flex flex-col relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
              <div className="h-56 overflow-hidden relative">
                <div
                  className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700 bg-cover bg-center"
                  style={{ backgroundImage: "url('/images/2.jpg')" }}
                ></div>
                <div className="absolute inset-0 bg-gradient-to-t from-white/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
              <div className="p-5 flex flex-col flex-grow relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Casa - Costa del Este</h3>
                  <span className="text-xs font-medium bg-gradient-to-r from-[#ff6a00] to-[#ff9500] text-white px-4 py-1.5 rounded-full whitespace-nowrap">
                    15.34 kW
                  </span>
                </div>
                <div className="h-16 mb-4">
                  <p className="text-sm text-gray-600">
                    26 paneles con sistema de batería de respaldo para cortes eléctricos.
                  </p>
                </div>
                <div className="mt-auto">
                  <div className="flex justify-between text-sm mb-4">
                    <span className="text-gray-500">Ahorro mensual:</span>
                    <span className="font-bold text-green-600">$450</span>
                  </div>
                  <button className="w-full text-[#ff6a00] hover:text-white inline-flex items-center justify-center text-sm font-medium py-2 border border-[#ff6a00]/30 rounded-lg hover:bg-gradient-to-r hover:from-[#ff6a00] hover:to-[#ff9500] transition-all duration-300 group">
                    <span>Ver resultados de ahorro</span>
                    <ArrowRight className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </div>
            </div>

            {/* Proyecto 3 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl border border-gray-200 overflow-hidden group transition-all duration-500 hover:border-[#ff6a00]/50 hover:shadow-xl h-full flex flex-col relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
              <div className="h-56 overflow-hidden relative">
                <div
                  className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700 bg-cover bg-center"
                  style={{ backgroundImage: "url('/images/33.jpg')" }}
                ></div>
                <div className="absolute inset-0 bg-gradient-to-t from-white/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
              <div className="p-5 flex flex-col flex-grow relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Casa - Santa Maria</h3>
                  <span className="text-xs font-medium bg-gradient-to-r from-[#ff6a00] to-[#ff9500] text-white px-4 py-1.5 rounded-full whitespace-nowrap">
                    16.40 kW
                  </span>
                </div>
                <div className="h-16 mb-4">
                  <p className="text-sm text-gray-600">
                    40 paneles solares con sistema de monitoreo inteligente vía app móvil.
                  </p>
                </div>
                <div className="mt-auto">
                  <div className="flex justify-between text-sm mb-4">
                    <span className="text-gray-500">Ahorro mensual:</span>
                    <span className="font-bold text-green-600">$500</span>
                  </div>
                  <button className="w-full text-[#ff6a00] hover:text-white inline-flex items-center justify-center text-sm font-medium py-2 border border-[#ff6a00]/30 rounded-lg hover:bg-gradient-to-r hover:from-[#ff6a00] hover:to-[#ff9500] transition-all duration-300 group">
                    <span>Ver resultados de ahorro</span>
                    <ArrowRight className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </div>
            </div>

            {/* Proyecto 4 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl border border-gray-200 overflow-hidden group transition-all duration-500 hover:border-[#ff6a00]/50 hover:shadow-xl h-full flex flex-col relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
              <div className="h-56 overflow-hidden relative">
                <div
                  className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700 bg-cover bg-center"
                  style={{ backgroundImage: "url('/images/37.jpg')" }}
                ></div>
                <div className="absolute inset-0 bg-gradient-to-t from-white/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
              <div className="p-5 flex flex-col flex-grow relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Casa - Costa del Este</h3>
                  <span className="text-xs font-medium bg-gradient-to-r from-[#ff6a00] to-[#ff9500] text-white px-4 py-1.5 rounded-full whitespace-nowrap">
                    23.60 kW
                  </span>
                </div>
                <div className="h-16 mb-4">
                  <p className="text-sm text-gray-600">40 paneles solares con sistema híbrido y 3 baterías de litio.</p>
                </div>
                <div className="mt-auto">
                  <div className="flex justify-between text-sm mb-4">
                    <span className="text-gray-500">Ahorro mensual:</span>
                    <span className="font-bold text-green-600">$750</span>
                  </div>
                  <button className="w-full text-[#ff6a00] hover:text-white inline-flex items-center justify-center text-sm font-medium py-2 border border-[#ff6a00]/30 rounded-lg hover:bg-gradient-to-r hover:from-[#ff6a00] hover:to-[#ff9500] transition-all duration-300 group">
                    <span>Ver resultados de ahorro</span>
                    <ArrowRight className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-10">
            <Link
              href="/proyectos"
              className="inline-block bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] py-3 px-8 rounded-lg shadow-lg transition-all duration-300 group flex items-center justify-center relative overflow-hidden text-white"
            >
              <span className="relative z-10">Ver Todos los Proyectos</span>
              <ArrowRight className="h-5 w-5 ml-2 transform group-hover:translate-x-1 transition-transform duration-300 relative z-10" />
              <div className="absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            </Link>
          </div>
        </div>

        {/* Modal para mostrar facturas - Reemplazado por renderizado condicional */}
        {modalOpen && <FacturasModal isOpen={true} closeModal={closeModal} projectId={currentProject} />}
      </section>

      {/* NUEVA SECCIÓN: Inyección Cero con estilo futurista */}
      <section className="py-20 bg-white border-t border-gray-200 relative overflow-hidden">
        {/* Fondo con elementos futuristas */}
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-gradient-to-bl from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-gradient-to-tr from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>

          {/* Patrón de circuitos */}
          <div className="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
              <pattern id="circuit" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <path
                  d="M0,10 L5,10 L5,0 M10,0 L10,5 L20,5 M20,10 L15,10 L15,20 M10,20 L10,15 L0,15"
                  fill="none"
                  stroke="rgba(255, 106, 0, 0.5)"
                  strokeWidth="0.2"
                />
              </pattern>
              <rect x="0" y="0" width="100%" height="100%" fill="url(#circuit)" />
            </svg>
          </div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <span className="text-sm text-[#ff6a00] bg-white/80 px-4 py-1 rounded-full border border-gray-200">
              INSTALACIÓN INMEDIATA
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mt-4 mb-4 text-gray-900">
              Instalación <span className="text-[#ff6a00]">Rápida e Inmediata</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Te instalamos de inmediato en un lapso de 7 a 10 días hábiles después del primer abono. Ahorra desde el
              primer día con inyección cero mientras esperas los trámites.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {/* Card 1 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 flex items-start space-x-4 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full p-3 text-white relative z-10">
                <Clock className="h-5 w-5" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Instalación en Tiempo Récord</h3>
                <p className="text-gray-600">
                  Te instalamos de inmediato en un lapso de 7 a 10 días hábiles después del primer abono.
                </p>
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 flex items-start space-x-4 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full p-3 text-white relative z-10">
                <Zap className="h-5 w-5" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Ahorra desde el Primer Día</h3>
                <p className="text-gray-600">
                  Ahorra con inyección cero mientras esperas los trámites y el cambio de medidor. ¡Mientras esperas,
                  ahorras!
                </p>
              </div>
            </div>

            {/* Card 3 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 flex items-start space-x-4 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full p-3 text-white relative z-10">
                <BarChart3 className="h-5 w-5" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Ahorro Sustancial</h3>
                <p className="text-gray-600">Se puede ahorrar entre un 50% al 70% en tu factura eléctrica mensual.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {/* Left Side - Zero Injection Explanation */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4 relative z-10">¿Qué es la Inyección Cero?</h3>
              <div className="space-y-4 relative z-10">
                <div>
                  <h4 className="font-semibold text-[#ff6a00] mb-2">¿Qué es la inyección cero?</h4>
                  <p className="text-gray-600">
                    Se refiere a la función que permite que un sistema fotovoltaico limite la energía que se vierte a la
                    red eléctrica, ajustando la producción para que no haya excedentes.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-[#ff6a00] mb-2">¿Cómo funciona?</h4>
                  <p className="text-gray-600">
                    El inversor ajusta la producción de energía para que se consuma dentro de la propiedad y no se envíe
                    a la red.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-[#ff6a00] mb-2">¿Es legal?</h4>
                  <p className="text-gray-600">
                    Sí, es totalmente legal. Es importante tener en cuenta que un sistema con Inyección Cero está
                    diseñado para aprovechar la energía generada durante las horas de sol, adaptando la producción
                    fotovoltaica al consumo instantáneo de la propiedad. Por tanto, su función principal es cubrir la
                    demanda diurna, cuando hay generación solar.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Side - Energy Flow Video */}
            <div className="bg-gradient-to-br from-white to-gray-50 p-6 rounded-xl border border-gray-200 shadow-lg relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <h3 className="text-xl font-semibold text-center mb-6 text-gray-900 relative z-10">
                Flujo de Energía con Inyección Cero
              </h3>

              <div className="relative flex justify-center items-center overflow-hidden rounded-lg h-64 bg-white shadow-inner">
                <video
                  src="/videos/inyeccioncero.mov"
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="relative w-full h-auto"
                  style={{
                    mixBlendMode: "multiply",
                  }}
                />

                {/* Overlay con efecto futurista */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#ff6a00]/30 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#ff6a00]/30 to-transparent"></div>
                  <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-[#ff6a00]/30 to-transparent"></div>
                  <div className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-transparent via-[#ff6a00]/30 to-transparent"></div>
                </div>
              </div>

              <div className="mt-6 text-center relative z-10">
                <p className="text-sm text-gray-700 leading-relaxed">
                  En este diagrama de inyección cero, observamos cómo un sistema solar inteligente optimiza el consumo
                  energético:
                </p>
                <ul className="text-sm text-gray-600 list-disc list-inside mt-2 text-left inline-block">
                  <li className="flex items-start">
                    <Sun className="text-[#ff6a00] h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Generación Solar: 5.04 kW de los paneles solares</span>
                  </li>
                  <li className="flex items-start">
                    <Lightbulb className="text-[#ff6a00] h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Consumo del Hogar: 5.94 kW de demanda total</span>
                  </li>
                  <li className="flex items-start">
                    <Network className="text-[#ff6a00] h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Aporte de la Red: 0.9 kW para completar la necesidad energética</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NUEVA SECCIÓN: Inyección Excedente con estilo futurista */}
      <section className="py-20 bg-gray-50 border-t border-gray-200 relative overflow-hidden">
        {/* Fondo con elementos futuristas */}
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-gradient-to-bl from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-gradient-to-tr from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>

          {/* Patrón de circuitos */}
          <div className="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
              <pattern id="circuit2" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <path
                  d="M0,10 L5,10 L5,0 M10,0 L10,5 L20,5 M20,10 L15,10 L15,20 M10,20 L10,15 L0,15"
                  fill="none"
                  stroke="rgba(255, 106, 0, 0.5)"
                  strokeWidth="0.2"
                />
              </pattern>
              <rect x="0" y="0" width="100%" height="100%" fill="url(#circuit2)" />
            </svg>
          </div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <span className="text-sm text-[#ff6a00] bg-white/80 px-4 py-1 rounded-full border border-gray-200">
              SISTEMA ON-GRID
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mt-4 mb-4 text-gray-900">
              Ahorre <span className="text-[#ff6a00]">hasta un 100% en su factura de luz!</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Después de tener los permisos aprobados y de haber usado el sistema en inyección cero ahorrando mientras
              esperabas ya podrás utilizar el sistema ON-GRID y ahorrar al 100%
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {/* Card 1 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 flex items-start space-x-4 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full p-3 text-white relative z-10">
                <Clock className="h-5 w-5" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Instalación en Tiempo Récord</h3>
                <p className="text-gray-600">Después de esperar 3 a 4 meses tendrás tu sistema funcionando al 100%.</p>
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 flex items-start space-x-4 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full p-3 text-white relative z-10">
                <Zap className="h-5 w-5" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Ahorra en grande</h3>
                <p className="text-gray-600">Disfruta del ahorro y de no tener que pagar más luz a las compañías!</p>
              </div>
            </div>

            {/* Card 3 */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 flex items-start space-x-4 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full p-3 text-white relative z-10">
                <BarChart3 className="h-5 w-5" />
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Monitoreo</h3>
                <p className="text-gray-600">Monitorea tu sistema con nuestra medición inteligente a través de WIFI.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {/* Left Side - ON-GRID Explanation */}
            <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 border border-gray-200 group hover:border-[#ff6a00]/30 transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <h3 className="text-2xl font-bold text-[#ff6a00] mb-4 relative z-10">¿Qué es una instalación ONGRID?</h3>

              <p className="text-gray-700 leading-relaxed mb-4 relative z-10">
                El <strong>sistema ON-GRID</strong> está conectado a la red eléctrica a través de un inversor que
                convierte la corriente continua (<strong>DC</strong>) generada por los paneles solares en corriente
                alterna (<strong>AC</strong>) compatible con la red.
              </p>

              <h4 className="text-xl font-semibold text-[#ff6a00] mb-2 relative z-10">¿Usa baterías?</h4>
              <p className="text-gray-700 mb-4 relative z-10">
                A diferencia de los sistemas <strong>OFF-GRID</strong>, los sistemas ON-GRID generalmente
                <em> no requieren baterías</em> para almacenar energía, ya que la energía generada se consume
                directamente o se inyecta a la red.
              </p>
              <p className="text-gray-700 mb-4 relative z-10">
                Cuando el sistema solar produce más energía de la que se consume en ese momento, el excedente se inyecta
                a la red eléctrica. Esto puede generar
                <strong> créditos o compensaciones</strong> en la factura eléctrica.
              </p>

              <h4 className="text-xl font-semibold text-[#ff6a00] mb-2 relative z-10">
                ¿Qué sucede si hay un corte de energía y tengo un sistema ON-GRID funcionando?
              </h4>
              <p className="text-gray-700 mb-4 relative z-10">
                El sistema se detiene porque depende de la sincronización con la red.
                <strong> Te quedarías sin luz</strong>, a menos que cuentes con baterías de respaldo (que ya sería un
                sistema híbrido).
              </p>
            </div>

            {/* Right Side - Energy Flow Video */}
            <div className="bg-gradient-to-br from-white to-gray-50 p-6 rounded-xl border border-gray-200 shadow-lg relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <h3 className="text-xl font-semibold text-center mb-6 text-gray-900 relative z-10">
                Flujo de Energía con Sistema ONGRID
              </h3>

              <div className="relative flex justify-center items-center overflow-hidden rounded-lg h-64 bg-white shadow-inner">
                <video
                  src="/videos/ongrid.mov"
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="relative w-full h-auto"
                  style={{
                    mixBlendMode: "multiply",
                  }}
                />

                {/* Overlay con efecto futurista */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#ff6a00]/30 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#ff6a00]/30 to-transparent"></div>
                  <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-[#ff6a00]/30 to-transparent"></div>
                  <div className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-transparent via-[#ff6a00]/30 to-transparent"></div>
                </div>
              </div>

              <div className="mt-6 text-center relative z-10">
                <p className="text-sm text-gray-700 leading-relaxed">
                  En este diagrama observamos un sistema ONGRID, vemos como el sistema solar genera excedente de energía
                  a la red:
                </p>
                <ul className="text-sm text-gray-600 list-disc list-inside mt-2 text-left inline-block">
                  <li className="flex items-start">
                    <Sun className="text-[#ff6a00] h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Generación Solar: 66.38 kW de los paneles solares</span>
                  </li>
                  <li className="flex items-start">
                    <Lightbulb className="text-[#ff6a00] h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Consumo del Hogar o Comercio: 18.18 kW de demanda total</span>
                  </li>
                  <li className="flex items-start">
                    <Network className="text-[#ff6a00] h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Excedente de energía a la red: 48.2 kW</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Mejorado con estilo futurista */}
      <section className="py-20 bg-white relative overflow-hidden border-t border-gray-200">
        {/* Fondo con elementos futuristas */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-[#ff6a00]/5 to-transparent opacity-30"></div>
          <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-gradient-to-b from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-gradient-to-t from-[#ff6a00]/5 to-transparent rounded-full blur-3xl"></div>

          {/* Líneas de circuito */}
          <div className="absolute inset-0">
            <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
              <path d="M0,50 L100,50" stroke="rgba(255, 106, 0, 0.05)" strokeWidth="0.1" />
              <path d="M50,0 L50,100" stroke="rgba(255, 106, 0, 0.05)" strokeWidth="0.1" />
              <path d="M25,0 L25,100" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
              <path d="M75,0 L75,100" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
              <path d="M0,25 L100,25" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
              <path d="M0,75 L100,75" stroke="rgba(255, 106, 0, 0.03)" strokeWidth="0.1" />
            </svg>
          </div>
        </div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
              ¿Listo para <span className="text-[#ff6a00]">Cambiar</span> a Energía Solar{" "}
              <span className="text-[#ff6a00]">Inteligente</span>?
            </h2>
            <p className="text-xl mb-8 text-gray-600">
              Solicita una cotización personalizada generada por IA y descubre cuánto puedes ahorrar con energía solar.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Link
                href="/propuesta"
                className="group flex-1 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] py-4 px-6 text-white font-bold rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center gap-2 relative overflow-hidden"
              >
                <span className="relative z-10">Cotizar Ahora</span>
                <Zap className="relative z-10" />
                <div className="absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              </Link>

              <Link
                href="/contacto"
                className="flex-1 bg-transparent hover:bg-gray-100 text-gray-800 font-bold py-4 px-6 border-2 border-gray-300 hover:border-[#ff6a00]/70 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 group relative overflow-hidden"
              >
                <span className="relative z-10">Contactar</span>
                <ArrowRight className="relative z-10 transform group-hover:translate-x-1 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-r from-[#ff6a00]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Link>
            </div>

            <div className="mt-8 text-gray-600 flex flex-wrap justify-center gap-x-6 gap-y-3">
              <span className="flex items-center text-sm">
                <div className="text-[#ff6a00] mr-1">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                Propuesta en 30 segundos
              </span>
              <span className="flex items-center text-sm">
                <div className="text-[#ff6a00] mr-1">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                Instalación en 7-10 días
              </span>
              <span className="flex items-center text-sm">
                <div className="text-[#ff6a00] mr-1">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                Garantía de 30 años
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Sección de Términos y Condiciones */}
      <section className="py-8 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center">
            <button
              onClick={() => router.push("/terminos-condiciones")}
              className="text-gray-500 hover:text-[#ff6a00] transition-colors duration-300 mb-4 text-sm font-medium flex items-center gap-2"
            >
              <span>Términos y Condiciones</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <p className="text-xs text-gray-500 text-center max-w-2xl">
              © 2025 SolarMente. Todos los derechos reservados. Al utilizar nuestros servicios, aceptas nuestros
              términos y condiciones. SolarMente es una marca registrada. Somos especialistas en energía solar con
              tecnología de Inteligencia Artificial.
            </p>
          </div>
        </div>
      </section>

      {/* Estilos CSS inline para animaciones específicas */}
      <style jsx global>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        /* Animaciones mejoradas */
        @keyframes pulse-slow {
          0%, 100% { opacity: 0.2; }
          50% { opacity: 0.5; }
        }
        
        .animate-pulse-slow {
          animation: pulse-slow 4s ease-in-out infinite;
        }
        
        /* Corregir problema de scroll en modales */
        body.modal-open {
          overflow: hidden;
          position: fixed;
          width: 100%;
        }
        
        /* Mejorar rendimiento de animaciones */
        .animate-pulse,
        .animate-fadeIn,
        .animate-bounce {
          will-change: opacity, transform;
        }
        
        /* Animaciones para los paneles solares */
        @keyframes floatPanel {
          0%, 100% { transform: translate(0, 0) scale(var(--scale)) rotate(var(--rotation)); }
          50% { transform: translate(20px, 15px) scale(var(--scale)) rotate(calc(var(--rotation) + 5deg)); }
        }
        
        @keyframes drawLine {
          0% { stroke-dashoffset: 1000; }
          100% { stroke-dashoffset: 0; }
        }
        
        @keyframes pulseGlow {
          0%, 100% { opacity: 0.2; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.5); }
        }
        
        @keyframes flowEnergy {
          0% { stroke-dashoffset: 1000; }
          100% { stroke-dashoffset: 0; }
        }
        
        @keyframes flowRight {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        
        @keyframes flowDown {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        
        .animate-draw {
          stroke-dasharray: 1000;
          stroke-dashoffset: 1000;
          animation: drawLine 2s forwards ease-in-out;
        }
        
        .animate-pulse-glow {
          animation: pulseGlow 3s infinite ease-in-out;
        }
        
        .animate-flow {
          stroke-dasharray: 1000;
          stroke-dashoffset: 1000;
          animation: flowEnergy 3s forwards ease-in-out;
        }
        
        .solar-panel-svg {
          --scale: 1;
          --rotation: 0deg;
        }

        /* Blueprint grid */
        .blueprint-grid {
          width: 100%;
          height: 100%;
        }

        /* Solar panel animations */
        @keyframes draw-frame {
          0% { stroke-dashoffset: 1200; }
          100% { stroke-dashoffset: 0; }
        }

        @keyframes draw-line {
          0% { stroke-dashoffset: 300; }
          100% { stroke-dashoffset: 0; }
        }

        @keyframes draw-cell {
          0% { stroke-dashoffset: 200; }
          100% { stroke-dashoffset: 0; }
        }

        @keyframes flare {
          0%, 100% { opacity: 0; transform: scale(0.5); }
          50% { opacity: 1; transform: scale(1.2); }
        }

        @keyframes flow-line {
          0% { stroke-dashoffset: 500; }
          100% { stroke-dashoffset: 0; }
        }

        .animate-draw-frame {
          stroke-dasharray: 1200;
          stroke-dashoffset: 1200;
          animation: draw-frame 2.5s forwards ease-in-out;
        }

        .animate-draw-line {
          stroke-dasharray: 300;
          stroke-dashoffset: 300;
          animation: draw-line 1.5s forwards ease-in-out;
        }

        .animate-draw-cell {
          stroke-dasharray: 200;
          stroke-dashoffset: 200;
          animation: draw-cell 1s forwards ease-in-out;
        }

        .animate-flare {
          animation: flare 2s infinite alternate;
        }

        .animate-flow-line {
          stroke-dasharray: 500;
          stroke-dashoffset: 500;
          animation: flow-line 2s linear forwards;
        }

        @keyframes float {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(10px);
          }
        }

        .animate-float {
          animation: float 4s ease-in-out infinite;
        }

@keyframes moveLineRight {
  0% {
    transform: translateX(0%);
  }
  100% {
    transform: translateX(50%);
  }
}

@keyframes moveLineDown {
  0% {
    transform: translateY(0%);
  }
  100% {
    transform: translateY(50%);
  }
}

@keyframes pulseDot {
  0%, 100% {
    opacity: 0.3;
    transform: scale(1);
  }
  50% {
    opacity: 0.8;
    transform: scale(1.5);
  }
}

@keyframes fadeInOut {
  0%, 100% {
    opacity: 0.1;
  }
  50% {
    opacity: 0.3;
  }
}

@keyframes flowParticle {
  0% {
    transform: translateX(0) translateY(0);
    opacity: 0;
  }
  10% {
    opacity: 0.7;
  }
  90% {
    opacity: 0.7;
  }
  100% {
    transform: translateX(100vw) translateY(20vh);
    opacity: 0;
  }
}

/* Header animation styles */
.header-line-h {
  position: absolute;
  height: 1px;
  background: linear-gradient(to right, transparent, #ff6a00, transparent);
  left: -100%;
  width: 200%;
  opacity: 0.3 + Math.random() * 0.4;
}

.header-line-v {
  position: absolute;
  width: 1px;
  background: linear-gradient(to bottom, transparent, #ff6a00, transparent);
  top: -100%;
  height: 200%;
  opacity: 0.2 + Math.random() * 0.3;
}

.header-dot {
  position: absolute;
  border-radius: 50%;
  background: #ff6a00;
  box-shadow: 0 0 8px 2px rgba(255, 106, 0, 0.6);
  opacity: 0.4 + Math.random() * 0.4;
}

.header-diagonal {
  position: absolute;
  height: 1px;
  width: 150%;
  background: linear-gradient(to right, transparent, #ff6a00, transparent);
  opacity: 0.15 + Math.random() * 0.2;
}

.header-particle {
  position: absolute;
  width: 2px;
  height: 2px;
  border-radius: 50%;
  background: #ff6a00;
  box-shadow: 0 0 10px 2px rgba(255, 106, 0, 0.8);
  opacity: 0.7;
}
      `}</style>

      <script
        dangerouslySetInnerHTML={{
          __html: `
    // Mostrar el primer panel de cada acordeón por defecto
    document.addEventListener('DOMContentLoaded', function() {
      // Para la sección de Inyección Cero
      const inyeccionZeroQueEs = document.getElementById('inyeccion-zero-que-es');
      if (inyeccionZeroQueEs) inyeccionZeroQueEs.classList.remove('hidden');
      
      // Para la sección ONGRID
      const ongridQueEs = document.getElementById('ongrid-que-es');
      if (ongridQueEs) ongridQueEs.classList.remove('hidden');
    });
  `,
        }}
      />

      <style jsx global>{`
        /* Animaciones para los elementos solares */
        @keyframes floatHorizontal {
          0% {
            transform: translateX(0);
          }
          50% {
            transform: translateX(30px);
          }
          100% {
            transform: translateX(0);
          }
        }

        @keyframes floatVertical {
          0% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(30px);
          }
          100% {
            transform: translateY(0);
          }
        }

        @keyframes pulseSun {
          0%, 100% {
            transform: scale(1);
            opacity: 0.6;
          }
          50% {
            transform: scale(1.1);
            opacity: 0.8;
          }
        }

        @keyframes rotateSun {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }

/* Animación para los contadores */
@keyframes countUp {
  0% {
    transform: translateY(20px);
    opacity: 0;
  }
  100% {
    transform: translateY(0);
    opacity: 1;
  }
}

.counter-animation {
  display: inline-block;
  animation: countUp 1s ease-out forwards;
}

/* Animación para las partículas en las tarjetas */
@keyframes floatParticle {
  0%, 100% {
    transform: translate(0, 0);
  }
  25% {
    transform: translate(10px, -10px);
  }
  50% {
    transform: translate(15px, 5px);
  }
  75% {
    transform: translate(5px, 10px);
  }
}

/* Efecto de hover para las tarjetas de estadísticas */
.stat-card:hover {
  box-shadow: 0 10px 25px -5px rgba(255, 106, 0, 0.1), 0 8px 10px -6px rgba(255, 106, 0, 0.1);
  border-color: rgba(255, 106, 0, 0.3);
}

.stat-card::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: 0.75rem;
  background: linear-gradient(45deg, transparent 50%, rgba(255, 106, 0, 0.1) 50%);
  background-size: 250% 250%;
  background-position: 0% 0%;
  transition: all 0.6s ease;
  z-index: 0;
}

.stat-card:hover::after {
  background-position: 100% 100%;
}
`}</style>
    </div>
  )
}
