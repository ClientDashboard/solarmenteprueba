import HomeClient from "@/components/home-client"

export const metadata = {
  title: "SolarMente - Energía Solar Inteligente en Panamá",
  description:
    "Primera empresa en Panamá que combina energía solar con IA avanzada. Ahorra hasta un 100% en tu factura de luz con propuestas personalizadas.",
}

export default function Home() {
  return <HomeClient />
}
