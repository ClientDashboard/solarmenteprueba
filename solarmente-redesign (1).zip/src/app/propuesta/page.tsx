import ProposalForm from "@/components/ProposalForm"

export const metadata = {
  title: "Cotizador Solar IA | SolarMente",
  description:
    "Genera una propuesta personalizada de energía solar en segundos con nuestra IA. Ahorra hasta un 100% en tu factura eléctrica.",
}

export default function ProposalPage() {
  return (
    <div className="min-h-screen bg-black">
      <ProposalForm />
    </div>
  )
}
