import { Suspense } from "react"
import ClientProposalPage from "@/components/solar-proposal/ClientProposalPage"

// Componente de carga para la vista previa
function LoadingProposal() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">Cargando propuesta solar...</h2>
        <div className="w-16 h-16 border-t-4 border-orange-500 border-solid rounded-full animate-spin mx-auto"></div>
      </div>
    </div>
  )
}

export default function ProposalPage({ params }: { params: { proposalId: string } }) {
  return (
    <Suspense fallback={<LoadingProposal />}>
      <ClientProposalPage proposalId={params.proposalId} />
    </Suspense>
  )
}
