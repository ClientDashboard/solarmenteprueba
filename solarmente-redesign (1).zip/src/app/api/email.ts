// services/email.ts
import sgMail from "@sendgrid/mail"
import { readFileSync } from "fs"
import path from "path"

// Set the SendGrid API key from your environment variable
const apiKey = process.env.SENDGRID_API_KEY

if (!apiKey) {
  console.error("SENDGRID_API_KEY is not set. Email functionality will not work.")
} else {
  sgMail.setApiKey(apiKey)
  console.log("SendGrid API key configured successfully")
}

// ---------------------------
// Load Client Email Template
// ---------------------------
let clientTemplate = ""
try {
  const clientTemplatePath = path.join(process.cwd(), "src", "app", "api", "email-templates", "transactional.html")
  clientTemplate = readFileSync(clientTemplatePath, "utf8")
  console.log(`Client template loaded successfully from: ${clientTemplatePath}`)
  // Optional: log a snippet to verify content
  console.log("Client template snippet:", clientTemplate.slice(0, 100))
} catch (error) {
  console.error(`Error reading client template:`, error)
  // Fallback template in case of error
  clientTemplate = `<html><body><h1>¡Tu propuesta solar está lista!</h1><p>Hola, hemos preparado tu propuesta solar personalizada.</p><p>Visita <a href="{{proposalUrl}}">este enlace</a> para verla.</p></body></html>`
  console.log("Using fallback client template")
}

// ---------------------------
// Load Admin Email Template
// ---------------------------
let adminTemplate = ""
try {
  const adminTemplatePath = path.join(process.cwd(), "src", "app", "api", "email-templates", "admin.html")
  adminTemplate = readFileSync(adminTemplatePath, "utf8")
  console.log(`Admin template loaded successfully from: ${adminTemplatePath}`)
  console.log("Admin template snippet:", adminTemplate.slice(0, 100))
} catch (error) {
  console.error(`Error reading admin template:`, error)
  adminTemplate = `<html><body><h1>Nueva propuesta generada</h1><p>Cliente: {{clienteNombre}}</p><p>Email: {{clienteEmail}}</p><p>Ver propuesta: <a href="{{proposalUrl}}">enlace</a></p></body></html>`
  console.log("Using fallback admin template")
}
