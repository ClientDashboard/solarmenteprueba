import { type NextRequest, NextResponse } from "next/server"

// Esta es una versión simplificada para el preview en v0
// que simula el envío de correos sin usar nodemailer o SendGrid
export async function POST(request: NextRequest) {
  try {
    // Simular procesamiento de la solicitud
    const data = await request.json()
    console.log("Simulando envío de correo con datos:", data)

    // Simular un retraso de procesamiento
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Devolver una respuesta exitosa simulada
    return NextResponse.json({
      success: true,
      emailStatus: {
        clienteEnviado: true,
        adminEnviado: true,
      },
      message: "Simulación de envío de correo exitosa (solo para vista previa)",
    })
  } catch (error) {
    console.error("Error en simulación de envío de correo:", error)
    return NextResponse.json({ error: "Error simulado en envío de correo" }, { status: 500 })
  }
}
