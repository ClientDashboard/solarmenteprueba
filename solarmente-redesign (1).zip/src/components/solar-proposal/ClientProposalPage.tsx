"use client"

import { useState, useEffect } from "react"
import PropuestaCliente from "./PropuestaCliente"

// Datos de muestra para la vista previa
const sampleProposalData = {
  id: "preview-123",
  nombre: "Cliente de Ejemplo",
  email: "cliente@ejemplo.com",
  telefono: "+507 6123-4567",
  consumo: 1500,
  tipo_propiedad: "residencial",
  provincia: "Panamá",
  fase_electrica: "monofasico",
  ahorro_estimado: 390,
  created_at: new Date().toISOString(),
}

export default function ClientProposalPage({ proposalId }: { proposalId: string }) {
  const [proposal, setProposal] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Determinar si estamos en el entorno de vista previa de v0
    const isV0Preview =
      typeof window !== "undefined" &&
      (window.location.hostname.includes("v0.dev") || window.location.hostname.includes("localhost"))

    if (isV0Preview) {
      // En vista previa, usar datos de muestra
      console.log("Usando datos de muestra para vista previa")
      setTimeout(() => {
        setProposal(sampleProposalData)
        setLoading(false)
      }, 1000) // Simular carga
      return
    }

    // Código real para entorno de producción
    const fetchProposal = async () => {
      try {
        const response = await fetch(`/api/proposal/${proposalId}`)
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`)
        }
        const data = await response.json()
        setProposal(data)
      } catch (err) {
        console.error("Error fetching proposal:", err)
        setError("No se pudo cargar la propuesta. Por favor, intente más tarde.")
      } finally {
        setLoading(false)
      }
    }

    fetchProposal()
  }, [proposalId])

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Cargando propuesta solar...</h2>
          <div className="w-16 h-16 border-t-4 border-orange-500 border-solid rounded-full animate-spin mx-auto"></div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center p-8 max-w-md">
          <h2 className="text-2xl font-bold mb-4 text-red-500">Error</h2>
          <p className="mb-6">{error}</p>
          <a href="/" className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition">
            Volver al inicio
          </a>
        </div>
      </div>
    )
  }

  if (!proposal) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center p-8 max-w-md">
          <h2 className="text-2xl font-bold mb-4">Propuesta no encontrada</h2>
          <p className="mb-6">No pudimos encontrar la propuesta solicitada.</p>
          <a href="/" className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition">
            Volver al inicio
          </a>
        </div>
      </div>
    )
  }

  return <PropuestaCliente proposal={proposal} />
}
