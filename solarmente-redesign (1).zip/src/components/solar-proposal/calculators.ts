import type { ProposalData } from "./types"

export function calcularPropuesta(consumo: number, esMonofasico = true): Omit<ProposalData, "cliente"> {
  // Cálculos básicos
  const tamanoSistema = calcularTamanoSistema(consumo, esMonofasico)
  const paneles = calcularNumeroPaneles(tamanoSistema)
  const inversores = Math.ceil(paneles / 4) // Asumiendo 4 paneles por inversor

  // Producción
  const produccionAnual = tamanoSistema * 1600 // kWh por año (estimado)
  const produccionMensual = generarProduccionMensual(produccionAnual)

  // Financiero
  const ahorroMensual = consumo * 0.21961 // Tarifa eléctrica
  const ahorroAnual = ahorroMensual * 12
  const ahorro25Anos = ahorroAnual * 25 * 1.5 // Considerando aumento de tarifas

  // Ambiental
  const co2Reducido = produccionAnual * 0.0007 // toneladas por kWh
  const petroleoReducido = produccionAnual * 0.09 // galones por kWh

  // Precios
  const precioBase = tamanoSistema * 1200 // $1,200 por kW
  const precioTotal = precioBase
  const cuotaMensual = calcularCuotaMensual(precioTotal, 48, 0.075) // 48 meses, 7.5% interés

  return {
    sistema: {
      tamano: tamanoSistema,
      paneles: paneles,
      inversores: inversores,
      potenciaPanel: 450,
      marcaPanel: "LONGi",
      modeloPanel: "Hi-MO 5",
      marcaInversor: "AP Systems",
      modeloInversor: "DS3",
      roi: 3,
    },
    produccion: {
      anual: produccionAnual,
      mensual: produccionMensual,
      promedioMensual: produccionAnual / 12,
    },
    financiero: {
      ahorroMensual: ahorroMensual,
      ahorroAnual: ahorroAnual,
      ahorro25Anos: ahorro25Anos,
    },
    ambiental: {
      co2Reducido: co2Reducido,
      petroleoReducido: petroleoReducido,
    },
    precios: {
      plan1: {
        total: precioTotal,
      },
      plan2: {
        cuotaMensual: cuotaMensual,
      },
    },
  }
}

// Funciones auxiliares
function calcularTamanoSistema(consumo: number, esMonofasico: boolean): number {
  // Cálculo básico: 1kW produce aproximadamente 130kWh/mes en Panamá
  let tamano = consumo / 130

  // Ajuste por tipo de sistema
  if (!esMonofasico) {
    tamano *= 1.1 // 10% más para sistemas trifásicos
  }

  // Redondear a 1 decimal
  return Math.round(tamano * 10) / 10
}

function calcularNumeroPaneles(tamanoSistema: number): number {
  // Asumiendo paneles de 450W
  return Math.ceil((tamanoSistema * 1000) / 450)
}

function generarProduccionMensual(produccionAnual: number): number[] {
  // Distribución mensual aproximada para Panamá (porcentajes)
  const distribucion = [0.085, 0.09, 0.095, 0.09, 0.08, 0.075, 0.08, 0.08, 0.075, 0.08, 0.085, 0.085]

  return distribucion.map((factor) => produccionAnual * factor)
}

function calcularCuotaMensual(monto: number, plazo: number, tasaAnual: number): number {
  const tasaMensual = tasaAnual / 12
  const factor = Math.pow(1 + tasaMensual, plazo)

  return (monto * (tasaMensual * factor)) / (factor - 1)
}
