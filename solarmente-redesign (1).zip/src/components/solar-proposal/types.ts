export interface ProposalData {
  cliente: {
    nombre: string
    telefono: string
    email: string
    consumo: number
  }
  sistema: {
    tamano: number
    paneles: number
    inversores: number
    potenciaPanel: number
    marcaPanel: string
    modeloPanel: string
    marcaInversor: string
    modeloInversor: string
    roi: number
  }
  produccion: {
    anual: number
    mensual: number[]
    promedioMensual: number
  }
  financiero: {
    ahorroMensual: number
    ahorroAnual: number
    ahorro25Anos: number
    ahorro30Anos: number
  }
  ambiental: {
    co2Reducido: number
    petroleoReducido: number
  }
  precios: {
    plan1: {
      total: number
      descuento: number
    }
    plan2: {
      cuotaMensual: number
      plazo: number
      inicial: number
    }
  }
}
