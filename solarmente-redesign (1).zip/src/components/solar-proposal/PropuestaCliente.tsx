"use client"

import { useState, useEffect } from "react"
import {
  Sun,
  Zap,
  DollarSign,
  BarChart3,
  Calendar,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Download,
  Phone,
  ChevronRight,
} from "lucide-react"
import type { ProposalData } from "./types"

interface PropuestaClienteProps {
  data: ProposalData
}

export default function PropuestaCliente({ data }: PropuestaClienteProps) {
  const [activeSection, setActiveSection] = useState("resumen")
  const [openAccordion, setOpenAccordion] = useState<string | null>("consumo")
  const [selectedPlan, setSelectedPlan] = useState<1 | 2>(1)
  const [showWelcome, setShowWelcome] = useState(true)
  const [animationComplete, setAnimationComplete] = useState(false)

  useEffect(() => {
    // Iniciar la animación después de cargar la página
    const timer = setTimeout(() => {
      setAnimationComplete(true)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id)
  }

  // Función para formatear números con separador de miles
  const formatNumber = (num: number): string => {
    return num.toLocaleString("es-PA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }

  // Datos mensuales de producción solar estimada
  const produccionMensual = data.produccion.mensual

  // Consumo actual del cliente
  const consumoActual = Array(12).fill(data.cliente.consumo)

  const handleViewProposal = () => {
    setShowWelcome(false)
  }

  // Extraer datos relevantes de la propuesta
  const { cliente, sistema, financiero, ambiental, precios } = data

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-[Mulish,sans-serif]">
      {/* Header con logo */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h1>
            <span className="ml-4 text-sm text-gray-500">Soluciones Energéticas Renovables</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 border border-gray-300 rounded-lg flex items-center gap-2 text-sm">
              <Download className="h-4 w-4" />
              Descargar PDF
            </button>
            <button className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-2 px-4 rounded-lg flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4" />
              Contactar
            </button>
          </div>
        </div>
      </header>

      {showWelcome ? (
        <div className="min-h-[calc(100vh-73px)] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center relative overflow-hidden pt-8">
          {/* Elementos decorativos de fondo */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full">
              {/* Círculos decorativos */}
              <div className="absolute top-[10%] left-[15%] w-64 h-64 rounded-full bg-[#ff6a00]/10 blur-3xl"></div>
              <div className="absolute bottom-[20%] right-[10%] w-80 h-80 rounded-full bg-[#ff9500]/10 blur-3xl"></div>
              <div className="absolute top-[40%] right-[30%] w-40 h-40 rounded-full bg-[#ff6a00]/5 blur-xl"></div>

              {/* Líneas de cuadrícula */}
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZGVmcz4KICA8cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgIDxwYXRoIGQ9Ik0gNDAgMCBMIDAgMCAwIDQwIiBmaWxsPSJub25lIiBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iMC41Ii8+CiAgPC9wYXR0ZXJuPgo8L2RlZnM+CjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiIC8+Cjwvc3ZnPg==')] opacity-10"></div>
            </div>
          </div>

          <div className="container mx-auto px-4 z-10 mt-8">
            <div className="max-w-4xl mx-auto text-center">
              {/* Icono de sol con animación */}
              <div className="flex justify-center mb-4">
                <div
                  className={`relative ${animationComplete ? "scale-100" : "scale-0"} transition-transform duration-700 ease-out`}
                >
                  <Sun className="h-16 w-16 text-[#ff6a00]" />
                  <div className="absolute inset-0 bg-[#ff6a00] rounded-full animate-ping opacity-20"></div>
                </div>
              </div>

              {/* Etiqueta de propuesta personalizada */}
              <div
                className={`inline-block bg-[#ff6a00]/10 backdrop-blur-sm px-4 py-1 rounded-full mb-3 ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-300`}
              >
                <span className="text-sm text-[#ff9500] font-medium">PROPUESTA PERSONALIZADA</span>
              </div>

              {/* Título principal con animación */}
              <h1
                className={`text-3xl md:text-5xl font-bold mb-4 text-white ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-500`}
              >
                Bienvenido, <span className="text-[#ff6a00]">{cliente.nombre.toUpperCase()}</span>
              </h1>

              {/* Subtítulo con animación */}
              <p
                className={`text-lg text-gray-300 mb-6 max-w-2xl mx-auto ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-700`}
              >
                Hemos preparado una propuesta personalizada de energía solar para optimizar su consumo energético y
                maximizar sus ahorros.
              </p>

              {/* Tarjetas de información con animación - VERSIÓN MÁS COMPACTA */}
              <div
                className={`grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} transition-all duration-700 delay-900`}
              >
                <div className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-lg border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-2">
                    <Zap className="h-8 w-8 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-base font-semibold text-white mb-1">Sistema Optimizado</h3>
                  <p className="text-sm text-gray-400">
                    {sistema.tamano} kWp de potencia diseñados para sus necesidades.
                  </p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-lg border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-2">
                    <DollarSign className="h-8 w-8 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-base font-semibold text-white mb-1">Ahorro Garantizado</h3>
                  <p className="text-sm text-gray-400">
                    B/. {formatNumber(financiero.ahorroAnual)} de ahorro anual en su factura eléctrica.
                  </p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-lg border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-2">
                    <Calendar className="h-8 w-8 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-base font-semibold text-white mb-1">Retorno Rápido</h3>
                  <p className="text-sm text-gray-400">Recupere su inversión en tan solo {sistema.roi} años.</p>
                </div>
              </div>

              {/* Botón para ver la propuesta completa */}
              <div
                className={`${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} transition-all duration-700 delay-1100`}
              >
                <button
                  onClick={handleViewProposal}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2 mx-auto text-base group relative overflow-hidden"
                >
                  <span className="relative z-10">Ver Propuesta Completa</span>
                  <ChevronRight className="h-5 w-5 relative z-10 group-hover:translate-x-1 transition-transform" />
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity"></div>
                </button>
              </div>

              {/* Fecha de la propuesta */}
              <div
                className={`mt-8 text-gray-400 text-sm ${animationComplete ? "opacity-100" : "opacity-0"} transition-opacity duration-700 delay-1300`}
              >
                <p>
                  Propuesta preparada el{" "}
                  {new Date().toLocaleDateString("es-PA", { day: "numeric", month: "long", year: "numeric" })}
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Navegación de secciones */}
          <div className="bg-white border-b border-gray-200">
            <div className="container mx-auto px-4 py-6">
              <div className="max-w-4xl mx-auto">
                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => setActiveSection("resumen")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "resumen"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Resumen Ejecutivo
                  </button>
                  <button
                    onClick={() => setActiveSection("analisis")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "analisis"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Análisis de Consumo
                  </button>
                  <button
                    onClick={() => setActiveSection("sistema")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "sistema"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Sistema Recomendado
                  </button>
                  <button
                    onClick={() => setActiveSection("financiero")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "financiero"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Análisis Financiero
                  </button>
                  <button
                    onClick={() => setActiveSection("planes")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "planes"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Planes de Pago
                  </button>
                  <button
                    onClick={() => setActiveSection("pasos")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "pasos"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Próximos Pasos
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Contenido principal */}
          <main className="container mx-auto px-4 py-12">
            <div className="max-w-4xl mx-auto">
              {/* Resumen Ejecutivo */}
              {activeSection === "resumen" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Resumen Ejecutivo
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Capacidad del Sistema</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">{sistema.tamano} kW</p>
                        <p className="text-sm text-gray-600">Sistema fotovoltaico</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Ahorro Anual</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">B/. {formatNumber(financiero.ahorroAnual)}</p>
                        <p className="text-sm text-gray-600">Estimado primer año</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Retorno de Inversión</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">{sistema.roi} años</p>
                        <p className="text-sm text-gray-600">ROI estimado</p>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Puntos Clave</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Sistema dimensionado para su consumo mensual de <strong>{cliente.consumo} kWh</strong>, con
                          una producción estimada de <strong>{data.produccion.promedioMensual} kWh</strong> mensuales.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Aprovechamiento del programa de compensación por excedentes, vendiendo el excedente de energía
                          a la red eléctrica.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Reducción significativa en el cargo por consumo de energía (B/.{" "}
                          {formatNumber(cliente.consumo * 0.21961)} en su factura actual).
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Mayor seguridad energética para su hogar y protección contra futuras alzas en las tarifas
                          eléctricas.
                        </span>
                      </li>
                    </ul>

                    <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-yellow-800 text-sm">
                        <strong>Nota importante:</strong> Con este sistema, usted podrá eliminar prácticamente su
                        factura eléctrica, con excepción de los cargos fijos, y generará más energía de la que consume
                        actualmente.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("analisis")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Análisis de Consumo
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Análisis de Consumo */}
              {activeSection === "analisis" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <BarChart3 className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Análisis de su Consumo Eléctrico
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Hemos analizado su patrón de consumo eléctrico y hemos diseñado un sistema que no solo cubrirá sus
                      necesidades actuales, sino que también generará excedentes que podrá vender a la red eléctrica.
                    </p>

                    <div className="mb-8">
                      <h3 className="text-lg font-semibold mb-4 text-gray-900">Consumo vs. Producción Mensual (kWh)</h3>
                      <div className="bg-gray-50 p-6 rounded-lg">
                        {/* Gráfico de barras simplificado */}
                        <div className="relative h-80 w-full">
                          {/* Líneas de referencia horizontales */}
                          <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">3,500</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">2,625</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">1,750</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">875</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">0</span>
                            </div>
                          </div>

                          {/* Barras del gráfico */}
                          <div className="absolute bottom-0 left-0 right-0 flex justify-between items-end h-full px-4">
                            {produccionMensual.map((produccion, index) => (
                              <div
                                key={index}
                                className="relative flex flex-col items-center group"
                                style={{ width: "7%" }}
                              >
                                {/* Barra de producción solar */}
                                <div
                                  className="w-full bg-[#ff6a00]"
                                  style={{
                                    height: `${(produccion / 3500) * 100}%`,
                                    minHeight: "4px",
                                  }}
                                ></div>

                                {/* Indicador de consumo actual */}
                                <div
                                  className="absolute w-full flex justify-center"
                                  style={{ bottom: `${(consumoActual[index] / 3500) * 100}%` }}
                                >
                                  <div className="h-3 w-3 bg-black rounded-full"></div>
                                </div>

                                {/* Tooltip */}
                                <div className="absolute bottom-full mb-2 bg-gray-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                                  Consumo: {formatNumber(consumoActual[index])} kWh
                                  <br />
                                  Producción: {formatNumber(produccion)} kWh
                                </div>

                                {/* Etiqueta de mes */}
                                <div className="absolute top-full mt-2 text-xs text-gray-500">
                                  {
                                    [
                                      "Ene",
                                      "Feb",
                                      "Mar",
                                      "Abr",
                                      "May",
                                      "Jun",
                                      "Jul",
                                      "Ago",
                                      "Sep",
                                      "Oct",
                                      "Nov",
                                      "Dic",
                                    ][index]
                                  }
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Leyenda */}
                        <div className="flex justify-center mt-12 gap-8">
                          <div className="flex items-center">
                            <div className="w-4 h-4 bg-[#ff6a00] mr-2"></div>
                            <span className="text-sm text-gray-700">Producción Solar</span>
                          </div>
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-black rounded-full mr-2"></div>
                            <span className="text-sm text-gray-700">Consumo Actual</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#fff5f0] p-4 rounded-lg mb-6">
                      <h3 className="text-lg font-semibold mb-2 text-gray-900">Detalles de su Factura Actual</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Consumo mensual:</p>
                          <p className="text-lg font-bold text-gray-900">{cliente.consumo} kWh</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Factura mensual:</p>
                          <p className="text-lg font-bold text-gray-900">
                            B/. {formatNumber(cliente.consumo * 0.21961)}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Tarifa de energía:</p>
                          <p className="text-lg font-bold text-gray-900">B/. 0.21961/kWh</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Cargo por energía:</p>
                          <p className="text-lg font-bold text-gray-900">
                            B/. {formatNumber(cliente.consumo * 0.21961)}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800 text-sm">
                        <strong>Beneficio clave:</strong> Su sistema solar producirá aproximadamente{" "}
                        <strong>{data.produccion.promedioMensual} kWh</strong> mensuales, lo que supera su consumo
                        actual de <strong>{cliente.consumo} kWh</strong>. Esto significa que no solo eliminará su
                        factura de electricidad, sino que también generará ingresos adicionales por la venta de
                        excedentes a la red eléctrica.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("sistema")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Sistema Recomendado
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Sistema Recomendado */}
              {activeSection === "sistema" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Sistema Recomendado
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Nuestra Recomendación</h3>
                    <p className="text-gray-700 mb-6">
                      Después de evaluar cuidadosamente sus datos de consumo, recomendamos un sistema solar de alta
                      eficiencia que maximizará su ahorro y aprovechará al máximo el espacio disponible en su techo.
                    </p>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("especificaciones")}
                      >
                        <div className="flex items-center">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Especificaciones del Sistema</span>
                        </div>
                        {openAccordion === "especificaciones" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "especificaciones" && (
                        <div className="p-4 border-t border-gray-100">
                          <div className="grid grid-cols-1 gap-6">
                            {/* Sección de Microinversores */}
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="flex flex-col justify-center">
                                  <div className="flex items-center mb-4">
                                    <h4 className="font-medium text-gray-900">
                                      Microinversores {sistema.marcaInversor}
                                    </h4>
                                    <img
                                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/APsystems-logo-primary-gT4XhVmnEtEbpLTElQ7HFF4b4DqeM7.png"
                                      alt="AP Systems Logo"
                                      className="h-6 ml-2"
                                    />
                                  </div>
                                  <div className="bg-pink-50 p-4 rounded-lg">
                                    <h5 className="font-medium text-gray-900 mb-2">
                                      ¿Por qué elegimos {sistema.marcaInversor}?
                                    </h5>
                                    <ul className="space-y-2">
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Monitoreo individual de cada panel solar para máximo rendimiento
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Mayor producción de energía incluso en condiciones de sombra parcial
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">Sistema más seguro con bajo voltaje DC</span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Diseño modular que facilita ampliaciones futuras del sistema
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Garantía extendida de 12 años, líder en la industria
                                        </span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="flex items-center justify-center">
                                  <img
                                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/APsystems_DS3-2022-BC-ScyxNgaBvDducFdQ3t1dJoeYTEgT54.png"
                                    alt="Microinversor AP Systems DS3"
                                    className="max-w-full h-auto max-h-64"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("consumo")}
                      >
                        <div className="flex items-center">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Consumo Eléctrico</span>
                        </div>
                        {openAccordion === "consumo" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "consumo" && (
                        <div className="p-4 border-t border-gray-100">
                          <div className="grid grid-cols-1 gap-6">
                            {/* Sección de Consumo Eléctrico */}
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="flex flex-col justify-center">
                                  <div className="flex items-center mb-4">
                                    <h4 className="font-medium text-gray-900">
                                      Análisis de Consumo
                                    </h4>
                                  </div>
                                  <div className="bg-pink-50 p-4 rounded-lg">
                                    <h5 className="font-medium text-gray-900 mb-2">
                                      ¿Por qué es importante entender tu consumo?
                                    </h5>
                                    <ul className="space-y-2">
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Optimización del sistema solar para tus necesidades específicas
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Maximización del ahorro en tu factura eléctrica
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">Identificación de oportunidades para reducir el consumo</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="flex items-center justify-center">
                                  <img
                                    src="https://images.pexels.com/photos/712853/pexels-photo-712853.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                    alt="Consumo Eléctrico"
                                    className="max-w-full h-auto max-h-64"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>\
