"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Zap } from "lucide-react"
import { processProposal } from "@/services/proposalService"

// Tipos para el formulario
interface FormData {
  nombre: string
  telefono: string
  email: string
  provincia: string
  tipoPropiedad: "residencial" | "comercial"
  faseElectrica: "monofasico" | "trifasico"
  consumo: number
}

export default function ProposalForm() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState<FormData>({
    nombre: "",
    telefono: "",
    email: "",
    provincia: "Panamá",
    tipoPropiedad: "residencial",
    faseElectrica: "monofasico",
    consumo: 1000,
  })

  // Calcular ahorro estimado (simplificado)
  const ahorroMensual = Math.round(formData.consumo * 0.26)

  // Manejar cambios en los campos del formulario
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement

    if (type === "radio") {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }))
    } else if (name === "consumo") {
      setFormData((prev) => ({
        ...prev,
        [name]: Number.parseInt(value) || 0,
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }))
    }
  }

  // Avanzar al siguiente paso
  const nextStep = () => {
    if (validateCurrentStep()) {
      setStep((prev) => prev + 1)
      window.scrollTo(0, 0)
    }
  }

  // Retroceder al paso anterior
  const prevStep = () => {
    setStep((prev) => prev - 1)
    window.scrollTo(0, 0)
  }

  // Validar el paso actual
  const validateCurrentStep = (): boolean => {
    setError(null)

    if (step === 1 && !formData.nombre) {
      setError("Por favor ingresa tu nombre completo")
      return false
    }

    if (step === 2) {
      if (!formData.telefono || formData.telefono.length < 8) {
        setError("Por favor ingresa un número de teléfono válido")
        return false
      }

      if (!formData.email || !formData.email.includes("@")) {
        setError("Por favor ingresa un correo electrónico válido")
        return false
      }
    }

    return true
  }

  // Enviar el formulario
  const handleSubmit = async () => {
    try {
      setLoading(true)

      // Usar el servicio de propuestas para procesar todo
      const result = await processProposal({
        nombre: formData.nombre,
        email: formData.email,
        telefono: formData.telefono,
        consumo: formData.consumo,
        tipoPropiedad: formData.tipoPropiedad,
        provincia: formData.provincia,
        faseElectrica: formData.faseElectrica,
      })

      // Redirigir a la página de propuesta
      router.push(
        `/propuesta/${result.id}?nombre=${encodeURIComponent(formData.nombre)}&consumo=${formData.consumo}&email=${encodeURIComponent(formData.email)}&telefono=${encodeURIComponent(formData.telefono)}&fase=${formData.faseElectrica}`,
      )
    } catch (err: any) {
      console.error("Error al enviar formulario:", err)
      setError("Ocurrió un error al generar tu propuesta. Por favor intenta nuevamente.")
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-black py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 relative">
        {/* Contenedor principal con borde naranja */}
        <div className="bg-black border border-solarmente-orange/50 rounded-2xl overflow-hidden">
          {/* Encabezado */}
          <div className="p-6 pb-0">
            <div className="flex justify-center mb-2">
              <h1 className="text-3xl font-bold text-white">
                Solar<span className="text-solarmente-orange">Mente</span>
                <span className="text-solarmente-orange font-light">.AI</span>
                <div className="absolute top-6 right-6">
                  <div className="w-6 h-6 bg-solarmente-orange rounded-full"></div>
                </div>
              </h1>
            </div>

            <p className="text-center text-white mb-1">
              Energía inteligente para un <span className="text-solarmente-orange">futuro brillante</span>
            </p>

            <p className="text-center text-gray-400 text-sm mb-4">
              Primera empresa en Panamá que combina energía solar con IA avanzada. Ahorra hasta un 100% en tu factura de
              luz con propuestas personalizadas.
            </p>

            {/* Línea naranja */}
            <div className="h-1 bg-gradient-to-r from-solarmente-orange to-solarmente-orange/20"></div>
          </div>

          {/* Contenido del paso actual */}
          <div className="p-6">
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white mb-1">Paso 1 de 3</h2>
                  <p className="text-gray-300 mb-6">
                    Comencemos por conocerte. Ingresa tu nombre completo para personalizar tu propuesta.
                  </p>
                </div>

                <div>
                  <label htmlFor="nombre" className="block text-sm font-medium text-gray-300 mb-1">
                    Nombre Completo
                  </label>
                  <input
                    type="text"
                    name="nombre"
                    id="nombre"
                    value={formData.nombre}
                    onChange={handleChange}
                    placeholder="Introduce tu nombre completo"
                    className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white focus:ring-solarmente-orange focus:border-solarmente-orange"
                  />
                  <p className="mt-2 text-xs text-gray-500">Este dato nos ayuda a personalizar tu propuesta</p>
                </div>

                {error && (
                  <div className="bg-red-900/30 border border-red-500/50 text-red-200 px-4 py-2 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <button
                  onClick={nextStep}
                  className="w-full bg-gradient-to-r from-solarmente-orange to-solarmente-orange-light text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:from-solarmente-orange-light hover:to-solarmente-orange transition-all duration-300"
                >
                  Continuar
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white mb-1">Paso 2 de 3</h2>
                  <p className="text-gray-300 mb-6">
                    ¿Cómo podemos contactarte? Necesitamos tu teléfono y email para enviarte la propuesta.
                  </p>
                </div>

                <div>
                  <label htmlFor="telefono" className="block text-sm font-medium text-gray-300 mb-1">
                    Teléfono
                  </label>
                  <div className="flex">
                    <div className="bg-gray-800 border border-gray-700 rounded-l-lg px-3 flex items-center">
                      <span className="text-white flex items-center gap-1">
                        <img src="https://flagcdn.com/w20/pa.png" alt="Bandera de Panamá" className="h-4" />
                        +507
                      </span>
                    </div>
                    <input
                      type="tel"
                      name="telefono"
                      id="telefono"
                      value={formData.telefono}
                      onChange={handleChange}
                      placeholder="8 dígitos"
                      className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-r-lg text-white focus:ring-solarmente-orange focus:border-solarmente-orange"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="correo@ejemplo.com"
                    className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white focus:ring-solarmente-orange focus:border-solarmente-orange"
                  />
                </div>

                {error && (
                  <div className="bg-red-900/30 border border-red-500/50 text-red-200 px-4 py-2 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <div className="flex gap-4">
                  <button
                    onClick={prevStep}
                    className="flex-1 bg-gray-800 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-700 transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M19 12H5M12 19l-7-7 7-7" />
                    </svg>
                    Atrás
                  </button>

                  <button
                    onClick={nextStep}
                    className="flex-1 bg-gradient-to-r from-solarmente-orange to-solarmente-orange-light text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:from-solarmente-orange-light hover:to-solarmente-orange transition-all duration-300"
                  >
                    Continuar
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M5 12h14M12 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white mb-1">Paso 3 de 3</h2>
                  <div className="bg-black border border-solarmente-orange/50 rounded-full px-3 py-1 text-xs text-solarmente-orange">
                    Ahorro: ~${ahorroMensual}/mes
                  </div>
                </div>
                <p className="text-gray-300 mb-6">
                  Cuéntanos sobre tu propiedad y la fase eléctrica para calcular el sistema ideal.
                </p>

                <div>
                  <label htmlFor="provincia" className="block text-sm font-medium text-gray-300 mb-1">
                    Provincia
                  </label>
                  <select
                    name="provincia"
                    id="provincia"
                    value={formData.provincia}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white focus:ring-solarmente-orange focus:border-solarmente-orange appearance-none"
                    style={{
                      backgroundImage:
                        'url(\'data:image/svg+xml;charset=US-ASCII,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="%23f77f00" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6"/></svg>\')',
                      backgroundRepeat: "no-repeat",
                      backgroundPosition: "right 1rem center",
                      backgroundSize: "1rem",
                    }}
                  >
                    <option value="Panamá">Panamá</option>
                    <option value="Chiriquí">Chiriquí</option>
                    <option value="Colón">Colón</option>
                    <option value="Veraguas">Veraguas</option>
                    <option value="Coclé">Coclé</option>
                    <option value="Herrera">Herrera</option>
                    <option value="Los Santos">Los Santos</option>
                    <option value="Bocas del Toro">Bocas del Toro</option>
                    <option value="Darién">Darién</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Tipo de Propiedad</label>
                  <div className="grid grid-cols-2 gap-4">
                    <label
                      className={`flex items-center justify-center p-3 border ${formData.tipoPropiedad === "residencial" ? "border-solarmente-orange bg-solarmente-orange/10" : "border-gray-700 bg-gray-900"} rounded-lg cursor-pointer transition-colors`}
                    >
                      <input
                        type="radio"
                        name="tipoPropiedad"
                        value="residencial"
                        checked={formData.tipoPropiedad === "residencial"}
                        onChange={handleChange}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <div
                          className={`w-4 h-4 rounded-full mr-2 flex items-center justify-center ${formData.tipoPropiedad === "residencial" ? "bg-solarmente-orange" : "bg-gray-700"}`}
                        >
                          {formData.tipoPropiedad === "residencial" && (
                            <div className="w-2 h-2 rounded-full bg-white"></div>
                          )}
                        </div>
                        <span className="text-white">Residencial</span>
                      </div>
                    </label>

                    <label
                      className={`flex items-center justify-center p-3 border ${formData.tipoPropiedad === "comercial" ? "border-solarmente-orange bg-solarmente-orange/10" : "border-gray-700 bg-gray-900"} rounded-lg cursor-pointer transition-colors`}
                    >
                      <input
                        type="radio"
                        name="tipoPropiedad"
                        value="comercial"
                        checked={formData.tipoPropiedad === "comercial"}
                        onChange={handleChange}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <div
                          className={`w-4 h-4 rounded-full mr-2 flex items-center justify-center ${formData.tipoPropiedad === "comercial" ? "bg-solarmente-orange" : "bg-gray-700"}`}
                        >
                          {formData.tipoPropiedad === "comercial" && (
                            <div className="w-2 h-2 rounded-full bg-white"></div>
                          )}
                        </div>
                        <span className="text-white">Comercial</span>
                      </div>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Fase Eléctrica</label>
                  <div className="grid grid-cols-2 gap-4">
                    <label
                      className={`flex items-center justify-center p-3 border ${formData.faseElectrica === "monofasico" ? "border-solarmente-orange bg-solarmente-orange/10" : "border-gray-700 bg-gray-900"} rounded-lg cursor-pointer transition-colors`}
                    >
                      <input
                        type="radio"
                        name="faseElectrica"
                        value="monofasico"
                        checked={formData.faseElectrica === "monofasico"}
                        onChange={handleChange}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <div
                          className={`w-4 h-4 rounded-full mr-2 flex items-center justify-center ${formData.faseElectrica === "monofasico" ? "bg-solarmente-orange" : "bg-gray-700"}`}
                        >
                          {formData.faseElectrica === "monofasico" && (
                            <div className="w-2 h-2 rounded-full bg-white"></div>
                          )}
                        </div>
                        <span className="text-white">Monofásico</span>
                      </div>
                    </label>

                    <label
                      className={`flex items-center justify-center p-3 border ${formData.faseElectrica === "trifasico" ? "border-solarmente-orange bg-solarmente-orange/10" : "border-gray-700 bg-gray-900"} rounded-lg cursor-pointer transition-colors`}
                    >
                      <input
                        type="radio"
                        name="faseElectrica"
                        value="trifasico"
                        checked={formData.faseElectrica === "trifasico"}
                        onChange={handleChange}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <div
                          className={`w-4 h-4 rounded-full mr-2 flex items-center justify-center ${formData.faseElectrica === "trifasico" ? "bg-solarmente-orange" : "bg-gray-700"}`}
                        >
                          {formData.faseElectrica === "trifasico" && (
                            <div className="w-2 h-2 rounded-full bg-white"></div>
                          )}
                        </div>
                        <span className="text-white">Trifásico</span>
                      </div>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    Consumo promedio mensual (kWh): {formData.consumo} kWh
                  </label>
                  <div className="bg-gray-900 border border-gray-700 rounded-lg p-4">
                    <input
                      type="range"
                      name="consumo"
                      min="100"
                      max="40000"
                      step="100"
                      value={formData.consumo}
                      onChange={handleChange}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-solarmente-orange"
                    />
                    <div className="flex justify-between text-xs text-gray-400 mt-2">
                      <span>1,000 kWh</span>
                      <span>40,000 kWh</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-2">
                      ¿Dónde encuentro mi consumo? Revisa tu factura de electricidad, donde aparece el consumo en kWh.
                    </p>
                  </div>
                </div>

                {error && (
                  <div className="bg-red-900/30 border border-red-500/50 text-red-200 px-4 py-2 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <div className="flex gap-4">
                  <button
                    onClick={prevStep}
                    className="flex-1 bg-gray-800 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-700 transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M19 12H5M12 19l-7-7 7-7" />
                    </svg>
                    Atrás
                  </button>

                  <button
                    onClick={nextStep}
                    className="flex-1 bg-gradient-to-r from-solarmente-orange to-solarmente-orange-light text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:from-solarmente-orange-light hover:to-solarmente-orange transition-all duration-300"
                  >
                    Continuar
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M5 12h14M12 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white mb-1">Revisar datos</h2>
                  <div className="bg-black border border-solarmente-orange/50 rounded-full px-3 py-1 text-xs text-solarmente-orange">
                    Ahorro: ~${ahorroMensual}/mes
                  </div>
                </div>
                <p className="text-gray-300 mb-6">
                  Revisa tus datos antes de generar tu propuesta personalizada con IA.
                </p>

                <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800">
                  <h3 className="text-white font-medium mb-4">Resumen de datos</h3>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-400 text-xs">Nombre</p>
                      <p className="text-white">{formData.nombre}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Teléfono</p>
                      <p className="text-white">+507 {formData.telefono}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Email</p>
                      <p className="text-white">{formData.email}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Provincia</p>
                      <p className="text-white">{formData.provincia}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Tipo de Propiedad</p>
                      <p className="text-white capitalize">{formData.tipoPropiedad}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Consumo mensual</p>
                      <p className="text-white">{formData.consumo} kWh</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Fase Eléctrica</p>
                      <p className="text-white capitalize">{formData.faseElectrica}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-green-500/20 rounded-full p-1 mt-0.5">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-green-500"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                      </svg>
                    </div>
                    <div>
                      <h4 className="text-green-400 font-medium">Ahorro Estimado Preliminar</h4>
                      <p className="text-green-200 text-sm">
                        Basado en tu consumo de {formData.consumo} kWh, podrías ahorrar aproximadamente{" "}
                        <span className="font-bold">${ahorroMensual}/mes</span>. Recibirás un análisis financiero
                        detallado en tu propuesta.
                      </p>
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="bg-red-900/30 border border-red-500/50 text-red-200 px-4 py-2 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <div className="flex gap-4">
                  <button
                    onClick={prevStep}
                    className="flex-1 bg-gray-800 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-700 transition-colors"
                    disabled={loading}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M19 12H5M12 19l-7-7 7-7" />
                    </svg>
                    Atrás
                  </button>

                  <button
                    onClick={handleSubmit}
                    className="flex-1 bg-gradient-to-r from-solarmente-orange to-solarmente-orange-light text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:from-solarmente-orange-light hover:to-solarmente-orange transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <svg
                          className="animate-spin -ml-1 mr-2 h-5 w-5 text-white"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          ></path>
                        </svg>
                        Generando...
                      </>
                    ) : (
                      <>
                        Generar Propuesta
                        <Zap className="h-5 w-5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
