"use client"

import { useState, useEffect, useCallback } from "react"
import { Zap, X, Maximize2, ArrowDownRight, LineChart, DollarSign, Bolt } from "lucide-react"

interface FacturasModalProps {
  isOpen: boolean
  closeModal: () => void
  projectId: string | null
}

function FacturasModal({ isOpen, closeModal, projectId }: FacturasModalProps) {
  // Mover todos los hooks al nivel superior (antes de cualquier condicional)
  const [animationComplete, setAnimationComplete] = useState(false)
  const [showComparison, setShowComparison] = useState(false)
  const [kwhCounter, setKwhCounter] = useState(23000)
  const [priceCounter, setPriceCounter] = useState(3500)
  const [demandCounter, setDemandCounter] = useState(760)
  const [showFullContent, setShowFullContent] = useState(false)
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null)

  // Mapeo de imágenes por proyecto
  const facturaImages: Record<string, string[]> = {
    dsv: ["/images/dsvfactura1.png", "/images/dsvfactura2.png"],
    // Puedes agregar más proyectos según necesites
  }

  const images = projectId && facturaImages[projectId] ? facturaImages[projectId] : []

  // Datos de consumo por proyecto
  const projectData: Record<
    string,
    {
      kwhBefore: number
      kwhAfter: number
      priceBefore: number
      priceAfter: number
      demandBefore: number
      demandAfter: number
    }
  > = {
    dsv: {
      kwhBefore: 23000,
      kwhAfter: 0,
      priceBefore: 3500,
      priceAfter: 0, // Cambiado a 0 para enfatizar el consumo cero
      demandBefore: 760,
      demandAfter: 534,
    },
    // Puedes agregar más proyectos aquí
  }

  const data =
    projectId && projectData[projectId]
      ? projectData[projectId]
      : { kwhBefore: 0, kwhAfter: 0, priceBefore: 0, priceAfter: 0, demandBefore: 0, demandAfter: 0 }

  // Efecto para bloquear el scroll del body cuando el modal está abierto
  useEffect(() => {
    if (isOpen) {
      // Guardar la posición actual del scroll
      const scrollY = window.scrollY
      document.body.style.position = "fixed"
      document.body.style.top = `-${scrollY}px`
      document.body.style.width = "100%"
    }

    // Limpiar y restaurar el scroll cuando se cierra
    return () => {
      if (isOpen) {
        const scrollY = Number.parseInt(document.body.style.top || "0") * -1
        document.body.style.position = ""
        document.body.style.top = ""
        document.body.style.width = ""
        window.scrollTo(0, scrollY)
      }
    }
  }, [isOpen])

  useEffect(() => {
    let timeout1: NodeJS.Timeout
    let timeout2: NodeJS.Timeout
    let timeout3: NodeJS.Timeout
    let kwhInterval: NodeJS.Timeout
    let priceInterval: NodeJS.Timeout
    let demandInterval: NodeJS.Timeout

    if (isOpen) {
      // Mostrar primero la animación de entrada
      timeout1 = setTimeout(() => {
        setShowComparison(true)
      }, 500)

      // Luego iniciar la animación de los contadores
      timeout2 = setTimeout(() => {
        kwhInterval = setInterval(() => {
          setKwhCounter((prev) => {
            const newValue = prev - Math.ceil((data.kwhBefore - data.kwhAfter) / 50)
            if (newValue <= data.kwhAfter) {
              clearInterval(kwhInterval)
              return data.kwhAfter
            }
            return newValue
          })
        }, 40)

        priceInterval = setInterval(() => {
          setPriceCounter((prev) => {
            const newValue = prev - Math.ceil((data.priceBefore - data.priceAfter) / 50)
            if (newValue <= data.priceAfter) {
              clearInterval(priceInterval)
              return data.priceAfter
            }
            return newValue
          })
        }, 40)

        demandInterval = setInterval(() => {
          setDemandCounter((prev) => {
            const newValue = prev - Math.ceil((data.demandBefore - data.demandAfter) / 50)
            if (newValue <= data.demandAfter) {
              clearInterval(demandInterval)
              return data.demandAfter
            }
            return newValue
          })
        }, 40)
      }, 1000)

      // Mostrar el contenido completo después de terminar las animaciones
      timeout3 = setTimeout(() => {
        setAnimationComplete(true)
        setShowFullContent(true)
      }, 3000)
    } else {
      // Resetear estados al cerrar
      setShowComparison(false)
      setAnimationComplete(false)
      setShowFullContent(false)
      setKwhCounter(data.kwhBefore)
      setPriceCounter(data.priceBefore)
      setDemandCounter(data.demandBefore)
      setEnlargedImage(null)
    }

    return () => {
      clearTimeout(timeout1)
      clearTimeout(timeout2)
      clearTimeout(timeout3)
      clearInterval(kwhInterval)
      clearInterval(priceInterval)
      clearInterval(demandInterval)
    }
  }, [isOpen, data.kwhBefore, data.kwhAfter, data.priceBefore, data.priceAfter, data.demandBefore, data.demandAfter])

  // Función para formatear números con separador de miles
  const formatNumber = (num: number): string => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  }

  // Función para ampliar una imagen - con useCallback
  const handleImageClick = useCallback((imgSrc: string) => {
    setEnlargedImage(imgSrc)
  }, [])

  // Función para cerrar la imagen ampliada - con useCallback
  const closeEnlargedImage = useCallback(() => {
    setEnlargedImage(null)
  }, [])

  // Aquí movemos la condicional después de todos los hooks
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-white/90 backdrop-blur-lg flex items-center justify-center z-50 p-4 animate-in fade-in duration-300">
      <div className="bg-white shadow-2xl border border-gray-200 rounded-xl w-full max-w-4xl overflow-hidden max-h-[90vh] relative">
        {/* Efectos de borde brillante */}
        <div className="absolute inset-0 rounded-xl pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#ff6a00]/50 to-transparent"></div>
          <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#ff6a00]/50 to-transparent"></div>
          <div className="absolute top-0 left-0 h-full w-[1px] bg-gradient-to-b from-transparent via-[#ff6a00]/50 to-transparent"></div>
          <div className="absolute top-0 right-0 h-full w-[1px] bg-gradient-to-b from-transparent via-[#ff6a00]/50 to-transparent"></div>
        </div>

        <div className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] p-4 text-white flex justify-between items-center sticky top-0 z-10">
          <h3 className="text-xl font-bold flex items-center">
            <Zap className="mr-2 h-5 w-5" />
            Resultados de Ahorro Increíbles
          </h3>
          <button
            onClick={closeModal}
            className="text-white hover:text-gray-200 transition-colors bg-white/10 rounded-full p-1.5 hover:bg-white/20"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 overflow-auto max-h-[calc(90vh-4rem)]">
          {/* Animación de transición inicial */}
          {!showComparison && (
            <div className="flex flex-col items-center justify-center py-16 animate-in fade-in duration-300">
              <div className="relative w-24 h-24 mb-8">
                <div className="absolute inset-0 rounded-full border-2 border-[#ff6a00]/20"></div>
                <div className="absolute inset-0 rounded-full border-t-2 border-[#ff6a00] animate-spin"></div>
                <div
                  className="absolute inset-0 rounded-full border-2 border-transparent border-t-[#ff9500] animate-spin"
                  style={{ animationDuration: "1.5s" }}
                ></div>
                <div className="absolute inset-2 rounded-full bg-gradient-to-br from-[#ff6a00]/20 to-transparent animate-pulse"></div>
                <Zap className="absolute inset-0 m-auto h-8 w-8 text-[#ff6a00]" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Calculando ahorros...</h3>
              <p className="text-gray-600 text-center max-w-lg">
                Estamos procesando los datos de antes y después para mostrarle los resultados impresionantes
              </p>
            </div>
          )}

          {showComparison && (
            <>
              {/* Tablero de comparación de energía */}
              <div className="mb-8 bg-gray-50 p-6 rounded-xl border border-gray-200 relative overflow-hidden group">
                {/* Fondo con efecto futurista */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                <h4 className="text-xl font-bold text-gray-900 mb-6 text-center relative z-10">
                  Impacto en Consumo y Facturación
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
                  {/* Consumo de energía */}
                  <div className="relative bg-white p-4 rounded-lg border border-gray-200 overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <h5 className="text-lg font-semibold text-gray-900 mb-4 flex items-center relative z-10">
                      <Bolt className="h-5 w-5 mr-2 text-[#ff6a00]" />
                      Consumo de Energía
                    </h5>

                    <div className="flex items-center justify-between mb-2 relative z-10">
                      <span className="text-gray-600">Antes:</span>
                      <span className="text-gray-900 font-bold">{formatNumber(data.kwhBefore)} kWh</span>
                    </div>

                    <div className="flex items-center justify-between relative z-10">
                      <span className="text-gray-600">Ahora:</span>
                      <div className="flex items-baseline">
                        <span
                          className={`text-2xl font-bold ${animationComplete ? "text-green-600" : "text-gray-900"} transition-colors duration-500`}
                        >
                          {formatNumber(kwhCounter)} kWh
                        </span>
                      </div>
                    </div>

                    <div className="h-3 w-full bg-gray-200 rounded-full mt-4 overflow-hidden relative z-10">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-green-300 transition-all duration-1000 ease-out rounded-full relative"
                        style={{
                          width: `${100 - (kwhCounter / data.kwhBefore) * 100}%`,
                          transitionDelay: "0.5s",
                        }}
                      >
                        <div className="absolute inset-0 bg-white/20 animate-pulse-slow"></div>
                      </div>
                    </div>

                    {animationComplete && (
                      <div className="mt-2 text-right relative z-10">
                        <span className="text-green-600 font-bold flex items-center justify-end">
                          <ArrowDownRight className="h-4 w-4 mr-1" />
                          {Math.round(100 - (data.kwhAfter / data.kwhBefore) * 100)}% de reducción
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Costo mensual */}
                  <div className="relative bg-white p-4 rounded-lg border border-gray-200 overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <h5 className="text-lg font-semibold text-gray-900 mb-4 flex items-center relative z-10">
                      <DollarSign className="h-5 w-5 mr-2 text-[#ff6a00]" />
                      Costo Mensual
                    </h5>

                    <div className="flex items-center justify-between mb-2 relative z-10">
                      <span className="text-gray-600">Antes:</span>
                      <span className="text-gray-900 font-bold">${formatNumber(data.priceBefore)}</span>
                    </div>

                    <div className="flex items-center justify-between relative z-10">
                      <span className="text-gray-600">Ahora:</span>
                      <div className="flex items-baseline">
                        <span
                          className={`text-2xl font-bold ${animationComplete ? "text-green-600" : "text-gray-900"} transition-colors duration-500`}
                        >
                          ${formatNumber(priceCounter)}
                        </span>
                      </div>
                    </div>

                    <div className="h-3 w-full bg-gray-200 rounded-full mt-4 overflow-hidden relative z-10">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-green-300 transition-all duration-1000 ease-out rounded-full relative"
                        style={{
                          width: `${100 - (priceCounter / data.priceBefore) * 100}%`,
                          transitionDelay: "0.7s",
                        }}
                      >
                        <div className="absolute inset-0 bg-white/20 animate-pulse-slow"></div>
                      </div>
                    </div>

                    {animationComplete && (
                      <div className="mt-2 text-right relative z-10">
                        <span className="text-green-600 font-bold flex items-center justify-end">
                          <ArrowDownRight className="h-4 w-4 mr-1" />
                          {Math.round(100 - (data.priceAfter / data.priceBefore) * 100)}% de ahorro
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Demanda máxima */}
                  <div className="relative bg-white p-4 rounded-lg border border-gray-200 overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <h5 className="text-lg font-semibold text-gray-900 mb-4 flex items-center relative z-10">
                      <LineChart className="h-5 w-5 mr-2 text-[#ff6a00]" />
                      Demanda Máxima
                    </h5>

                    <div className="flex items-center justify-between mb-2 relative z-10">
                      <span className="text-gray-600">Antes:</span>
                      <span className="text-gray-900 font-bold">{formatNumber(data.demandBefore)} kW</span>
                    </div>

                    <div className="flex items-center justify-between relative z-10">
                      <span className="text-gray-600">Ahora:</span>
                      <div className="flex items-baseline">
                        <span
                          className={`text-2xl font-bold ${animationComplete ? "text-green-600" : "text-gray-900"} transition-colors duration-500`}
                        >
                          {formatNumber(demandCounter)} kW
                        </span>
                      </div>
                    </div>

                    <div className="h-3 w-full bg-gray-200 rounded-full mt-4 overflow-hidden relative z-10">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-green-300 transition-all duration-1000 ease-out rounded-full relative"
                        style={{
                          width: `${100 - (demandCounter / data.demandBefore) * 100}%`,
                          transitionDelay: "0.9s",
                        }}
                      >
                        <div className="absolute inset-0 bg-white/20 animate-pulse-slow"></div>
                      </div>
                    </div>

                    {animationComplete && (
                      <div className="mt-2 text-right relative z-10">
                        <span className="text-green-600 font-bold flex items-center justify-end">
                          <ArrowDownRight className="h-4 w-4 mr-1" />
                          {Math.round(100 - (data.demandAfter / data.demandBefore) * 100)}% de reducción
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {showFullContent && (
                  <div className="mt-8 relative z-10">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                      <span className="text-[#ff6a00] mr-2">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          <path
                            fillRule="evenodd"
                            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </span>
                      Análisis de Resultados
                    </h4>

                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <p className="text-gray-700 mb-4">
                        Los resultados muestran una reducción significativa en el consumo de energía y costos asociados
                        después de la instalación del sistema solar. Esto se traduce en:
                      </p>

                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <span className="text-green-600 mr-2">✓</span>
                          <span>
                            Ahorro anual estimado de{" "}
                            <strong className="text-gray-900">${formatNumber(data.priceBefore * 12)}</strong>
                          </span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-green-600 mr-2">✓</span>
                          <span>
                            Reducción de huella de carbono equivalente a plantar{" "}
                            <strong className="text-gray-900">
                              {Math.round(((data.kwhBefore * 0.7) / 1000) * 12)}
                            </strong>{" "}
                            árboles al año
                          </span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-green-600 mr-2">✓</span>
                          <span>
                            Retorno de inversión estimado en <strong className="text-gray-900">3-4 años</strong> basado
                            en el ahorro actual
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              {/* Facturas antes y después */}
              {images.length > 0 && showFullContent && (
                <div className="mb-8 bg-gray-50 p-6 rounded-xl border border-gray-200 relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                  <h4 className="text-xl font-bold text-gray-900 mb-6 text-center relative z-10">
                    Facturas Antes vs Después
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                    {images.map((img, index) => (
                      <div
                        key={index}
                        className="relative bg-white p-2 rounded-lg border border-gray-200 overflow-hidden group cursor-pointer transform transition-transform hover:scale-[1.02]"
                        onClick={() => handleImageClick(img)}
                      >
                        <div className="absolute inset-0 bg-gradient-to-br from-[#ff6a00]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                        <div className="relative aspect-[4/5] overflow-hidden rounded-md">
                          <img
                            src={img || "/placeholder.svg"}
                            alt={`Factura ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-gray-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center p-4">
                            <button className="bg-white/80 backdrop-blur-sm text-gray-900 px-4 py-2 rounded-full flex items-center text-sm font-medium">
                              <Maximize2 className="h-4 w-4 mr-1" />
                              Ampliar imagen
                            </button>
                          </div>
                        </div>

                        <div className="mt-2 text-center text-sm text-gray-600 relative z-10">
                          {index === 0 ? "Factura Antes" : "Factura Después"}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          <div className="mt-8 text-center">
            <button
              onClick={closeModal}
              className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] py-3 px-8 text-white font-bold rounded-lg transition-all duration-300 relative overflow-hidden group"
            >
              <span className="relative z-10">Cerrar</span>
              <div className="absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            </button>
          </div>
        </div>
      </div>

      {/* Modal de imagen ampliada */}
      {enlargedImage && (
        <div
          className="fixed inset-0 bg-white/95 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={closeEnlargedImage}
        >
          <div className="relative max-w-5xl max-h-[90vh] w-full h-full flex items-center justify-center">
            <button
              className="absolute top-4 right-4 bg-white/80 text-gray-900 rounded-full p-2 hover:bg-gray-100 transition-colors z-10 backdrop-blur-sm border border-gray-200"
              onClick={closeEnlargedImage}
            >
              <X className="h-6 w-6" />
            </button>
            <img
              src={enlargedImage || "/placeholder.svg"}
              alt="Factura ampliada"
              className="max-w-full max-h-full object-contain rounded-lg shadow-lg border border-gray-200"
            />
          </div>
        </div>
      )}
    </div>
  )
}

export default FacturasModal
