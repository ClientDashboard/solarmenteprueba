"use client"

import { useState, useEffect } from "react"
import {
  Sun,
  Zap,
  DollarSign,
  BarChart3,
  Calendar,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Download,
  Phone,
  Shield,
  Upload,
  FileSpreadsheet,
  FileIcon as FilePdf,
  ChevronRight,
} from "lucide-react"

// Definir interfaces para los datos del cliente
interface ClienteData {
  nombre: string
  fecha: string
  facturaActual: {
    consumo: number // en kWh
    cargoPorConsumo: number // en B/.
    cargoPorDemanda: number // en B/.
    mes: string
    año: string
    distribuidor: string // ENSA, EDEMET, etc.
  }
  patronConsumo: {
    maximo: number // en kWh
    mesesAlto: number // cantidad de meses con consumo alto
    mesesBajo: number // cantidad de meses con consumo bajo
  }
  sistemaRecomendado: {
    capacidad: number // en kWp
    paneles: {
      cantidad: number
      potencia: number // en W
    }
    inversores: {
      cantidad: number
      potencia: number // en kW
    }
    generacionAnual: number // en kWh
    areaRequerida: number // en m²
  }
  financiero: {
    inversionTotal: number // en B/.
    ahorroAnual: number // en B/.
    roi: number // en años
    proyeccion: Array<{
      año: number
      ahorroAnual: number
      ahorroAcumulado: number
      roiPorcentaje: number
    }>
  }
  contacto: {
    telefono: string
    celular: string
    email: string
    emailSecundario: string
  }
  consumoMensual: number[] // Array de 12 valores para el gráfico de barras
}

// Datos de ejemplo para mostrar en el template
const clienteEjemplo: ClienteData = {
  nombre: "ARCE AVICOLA S.A.",
  fecha: "12 de abril de 2025",
  facturaActual: {
    consumo: 158448,
    cargoPorConsumo: 3493.03,
    cargoPorDemanda: 3819.46,
    mes: "febrero",
    año: "2025",
    distribuidor: "ENSA",
  },
  patronConsumo: {
    maximo: 158448,
    mesesAlto: 6,
    mesesBajo: 6,
  },
  sistemaRecomendado: {
    capacidad: 350,
    paneles: {
      cantidad: 700,
      potencia: 500,
    },
    inversores: {
      cantidad: 5,
      potencia: 70,
    },
    generacionAnual: 560000,
    areaRequerida: 2100,
  },
  financiero: {
    inversionTotal: 175000,
    ahorroAnual: 41916,
    roi: 4.2,
    proyeccion: [
      { año: 1, ahorroAnual: 41916, ahorroAcumulado: 41916, roiPorcentaje: 24 },
      { año: 2, ahorroAnual: 43173, ahorroAcumulado: 85089, roiPorcentaje: 49 },
      { año: 3, ahorroAnual: 44469, ahorroAcumulado: 129558, roiPorcentaje: 74 },
      { año: 4, ahorroAnual: 45803, ahorroAcumulado: 175361, roiPorcentaje: 100 },
      { año: 5, ahorroAnual: 47177, ahorroAcumulado: 222538, roiPorcentaje: 127 },
      { año: 10, ahorroAnual: 54685, ahorroAcumulado: 487538, roiPorcentaje: 279 },
      { año: 15, ahorroAnual: 63380, ahorroAcumulado: 798538, roiPorcentaje: 456 },
      { año: 20, ahorroAnual: 73440, ahorroAcumulado: 1165538, roiPorcentaje: 666 },
      { año: 25, ahorroAnual: 85110, ahorroAcumulado: 1598538, roiPorcentaje: 914 },
    ],
  },
  contacto: {
    telefono: "(+507) 236-3255",
    celular: "(+507) 6414-3255",
    email: "ventas@solarmente.io",
    emailSecundario: "info@solarmente.io",
  },
  consumoMensual: [158448, 145000, 138000, 92000, 85000, 78000, 75000, 82000, 90000, 130000, 142000, 155000],
}

// Función para formatear números con separador de miles
const formatNumber = (num: number): string => {
  return num.toLocaleString("es-PA")
}

export default function PropuestaTemplate({ cliente = clienteEjemplo }: { cliente?: ClienteData }) {
  const [activeSection, setActiveSection] = useState("resumen")
  const [openAccordion, setOpenAccordion] = useState<string | null>("consumo")
  const [showUploadForm, setShowUploadForm] = useState(false)
  const [showWelcome, setShowWelcome] = useState(true)
  const [animationComplete, setAnimationComplete] = useState(false)

  useEffect(() => {
    // Iniciar la animación después de cargar la página
    const timer = setTimeout(() => {
      setAnimationComplete(true)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id)
  }

  const handleViewProposal = () => {
    setShowWelcome(false)
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-[Mulish,sans-serif]">
      {/* Header con logo */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h1>
            <span className="ml-4 text-sm text-gray-500">Soluciones Energéticas Renovables</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowUploadForm(!showUploadForm)}
              className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 border border-gray-300 rounded-lg flex items-center gap-2 text-sm"
            >
              <Upload className="h-4 w-4" />
              Cargar Datos
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 border border-gray-300 rounded-lg flex items-center gap-2 text-sm">
              <Download className="h-4 w-4" />
              Descargar PDF
            </button>
            <button className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-2 px-4 rounded-lg flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4" />
              Contactar
            </button>
          </div>
        </div>
      </header>

      {/* Formulario de carga de datos */}
      {showUploadForm && (
        <div className="bg-white border-b border-gray-200 shadow-md">
          <div className="container mx-auto px-4 py-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-xl font-bold mb-4 text-gray-900">Cargar Datos del Cliente</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <div className="flex items-center mb-3">
                    <FileSpreadsheet className="h-5 w-5 text-[#ff6a00] mr-2" />
                    <h3 className="font-medium text-gray-900">Factura de Luz</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Sube la factura de luz del cliente para extraer automáticamente los datos de consumo.
                  </p>
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-white hover:bg-gray-50">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-8 h-8 mb-3 text-gray-400" />
                        <p className="mb-2 text-sm text-gray-500">
                          <span className="font-semibold">Haz clic para subir</span> o arrastra y suelta
                        </p>
                        <p className="text-xs text-gray-500">PDF, JPG o PNG (Max. 10MB)</p>
                      </div>
                      <input id="dropzone-file" type="file" className="hidden" />
                    </label>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <div className="flex items-center mb-3">
                    <FilePdf className="h-5 w-5 text-[#ff6a00] mr-2" />
                    <h3 className="font-medium text-gray-900">Propuesta Actual</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Sube la propuesta actual en PDF para extraer los datos del sistema recomendado.
                  </p>
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-white hover:bg-gray-50">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-8 h-8 mb-3 text-gray-400" />
                        <p className="mb-2 text-sm text-gray-500">
                          <span className="font-semibold">Haz clic para subir</span> o arrastra y suelta
                        </p>
                        <p className="text-xs text-gray-500">PDF (Max. 10MB)</p>
                      </div>
                      <input id="dropzone-file" type="file" className="hidden" />
                    </label>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setShowUploadForm(false)}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg mr-3"
                >
                  Cancelar
                </button>
                <button className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-2 px-4 rounded-lg">
                  Procesar Datos
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pantalla de bienvenida */}
      {showWelcome ? (
        <div className="min-h-[calc(100vh-73px)] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center relative overflow-hidden">
          {/* Elementos decorativos de fondo */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full">
              {/* Círculos decorativos */}
              <div className="absolute top-[10%] left-[15%] w-64 h-64 rounded-full bg-[#ff6a00]/10 blur-3xl"></div>
              <div className="absolute bottom-[20%] right-[10%] w-80 h-80 rounded-full bg-[#ff9500]/10 blur-3xl"></div>
              <div className="absolute top-[40%] right-[30%] w-40 h-40 rounded-full bg-[#ff6a00]/5 blur-xl"></div>

              {/* Líneas de cuadrícula */}
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZGVmcz4KICA8cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgIDxwYXRoIGQ9Ik0gNDAgMCBMIDAgMCAwIDQwIiBmaWxsPSJub25lIiBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iMC41Ii8+CiAgPC9wYXR0ZXJuPgo8L2RlZnM+CjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiIC8+Cjwvc3ZnPg==')] opacity-10"></div>
            </div>
          </div>

          <div className="container mx-auto px-4 z-10">
            <div className="max-w-4xl mx-auto text-center">
              {/* Icono de sol con animación */}
              <div className="flex justify-center mb-6">
                <div
                  className={`relative ${animationComplete ? "scale-100" : "scale-0"} transition-transform duration-700 ease-out`}
                >
                  <Sun className="h-20 w-20 text-[#ff6a00]" />
                  <div className="absolute inset-0 bg-[#ff6a00] rounded-full animate-ping opacity-20"></div>
                </div>
              </div>

              {/* Etiqueta de propuesta personalizada */}
              <div
                className={`inline-block bg-[#ff6a00]/10 backdrop-blur-sm px-4 py-1 rounded-full mb-4 ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-300`}
              >
                <span className="text-sm text-[#ff9500] font-medium">PROPUESTA PERSONALIZADA</span>
              </div>

              {/* Título principal con animación */}
              <h1
                className={`text-4xl md:text-6xl font-bold mb-6 text-white ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-500`}
              >
                Bienvenido, <span className="text-[#ff6a00]">{cliente.nombre}</span>
              </h1>

              {/* Subtítulo con animación */}
              <p
                className={`text-xl text-gray-300 mb-8 max-w-2xl mx-auto ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-700`}
              >
                Hemos preparado una propuesta personalizada de energía solar para optimizar su consumo energético y
                maximizar sus ahorros.
              </p>

              {/* Tarjetas de información con animación */}
              <div
                className={`grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} transition-all duration-700 delay-900`}
              >
                <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-4">
                    <Zap className="h-10 w-10 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">Sistema Optimizado</h3>
                  <p className="text-gray-400">
                    {cliente.sistemaRecomendado.capacidad} kWp de potencia diseñados específicamente para sus
                    necesidades.
                  </p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-4">
                    <DollarSign className="h-10 w-10 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">Ahorro Garantizado</h3>
                  <p className="text-gray-400">
                    B/. {formatNumber(cliente.financiero.ahorroAnual)} de ahorro anual estimado en su factura eléctrica.
                  </p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-4">
                    <Calendar className="h-10 w-10 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">Retorno Rápido</h3>
                  <p className="text-gray-400">
                    Recupere su inversión en tan solo {cliente.financiero.roi} años con beneficios a largo plazo.
                  </p>
                </div>
              </div>

              {/* Botón para ver la propuesta completa */}
              <div
                className={`${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} transition-all duration-700 delay-1100`}
              >
                <button
                  onClick={handleViewProposal}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-4 px-8 rounded-lg flex items-center gap-2 mx-auto text-lg group relative overflow-hidden"
                >
                  <span className="relative z-10">Ver Propuesta Completa</span>
                  <ChevronRight className="h-5 w-5 relative z-10 group-hover:translate-x-1 transition-transform" />
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity"></div>
                </button>
              </div>

              {/* Fecha de la propuesta */}
              <div
                className={`mt-12 text-gray-400 ${animationComplete ? "opacity-100" : "opacity-0"} transition-opacity duration-700 delay-1300`}
              >
                <p>Propuesta preparada el {cliente.fecha}</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Portada */}
          <div className="bg-white border-b border-gray-200">
            <div className="container mx-auto px-4 py-8">
              <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="inline-block bg-[#fff5f0] px-3 py-1 rounded-full mb-2">
                      <span className="text-xs text-[#ff6a00] font-medium">PROPUESTA PERSONALIZADA</span>
                    </div>
                    <h1 className="text-2xl font-bold text-gray-900">Recomendación de Sistema Solar Fotovoltaico</h1>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500 mb-1">CLIENTE</p>
                    <p className="text-lg font-bold text-gray-900">{cliente.nombre}</p>
                    <p className="text-xs text-gray-500 mt-1">{cliente.fecha}</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 mb-6">
                  <p className="text-gray-700 text-sm">
                    Estimado <span className="font-semibold">{cliente.nombre}</span>, hemos analizado detalladamente su
                    factura eléctrica de {cliente.facturaActual.distribuidor} correspondiente al mes de{" "}
                    {cliente.facturaActual.mes} de {cliente.facturaActual.año}, y queremos compartirle nuestra
                    recomendación profesional sobre la solución solar que mejor se adapta a sus necesidades energéticas.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setActiveSection("resumen")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      activeSection === "resumen"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Resumen Ejecutivo
                  </button>
                  <button
                    onClick={() => setActiveSection("analisis")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      activeSection === "analisis"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Análisis de Consumo
                  </button>
                  <button
                    onClick={() => setActiveSection("sistema")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      activeSection === "sistema"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Sistema Recomendado
                  </button>
                  <button
                    onClick={() => setActiveSection("financiero")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      activeSection === "financiero"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Análisis Financiero
                  </button>
                  <button
                    onClick={() => setActiveSection("pasos")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      activeSection === "pasos"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Próximos Pasos
                  </button>
                  <button
                    onClick={() => setActiveSection("documentos")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      activeSection === "documentos"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Documentos
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Contenido principal */}
          <main className="container mx-auto px-4 py-12">
            <div className="max-w-4xl mx-auto">
              {/* Resumen Ejecutivo */}
              {activeSection === "resumen" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Resumen Ejecutivo
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Capacidad del Sistema</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">{cliente.sistemaRecomendado.capacidad} kWp</p>
                        <p className="text-sm text-gray-600">Sistema fotovoltaico</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Ahorro Anual</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">
                          B/. {formatNumber(cliente.financiero.ahorroAnual)}
                        </p>
                        <p className="text-sm text-gray-600">Estimado primer año</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Retorno de Inversión</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">{cliente.financiero.roi} años</p>
                        <p className="text-sm text-gray-600">ROI estimado</p>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Puntos Clave</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Sistema dimensionado para su consumo máximo de{" "}
                          <strong>{formatNumber(cliente.patronConsumo.maximo)} kWh</strong> mensuales, optimizando su
                          inversión.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Aprovechamiento del programa de compensación por excedentes, vendiendo hasta un 25% de
                          excedente a B/. 0.08 por kWh.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Reducción significativa en el cargo por consumo de energía (B/.{" "}
                          {formatNumber(cliente.facturaActual.cargoPorConsumo)} en su factura actual).
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Mayor seguridad energética para su negocio y protección contra futuras alzas en las tarifas
                          eléctricas.
                        </span>
                      </li>
                    </ul>

                    <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-yellow-800 text-sm">
                        <strong>Nota importante:</strong> El cargo por demanda (B/.{" "}
                        {formatNumber(cliente.facturaActual.cargoPorDemanda)} en su factura actual) permanecerá, ya que
                        este depende de la potencia instantánea utilizada y no del consumo total.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("analisis")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Análisis de Consumo
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Análisis de Consumo */}
              {activeSection === "analisis" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <BarChart3 className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Análisis de su Consumo Eléctrico
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Observamos que su patrón de consumo muestra una variabilidad estacional significativa, con:
                    </p>

                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-0.5"></div>
                        <span>
                          Aproximadamente {cliente.patronConsumo.mesesAlto} meses de consumo elevado (picos de hasta{" "}
                          {formatNumber(cliente.patronConsumo.maximo)} kWh)
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-[#ff9500] mr-2 flex-shrink-0 mt-0.5"></div>
                        <span>Aproximadamente {cliente.patronConsumo.mesesBajo} meses de consumo más reducido</span>
                      </li>
                    </ul>

                    <p className="text-gray-700 mb-6">
                      Este patrón es común en empresas como la suya y representa una oportunidad importante para
                      optimizar su inversión en energía solar.
                    </p>

                    <div className="mb-8">
                      <h3 className="text-lg font-semibold mb-4 text-gray-900">Consumo Mensual (kWh)</h3>
                      <div className="bg-gray-50 p-4 rounded-lg overflow-hidden">
                        <div className="h-64 relative">
                          {/* Simulación de gráfico de barras */}
                          <div className="absolute bottom-0 left-0 w-full h-full flex items-end justify-between px-2">
                            {cliente.consumoMensual.map((value, index) => (
                              <div key={index} className="w-[7%] relative group">
                                <div
                                  className={`${
                                    index < cliente.patronConsumo.mesesAlto ? "bg-[#ff6a00]" : "bg-[#ff9500]"
                                  } rounded-t-sm transition-all duration-300 group-hover:opacity-80`}
                                  style={{
                                    height: `${(value / Math.max(...cliente.consumoMensual)) * 100}%`,
                                  }}
                                ></div>
                                <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                  {formatNumber(value)} kWh
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Líneas de referencia */}
                          <div className="absolute bottom-0 left-0 w-full h-full flex flex-col justify-between pointer-events-none">
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">
                                {formatNumber(Math.max(...cliente.consumoMensual))}
                              </span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">
                                {formatNumber(Math.max(...cliente.consumoMensual) * 0.75)}
                              </span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">
                                {formatNumber(Math.max(...cliente.consumoMensual) * 0.5)}
                              </span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">
                                {formatNumber(Math.max(...cliente.consumoMensual) * 0.25)}
                              </span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">0</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex justify-between mt-2 px-2">
                          {["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"].map(
                            (month, index) => (
                              <div key={index} className="text-xs text-gray-500 w-[7%] text-center">
                                {month}
                              </div>
                            ),
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#fff5f0] p-4 rounded-lg mb-6">
                      <h3 className="text-lg font-semibold mb-2 text-gray-900">Detalles de su Factura Actual</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Cargo por consumo:</p>
                          <p className="text-lg font-bold text-gray-900">
                            B/. {formatNumber(cliente.facturaActual.cargoPorConsumo)}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Cargo por demanda:</p>
                          <p className="text-lg font-bold text-gray-900">
                            B/. {formatNumber(cliente.facturaActual.cargoPorDemanda)}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-yellow-800 text-sm">
                        <strong>Nota importante:</strong> El cargo por demanda permanecerá, ya que este depende de la
                        potencia instantánea utilizada y no del consumo total. Los paneles solares reducirán
                        principalmente el cargo por consumo de energía.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("sistema")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Sistema Recomendado
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Sistema Recomendado */}
              {activeSection === "sistema" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Sistema Recomendado
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Nuestra Recomendación</h3>
                    <p className="text-gray-700 mb-6">
                      Después de evaluar cuidadosamente sus datos de consumo, recomendamos un sistema solar dimensionado
                      para su consumo máximo en lugar de un sistema basado en el promedio anual.
                    </p>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("consumo")}
                      >
                        <div className="flex items-center">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Maximización de ahorros durante todo el año</span>
                        </div>
                        {openAccordion === "consumo" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "consumo" && (
                        <div className="p-4 border-t border-gray-100">
                          <ul className="space-y-2 text-gray-700">
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>
                                Durante los meses de alto consumo, su sistema cubrirá la mayor parte de sus necesidades
                                energéticas.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>En los meses de menor consumo, generará excedentes que serán aprovechados.</span>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("excedentes")}
                      >
                        <div className="flex items-center">
                          <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">
                            Aprovechamiento del programa de compensación por excedentes
                          </span>
                        </div>
                        {openAccordion === "excedentes" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "excedentes" && (
                        <div className="p-4 border-t border-gray-100">
                          <ul className="space-y-2 text-gray-700">
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>
                                En Panamá, puede vender a la red hasta un 25% de excedente de energía a B/. 0.08 por
                                kWh.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>
                                Los excedentes generados durante los meses de menor consumo se convertirán en créditos
                                en su factura.
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("seguridad")}
                      >
                        <div className="flex items-center">
                          <Shield className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Mayor seguridad energética para su negocio</span>
                        </div>
                        {openAccordion === "seguridad" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "seguridad" && (
                        <div className="p-4 border-t border-gray-100">
                          <ul className="space-y-2 text-gray-700">
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>Un sistema más grande garantiza mayor independencia de la red eléctrica.</span>
                            </li>
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>
                                Protección contra futuras alzas en las tarifas eléctricas de{" "}
                                {cliente.facturaActual.distribuidor}.
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("roi")}
                      >
                        <div className="flex items-center">
                          <BarChart3 className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Optimización del retorno de inversión</span>
                        </div>
                        {openAccordion === "roi" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "roi" && (
                        <div className="p-4 border-t border-gray-100">
                          <ul className="space-y-2 text-gray-700">
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>
                                El programa de compensación por excedentes mejora significativamente el tiempo de
                                recuperación de su inversión.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                              <span>
                                La venta de excedentes convierte lo que podría ser capacidad subutilizada en ingresos
                                adicionales.
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>

                    <div className="bg-gray-50 p-6 rounded-lg">
                      <h3 className="text-lg font-semibold mb-4 text-gray-900">Especificaciones del Sistema</h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Componentes Principales</h4>
                          <ul className="space-y-2 text-gray-700">
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>
                                <strong>{cliente.sistemaRecomendado.paneles.cantidad} paneles</strong> solares de{" "}
                                {cliente.sistemaRecomendado.paneles.potencia}W (Tier 1)
                              </span>
                            </li>
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>
                                <strong>{cliente.sistemaRecomendado.inversores.cantidad} inversores</strong> trifásicos
                                de {cliente.sistemaRecomendado.inversores.potencia}kW
                              </span>
                            </li>
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>Sistema de monitoreo en tiempo real</span>
                            </li>
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>Estructura de montaje en aluminio anodizado</span>
                            </li>
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Características Técnicas</h4>
                          <ul className="space-y-2 text-gray-700">
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>
                                Capacidad total: <strong>{cliente.sistemaRecomendado.capacidad} kWp</strong>
                              </span>
                            </li>
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>
                                Generación anual estimada:{" "}
                                <strong>{formatNumber(cliente.sistemaRecomendado.generacionAnual)} kWh</strong>
                              </span>
                            </li>
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>
                                Área requerida:{" "}
                                <strong>~{formatNumber(cliente.sistemaRecomendado.areaRequerida)} m²</strong>
                              </span>
                            </li>
                            <li className="flex items-start">
                              <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                              <span>
                                Garantía de paneles: <strong>25 años</strong>
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="mt-8">
                      <h3 className="text-lg font-semibold mb-4 text-gray-900">Tecnología Utilizada</h3>

                      {/* Microinversores AP Systems */}
                      <div className="mb-8 bg-white p-6 rounded-lg border border-gray-200">
                        <div className="flex flex-col md:flex-row gap-6">
                          <div className="md:w-1/3 flex justify-center items-start">
                            <div className="bg-gray-100 p-4 rounded-lg w-full max-w-[250px] h-[250px] flex items-center justify-center">
                              {/* Aquí irá la imagen del microinversor */}
                              <div className="text-center text-gray-500">
                                <span className="block mb-2">Imagen del Microinversor</span>
                                <span className="text-sm">AP Systems</span>
                              </div>
                            </div>
                          </div>
                          <div className="md:w-2/3">
                            <h4 className="text-xl font-semibold mb-4 text-gray-900 flex items-center">
                              <Zap className="mr-2 h-5 w-5 text-[#ff6a00]" />
                              Microinversores AP Systems
                            </h4>

                            <div className="bg-[#fff5f0] p-4 rounded-lg mb-4">
                              <h5 className="font-medium text-gray-900 mb-2">¿Por qué elegimos AP Systems?</h5>
                              <ul className="space-y-2">
                                <li className="flex items-start">
                                  <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                  <span>Monitoreo individual de cada panel solar para máximo rendimiento</span>
                                </li>
                                <li className="flex items-start">
                                  <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                  <span>Mayor producción de energía incluso en condiciones de sombra parcial</span>
                                </li>
                                <li className="flex items-start">
                                  <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                  <span>Sistema más seguro con bajo voltaje DC</span>
                                </li>
                                <li className="flex items-start">
                                  <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                  <span>Diseño modular que facilita ampliaciones futuras del sistema</span>
                                </li>
                                <li className="flex items-start">
                                  <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                  <span>Garantía extendida de 12 años, líder en la industria</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Paneles Solares LONGi */}
                      <div className="mb-8 bg-white p-6 rounded-lg border border-gray-200">
                        <div className="flex flex-col md:flex-row gap-6">
                          <div className="md:w-1/3 flex justify-center items-start">
                            <div className="bg-gray-100 p-4 rounded-lg w-full max-w-[250px] h-[350px] flex items-center justify-center">
                              {/* Aquí irá la imagen del panel solar */}
                              <div className="text-center text-gray-500">
                                <span className="block mb-2">Imagen del Panel Solar</span>
                                <span className="text-sm">LONGi Solar Hi-MO X6</span>
                              </div>
                            </div>
                          </div>
                          <div className="md:w-2/3">
                            <h4 className="text-xl font-semibold mb-4 text-gray-900 flex items-center">
                              <Sun className="mr-2 h-5 w-5 text-[#ff6a00]" />
                              Tecnología Avanzada LONGi Solar Hi-MO X6
                            </h4>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div className="bg-white p-4 rounded-lg border border-gray-200">
                                <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                                  <div className="h-3 w-3 rounded-full bg-[#ff6a00] mr-2"></div>
                                  Diseño Anti-Polvo
                                </h5>
                                <p className="text-sm text-gray-700">
                                  Permite que el polvo se deslice naturalmente del módulo bajo la influencia de la
                                  gravedad y la lluvia.
                                </p>
                              </div>

                              <div className="bg-white p-4 rounded-lg border border-gray-200">
                                <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                                  <div className="h-3 w-3 rounded-full bg-[#ff6a00] mr-2"></div>
                                  Prevención de Sombras
                                </h5>
                                <p className="text-sm text-gray-700">
                                  Evita la obstrucción de luz incidente, garantizando un rendimiento óptimo de
                                  generación de energía.
                                </p>
                              </div>

                              <div className="bg-white p-4 rounded-lg border border-gray-200">
                                <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                                  <div className="h-3 w-3 rounded-full bg-[#ff6a00] mr-2"></div>
                                  Mejora de Rendimiento
                                </h5>
                                <p className="text-sm text-gray-700">
                                  Ganancia notable en generación de energía, reduciendo la frecuencia y costo de
                                  limpieza.
                                </p>
                              </div>

                              <div className="bg-white p-4 rounded-lg border border-gray-200">
                                <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                                  <div className="h-3 w-3 rounded-full bg-[#ff6a00] mr-2"></div>
                                  Fiabilidad Estructural
                                </h5>
                                <p className="text-sm text-gray-700">
                                  Marco patentado y técnicas avanzadas de sellado que garantizan durabilidad y capacidad
                                  de carga.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-center">
                      <button
                        onClick={() => setActiveSection("financiero")}
                        className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                      >
                        Ver Análisis Financiero
                        <ArrowRight className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Análisis Financiero */}
              {activeSection === "financiero" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <DollarSign className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Análisis Financiero
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Inversión Total</h3>
                    <p className="text-gray-700 mb-6">
                      La inversión total estimada para este sistema es de{" "}
                      <span className="font-semibold">B/. {formatNumber(cliente.financiero.inversionTotal)}</span>, que
                      incluye todos los componentes, la instalación y la puesta en marcha.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Ahorro Anual Estimado</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">
                          B/. {formatNumber(cliente.financiero.ahorroAnual)}
                        </p>
                        <p className="text-sm text-gray-600">Primer año</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Retorno de Inversión (ROI)</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">{cliente.financiero.roi} años</p>
                        <p className="text-sm text-gray-600">Estimado</p>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Proyección de Ahorros</h3>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Año
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Ahorro Anual (B/.)
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Ahorro Acumulado (B/.)
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              ROI (%)
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {cliente.financiero.proyeccion.map((item) => (
                            <tr key={item.año}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.año}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                B/. {formatNumber(item.ahorroAnual)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                B/. {formatNumber(item.ahorroAcumulado)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {item.roiPorcentaje}%
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800 text-sm">
                        <strong>Beneficios a largo plazo:</strong> Después de recuperar su inversión inicial, continuará
                        disfrutando de ahorros significativos en su factura eléctrica durante muchos años.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("pasos")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Próximos Pasos
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Próximos Pasos */}
              {activeSection === "pasos" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <ArrowRight className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Próximos Pasos
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Para avanzar con la implementación de su sistema solar, le invitamos a seguir estos sencillos
                      pasos:
                    </p>

                    <ul className="space-y-4">
                      <li className="flex items-start">
                        <div className="h-8 w-8 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-3">
                          1
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Aceptación de la Propuesta</h3>
                          <p className="text-gray-700">
                            Revise detenidamente los términos y condiciones de esta propuesta y confirme su aceptación.
                          </p>
                        </div>
                      </li>

                      <li className="flex items-start">
                        <div className="h-8 w-8 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-3">
                          2
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Firma del Contrato</h3>
                          <p className="text-gray-700">
                            Procederemos a la firma del contrato de suministro e instalación del sistema solar.
                          </p>
                        </div>
                      </li>

                      <li className="flex items-start">
                        <div className="h-8 w-8 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-3">
                          3
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Programación de la Instalación</h3>
                          <p className="text-gray-700">
                            Coordinaremos con usted la fecha y hora más conveniente para la instalación del sistema en
                            su propiedad.
                          </p>
                        </div>
                      </li>

                      <li className="flex items-start">
                        <div className="h-8 w-8 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-3">
                          4
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Puesta en Marcha y Monitoreo</h3>
                          <p className="text-gray-700">
                            Una vez instalado el sistema, realizaremos la puesta en marcha y le proporcionaremos acceso
                            a la plataforma de monitoreo en tiempo real.
                          </p>
                        </div>
                      </li>
                    </ul>

                    <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-blue-800 text-sm">
                        <strong>Soporte continuo:</strong> Estaremos a su disposición para brindarle soporte técnico y
                        resolver cualquier duda o inquietud que pueda surgir durante la vida útil del sistema.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("documentos")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Documentos
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Documentos */}
              {activeSection === "documentos" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <FileSpreadsheet className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Documentos
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">Aquí encontrará los documentos relevantes para su propuesta:</p>

                    <ul className="space-y-4">
                      <li className="flex items-center justify-between px-4 py-3 bg-gray-50 rounded-lg border border-gray-200">
                        <div className="flex items-center">
                          <FilePdf className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Propuesta en PDF</span>
                        </div>
                        <a
                          href="#"
                          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded-lg text-sm"
                        >
                          Descargar
                        </a>
                      </li>

                      <li className="flex items-center justify-between px-4 py-3 bg-gray-50 rounded-lg border border-gray-200">
                        <div className="flex items-center">
                          <FileSpreadsheet className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Términos y Condiciones</span>
                        </div>
                        <a
                          href="#"
                          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded-lg text-sm"
                        >
                          Ver
                        </a>
                      </li>

                      <li className="flex items-center justify-between px-4 py-3 bg-gray-50 rounded-lg border border-gray-200">
                        <div className="flex items-center">
                          <FileSpreadsheet className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Garantía del Sistema</span>
                        </div>
                        <a
                          href="#"
                          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded-lg text-sm"
                        >
                          Ver
                        </a>
                      </li>
                    </ul>

                    <div className="mt-6 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <p className="text-purple-800 text-sm">
                        <strong>Información adicional:</strong> Si requiere algún otro documento o información
                        adicional, no dude en ponerse en contacto con nosotros.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("contacto")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Contactar
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Contacto */}
              {activeSection === "contacto" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Phone className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Contacto
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Estamos a su disposición para responder cualquier pregunta o inquietud que pueda tener. No dude en
                      ponerse en contacto con nosotros a través de los siguientes medios:
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-gray-900">Información de Contacto</h3>
                        <ul className="space-y-2">
                          <li className="flex items-center">
                            <Phone className="h-4 w-4 text-[#ff6a00] mr-2" />
                            <span className="text-gray-700">Teléfono: {cliente.contacto.telefono}</span>
                          </li>
                          <li className="flex items-center">
                            <Phone className="h-4 w-4 text-[#ff6a00] mr-2" />
                            <span className="text-gray-700">Celular: {cliente.contacto.celular}</span>
                          </li>
                          <li className="flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4 text-[#ff6a00] mr-2"
                            >
                              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                              <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <span className="text-gray-700">Email: {cliente.contacto.email}</span>
                          </li>
                          <li className="flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4 text-[#ff6a00] mr-2"
                            >
                              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                              <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <span className="text-gray-700">
                              Email (Alternativo): {cliente.contacto.emailSecundario}
                            </span>
                          </li>
                        </ul>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-gray-900">Formulario de Contacto</h3>
                        <form className="space-y-4">
                          <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                              Nombre
                            </label>
                            <input
                              type="text"
                              id="name"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ff6a00] focus:ring-[#ff6a00] sm:text-sm"
                            />
                          </div>
                          <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                              Email
                            </label>
                            <input
                              type="email"
                              id="email"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ff6a00] focus:ring-[#ff6a00] sm:text-sm"
                            />
                          </div>
                          <div>
                            <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                              Mensaje
                            </label>
                            <textarea
                              id="message"
                              rows={4}
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ff6a00] focus:ring-[#ff6a00] sm:text-sm"
                            ></textarea>
                          </div>
                          <div>
                            <button
                              type="submit"
                              className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-2 px-4 rounded-lg"
                            >
                              Enviar Mensaje
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>

                    <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                      <p className="text-orange-800 text-sm">
                        <strong>Horario de atención:</strong> Nuestro horario de atención es de lunes a viernes de 9:00
                        a.m. a 6:00 p.m.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </>
      )}
    </div>
  )
}
