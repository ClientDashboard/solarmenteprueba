"use client"

import { useState, useEffect } from "react"
import {
  Sun,
  Zap,
  DollarSign,
  BarChart3,
  Calendar,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Download,
  Phone,
  Shield,
  Leaf,
  Wifi,
  PenToolIcon as Tool,
  Percent,
  ChevronRight,
} from "lucide-react"

export default function PropuestaCliente() {
  const [activeSection, setActiveSection] = useState("resumen")
  const [openAccordion, setOpenAccordion] = useState<string | null>("consumo")
  const [selectedPlan, setSelectedPlan] = useState<1 | 2>(1)
  const [showWelcome, setShowWelcome] = useState(true)
  const [animationComplete, setAnimationComplete] = useState(false)

  useEffect(() => {
    // Iniciar la animación después de cargar la página
    const timer = setTimeout(() => {
      setAnimationComplete(true)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id)
  }

  // Función para formatear números con separador de miles
  const formatNumber = (num: number): string => {
    return num.toLocaleString("es-PA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }

  // Datos mensuales de producción solar estimada
  const produccionMensual = [
    3200, // enero
    3100, // febrero
    3300, // marzo
    3150, // abril
    2900, // mayo
    2800, // junio
    2850, // julio
    2900, // agosto
    2950, // septiembre
    3050, // octubre
    3100, // noviembre
    3200, // diciembre
  ]

  // Consumo actual del cliente (constante en este caso)
  const consumoActual = Array(12).fill(2100)

  const handleViewProposal = () => {
    setShowWelcome(false)
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-[Mulish,sans-serif]">
      {/* Header con logo */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h1>
            <span className="ml-4 text-sm text-gray-500">Soluciones Energéticas Renovables</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 border border-gray-300 rounded-lg flex items-center gap-2 text-sm">
              <Download className="h-4 w-4" />
              Descargar PDF
            </button>
            <button className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-2 px-4 rounded-lg flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4" />
              Contactar
            </button>
          </div>
        </div>
      </header>

      {showWelcome ? (
        <div className="min-h-[calc(100vh-73px)] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center relative overflow-hidden pt-8">
          {/* Elementos decorativos de fondo */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full">
              {/* Círculos decorativos */}
              <div className="absolute top-[10%] left-[15%] w-64 h-64 rounded-full bg-[#ff6a00]/10 blur-3xl"></div>
              <div className="absolute bottom-[20%] right-[10%] w-80 h-80 rounded-full bg-[#ff9500]/10 blur-3xl"></div>
              <div className="absolute top-[40%] right-[30%] w-40 h-40 rounded-full bg-[#ff6a00]/5 blur-xl"></div>

              {/* Líneas de cuadrícula */}
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZGVmcz4KICA8cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgIDxwYXRoIGQ9Ik0gNDAgMCBMIDAgMCAwIDQwIiBmaWxsPSJub25lIiBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iMC41Ii8+CiAgPC9wYXR0ZXJuPgo8L2RlZnM+CjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiIC8+Cjwvc3ZnPg==')] opacity-10"></div>
            </div>
          </div>

          <div className="container mx-auto px-4 z-10 mt-8">
            <div className="max-w-4xl mx-auto text-center">
              {/* Icono de sol con animación */}
              <div className="flex justify-center mb-4">
                <div
                  className={`relative ${animationComplete ? "scale-100" : "scale-0"} transition-transform duration-700 ease-out`}
                >
                  <Sun className="h-16 w-16 text-[#ff6a00]" />
                  <div className="absolute inset-0 bg-[#ff6a00] rounded-full animate-ping opacity-20"></div>
                </div>
              </div>

              {/* Etiqueta de propuesta personalizada */}
              <div
                className={`inline-block bg-[#ff6a00]/10 backdrop-blur-sm px-4 py-1 rounded-full mb-3 ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-300`}
              >
                <span className="text-sm text-[#ff9500] font-medium">PROPUESTA PERSONALIZADA</span>
              </div>

              {/* Título principal con animación */}
              <h1
                className={`text-3xl md:text-5xl font-bold mb-4 text-white ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-500`}
              >
                Bienvenido, <span className="text-[#ff6a00]">FANTINA ISABEL</span>
              </h1>

              {/* Subtítulo con animación */}
              <p
                className={`text-lg text-gray-300 mb-6 max-w-2xl mx-auto ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"} transition-all duration-700 delay-700`}
              >
                Hemos preparado una propuesta personalizada de energía solar para optimizar su consumo energético y
                maximizar sus ahorros.
              </p>

              {/* Tarjetas de información con animación - VERSIÓN MÁS COMPACTA */}
              <div
                className={`grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 ${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} transition-all duration-700 delay-900`}
              >
                <div className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-lg border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-2">
                    <Zap className="h-8 w-8 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-base font-semibold text-white mb-1">Sistema Optimizado</h3>
                  <p className="text-sm text-gray-400">24.28 kWp de potencia diseñados para sus necesidades.</p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-lg border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-2">
                    <DollarSign className="h-8 w-8 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-base font-semibold text-white mb-1">Ahorro Garantizado</h3>
                  <p className="text-sm text-gray-400">B/. 8,050.54 de ahorro anual en su factura eléctrica.</p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-lg border border-gray-700 hover:border-[#ff6a00]/50 transition-colors group">
                  <div className="flex items-center justify-center mb-2">
                    <Calendar className="h-8 w-8 text-[#ff6a00] group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="text-base font-semibold text-white mb-1">Retorno Rápido</h3>
                  <p className="text-sm text-gray-400">Recupere su inversión en tan solo 3 años.</p>
                </div>
              </div>

              {/* Botón para ver la propuesta completa */}
              <div
                className={`${animationComplete ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} transition-all duration-700 delay-1100`}
              >
                <button
                  onClick={handleViewProposal}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2 mx-auto text-base group relative overflow-hidden"
                >
                  <span className="relative z-10">Ver Propuesta Completa</span>
                  <ChevronRight className="h-5 w-5 relative z-10 group-hover:translate-x-1 transition-transform" />
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity"></div>
                </button>
              </div>

              {/* Fecha de la propuesta */}
              <div
                className={`mt-8 text-gray-400 text-sm ${animationComplete ? "opacity-100" : "opacity-0"} transition-opacity duration-700 delay-1300`}
              >
                <p>Propuesta preparada el 12 de abril de 2025</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Navegación de secciones */}
          <div className="bg-white border-b border-gray-200">
            <div className="container mx-auto px-4 py-6">
              <div className="max-w-4xl mx-auto">
                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => setActiveSection("resumen")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "resumen"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Resumen Ejecutivo
                  </button>
                  <button
                    onClick={() => setActiveSection("analisis")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "analisis"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Análisis de Consumo
                  </button>
                  <button
                    onClick={() => setActiveSection("sistema")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "sistema"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Sistema Recomendado
                  </button>
                  <button
                    onClick={() => setActiveSection("financiero")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "financiero"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Análisis Financiero
                  </button>
                  <button
                    onClick={() => setActiveSection("planes")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "planes"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Planes de Pago
                  </button>
                  <button
                    onClick={() => setActiveSection("pasos")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeSection === "pasos"
                        ? "bg-[#ff6a00] text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Próximos Pasos
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Contenido principal */}
          <main className="container mx-auto px-4 py-12">
            <div className="max-w-4xl mx-auto">
              {/* Resumen Ejecutivo */}
              {activeSection === "resumen" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Resumen Ejecutivo
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Capacidad del Sistema</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">24.28 kW</p>
                        <p className="text-sm text-gray-600">Sistema fotovoltaico</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Ahorro Anual</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">B/. 8,050.54</p>
                        <p className="text-sm text-gray-600">Estimado primer año</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Retorno de Inversión</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">3 años</p>
                        <p className="text-sm text-gray-600">ROI estimado</p>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Puntos Clave</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Sistema dimensionado para su consumo mensual de <strong>2,100 kWh</strong>, con una producción
                          estimada de <strong>3,054.86 kWh</strong> mensuales.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Aprovechamiento del programa de compensación por excedentes, vendiendo el excedente de energía
                          a la red eléctrica.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Reducción significativa en el cargo por consumo de energía (B/. 458.97 en su factura actual).
                        </span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>
                          Mayor seguridad energética para su hogar y protección contra futuras alzas en las tarifas
                          eléctricas.
                        </span>
                      </li>
                    </ul>

                    <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-yellow-800 text-sm">
                        <strong>Nota importante:</strong> Con este sistema, usted podrá eliminar prácticamente su
                        factura eléctrica, con excepción de los cargos fijos, y generará más energía de la que consume
                        actualmente.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("analisis")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Análisis de Consumo
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Análisis de Consumo */}
              {activeSection === "analisis" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <BarChart3 className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Análisis de su Consumo Eléctrico
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Hemos analizado su patrón de consumo eléctrico y hemos diseñado un sistema que no solo cubrirá sus
                      necesidades actuales, sino que también generará excedentes que podrá vender a la red eléctrica.
                    </p>

                    <div className="mb-8">
                      <h3 className="text-lg font-semibold mb-4 text-gray-900">Consumo vs. Producción Mensual (kWh)</h3>
                      <div className="bg-gray-50 p-6 rounded-lg">
                        {/* Gráfico de barras simplificado */}
                        <div className="relative h-80 w-full">
                          {/* Líneas de referencia horizontales */}
                          <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">3,500</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">2,625</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">1,750</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">875</span>
                            </div>
                            <div className="border-b border-gray-200 relative h-0">
                              <span className="absolute -top-3 -left-14 text-xs text-gray-500">0</span>
                            </div>
                          </div>

                          {/* Barras del gráfico */}
                          <div className="absolute bottom-0 left-0 right-0 flex justify-between items-end h-full px-4">
                            {produccionMensual.map((produccion, index) => (
                              <div
                                key={index}
                                className="relative flex flex-col items-center group"
                                style={{ width: "7%" }}
                              >
                                {/* Barra de producción solar */}
                                <div
                                  className="w-full bg-[#ff6a00]"
                                  style={{
                                    height: `${(produccion / 3500) * 100}%`,
                                    minHeight: "4px",
                                  }}
                                ></div>

                                {/* Indicador de consumo actual */}
                                <div
                                  className="absolute w-full flex justify-center"
                                  style={{ bottom: `${(consumoActual[index] / 3500) * 100}%` }}
                                >
                                  <div className="h-3 w-3 bg-black rounded-full"></div>
                                </div>

                                {/* Tooltip */}
                                <div className="absolute bottom-full mb-2 bg-gray-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                                  Consumo: {formatNumber(consumoActual[index])} kWh
                                  <br />
                                  Producción: {formatNumber(produccion)} kWh
                                </div>

                                {/* Etiqueta de mes */}
                                <div className="absolute top-full mt-2 text-xs text-gray-500">
                                  {
                                    [
                                      "Ene",
                                      "Feb",
                                      "Mar",
                                      "Abr",
                                      "May",
                                      "Jun",
                                      "Jul",
                                      "Ago",
                                      "Sep",
                                      "Oct",
                                      "Nov",
                                      "Dic",
                                    ][index]
                                  }
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Leyenda */}
                        <div className="flex justify-center mt-12 gap-8">
                          <div className="flex items-center">
                            <div className="w-4 h-4 bg-[#ff6a00] mr-2"></div>
                            <span className="text-sm text-gray-700">Producción Solar</span>
                          </div>
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-black rounded-full mr-2"></div>
                            <span className="text-sm text-gray-700">Consumo Actual</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#fff5f0] p-4 rounded-lg mb-6">
                      <h3 className="text-lg font-semibold mb-2 text-gray-900">Detalles de su Factura Actual</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Consumo mensual:</p>
                          <p className="text-lg font-bold text-gray-900">2,100 kWh</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Factura mensual:</p>
                          <p className="text-lg font-bold text-gray-900">B/. 446.36</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Tarifa de energía:</p>
                          <p className="text-lg font-bold text-gray-900">B/. 0.21961/kWh</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Cargo por energía:</p>
                          <p className="text-lg font-bold text-gray-900">B/. 458.97</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800 text-sm">
                        <strong>Beneficio clave:</strong> Su sistema solar producirá aproximadamente{" "}
                        <strong>3,054.86 kWh</strong> mensuales, lo que supera su consumo actual de{" "}
                        <strong>2,100 kWh</strong>. Esto significa que no solo eliminará su factura de electricidad,
                        sino que también generará ingresos adicionales por la venta de excedentes a la red eléctrica.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("sistema")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Sistema Recomendado
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Sistema Recomendado */}
              {activeSection === "sistema" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Sistema Recomendado
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Nuestra Recomendación</h3>
                    <p className="text-gray-700 mb-6">
                      Después de evaluar cuidadosamente sus datos de consumo, recomendamos un sistema solar de alta
                      eficiencia que maximizará su ahorro y aprovechará al máximo el espacio disponible en su techo.
                    </p>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("especificaciones")}
                      >
                        <div className="flex items-center">
                          <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Especificaciones del Sistema</span>
                        </div>
                        {openAccordion === "especificaciones" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "especificaciones" && (
                        <div className="p-4 border-t border-gray-100">
                          <div className="grid grid-cols-1 gap-6">
                            {/* Sección de Microinversores */}
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="flex flex-col justify-center">
                                  <div className="flex items-center mb-4">
                                    <h4 className="font-medium text-gray-900">Microinversores AP Systems</h4>
                                    <img
                                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/APsystems-logo-primary-gT4XhVmnEtEbpLTElQ7HFF4b4DqeM7.png"
                                      alt="AP Systems Logo"
                                      className="h-6 ml-2"
                                    />
                                  </div>
                                  <div className="bg-pink-50 p-4 rounded-lg">
                                    <h5 className="font-medium text-gray-900 mb-2">¿Por qué elegimos AP Systems?</h5>
                                    <ul className="space-y-2">
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Monitoreo individual de cada panel solar para máximo rendimiento
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Mayor producción de energía incluso en condiciones de sombra parcial
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">Sistema más seguro con bajo voltaje DC</span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Diseño modular que facilita ampliaciones futuras del sistema
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                                        <span className="text-sm">
                                          Garantía extendida de 12 años, líder en la industria
                                        </span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="flex items-center justify-center">
                                  <img
                                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/APsystems_DS3-2022-BC-ScyxNgaBvDducFdQ3t1dJoeYTEgT54.png"
                                    alt="Microinversor AP Systems DS3"
                                    className="max-w-full h-auto max-h-64"
                                  />
                                </div>
                              </div>
                            </div>

                            {/* Sección de Paneles Solares */}
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <h4 className="font-medium text-gray-900 mb-4 text-center">
                                Tecnología Avanzada LONGi Solar Hi-MO X6
                              </h4>
                              <div className="flex justify-center mb-6">
                                <img
                                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-04-12%20at%207.39.03%E2%80%AFPM-rjbKDBHeFwydWCtaElAXqKD3PM.png"
                                  alt="Panel Solar LONGi"
                                  className="max-w-full h-auto max-h-96"
                                />
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <div className="bg-white p-3 rounded-lg border border-gray-200">
                                  <div className="flex justify-center mb-2">
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      className="h-6 w-6 text-[#ff6a00]"
                                      fill="none"
                                      viewBox="0 0 24 24"
                                      stroke="currentColor"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                                      />
                                    </svg>
                                  </div>
                                  <h5 className="font-medium text-gray-900 text-center mb-1">Diseño Anti-Polvo</h5>
                                  <p className="text-xs text-gray-600 text-center">
                                    Permite que el polvo se deslice naturalmente del módulo bajo la influencia de la
                                    gravedad y la lluvia.
                                  </p>
                                </div>
                                <div className="bg-white p-3 rounded-lg border border-gray-200">
                                  <div className="flex justify-center mb-2">
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      className="h-6 w-6 text-[#ff6a00]"
                                      fill="none"
                                      viewBox="0 0 24 24"
                                      stroke="currentColor"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                                      />
                                    </svg>
                                  </div>
                                  <h5 className="font-medium text-gray-900 text-center mb-1">Prevención de Sombras</h5>
                                  <p className="text-xs text-gray-600 text-center">
                                    Evita la obstrucción de luz incidente, garantizando un rendimiento óptimo de
                                    generación de energía.
                                  </p>
                                </div>
                                <div className="bg-white p-3 rounded-lg border border-gray-200">
                                  <div className="flex justify-center mb-2">
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      className="h-6 w-6 text-[#ff6a00]"
                                      fill="none"
                                      viewBox="0 0 24 24"
                                      stroke="currentColor"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                                      />
                                    </svg>
                                  </div>
                                  <h5 className="font-medium text-gray-900 text-center mb-1">Mejora de Rendimiento</h5>
                                  <p className="text-xs text-gray-600 text-center">
                                    Ganancia notable en generación de energía, reduciendo la frecuencia y costo de
                                    limpieza.
                                  </p>
                                </div>
                                <div className="bg-white p-3 rounded-lg border border-gray-200">
                                  <div className="flex justify-center mb-2">
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      className="h-6 w-6 text-[#ff6a00]"
                                      fill="none"
                                      viewBox="0 0 24 24"
                                      stroke="currentColor"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                                      />
                                    </svg>
                                  </div>
                                  <h5 className="font-medium text-gray-900 text-center mb-1">Fiabilidad Estructural</h5>
                                  <p className="text-xs text-gray-600 text-center">
                                    Marco patentado y técnicas avanzadas de sellado que garantizan durabilidad y
                                    capacidad de carga.
                                  </p>
                                </div>
                              </div>
                            </div>

                            {/* Componentes y Características Técnicas */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                              <div>
                                <h4 className="font-medium text-gray-700 mb-2">Componentes Principales</h4>
                                <ul className="space-y-2 text-gray-700">
                                  <li className="flex items-start">
                                    <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                    <span>
                                      <strong>41 paneles</strong> solares de 585W (LONGI/ERA)
                                    </span>
                                  </li>
                                  <li className="flex items-start">
                                    <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                    <span>
                                      <strong>13 microinversores</strong> AP/DS3D-MX
                                    </span>
                                  </li>
                                  <li className="flex items-start">
                                    <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                    <span>Sistema de monitoreo WiFi 24/7</span>
                                  </li>
                                  <li className="flex items-start">
                                    <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                    <span>Estructura de montaje en aluminio anodizado</span>
                                  </li>
                                </ul>
                              </div>

                              <div>
                                <h4 className="font-medium text-gray-700 mb-2">Características Técnicas</h4>
                                <ul className="space-y-2 text-gray-700">
                                  <li className="flex items-start">
                                    <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                    <span>
                                      Capacidad total: <strong>24.28 kW</strong>
                                    </span>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("garantias")}
                      >
                        <div className="flex items-center">
                          <Shield className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Garantías y Mantenimiento</span>
                        </div>
                        {openAccordion === "garantias" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "garantias" && (
                        <div className="p-4 border-t border-gray-100">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-medium text-gray-700 mb-2">Garantías</h4>
                              <ul className="space-y-2 text-gray-700">
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    <strong>30 años</strong> en paneles solares
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    <strong>15 años</strong> en estructura de montaje
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    <strong>12 años</strong> en inversores
                                  </span>
                                </li>
                              </ul>
                            </div>

                            <div>
                              <h4 className="font-medium text-gray-700 mb-2">Mantenimiento y Monitoreo</h4>
                              <ul className="space-y-2 text-gray-700">
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    Monitoreo WiFi 24/7 <strong>(primer año gratis)</strong>
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    Mantenimiento anual: <strong>B/. 80</strong> (primer año gratis)
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>Soporte técnico durante toda la vida útil del sistema</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="mb-8">
                      <button
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={() => toggleAccordion("beneficios")}
                      >
                        <div className="flex items-center">
                          <Leaf className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <span className="font-medium text-gray-900">Beneficios Ambientales</span>
                        </div>
                        {openAccordion === "beneficios" ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>

                      {openAccordion === "beneficios" && (
                        <div className="p-4 border-t border-gray-100">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-medium text-gray-700 mb-2">Reducción de Impacto Ambiental</h4>
                              <ul className="space-y-2 text-gray-700">
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    Reducción de CO₂: <strong>22.20 toneladas</strong>
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>
                                    Reducción de consumo de petróleo: <strong>2,289.03 galones</strong>
                                  </span>
                                </li>
                              </ul>
                            </div>

                            <div>
                              <h4 className="font-medium text-gray-700 mb-2">Beneficios Adicionales</h4>
                              <ul className="space-y-2 text-gray-700">
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>Contribución a la reducción de la huella de carbono</span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>Promoción de energías limpias y renovables</span>
                                </li>
                                <li className="flex items-start">
                                  <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                                  <span>Independencia energética</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="bg-gray-50 p-6 rounded-lg">
                      <h3 className="text-lg font-semibold mb-4 text-gray-900">Características Adicionales</h3>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-white p-4 rounded-lg border border-gray-200">
                          <div className="flex items-center mb-2">
                            <Wifi className="h-5 w-5 text-[#ff6a00] mr-2" />
                            <h4 className="font-medium text-gray-900">Monitoreo WiFi</h4>
                          </div>
                          <p className="text-sm text-gray-600">
                            Monitoree la producción de su sistema desde cualquier lugar a través de una aplicación
                            móvil.
                          </p>
                        </div>

                        <div className="bg-white p-4 rounded-lg border border-gray-200">
                          <div className="flex items-center mb-2">
                            <Tool className="h-5 w-5 text-[#ff6a00] mr-2" />
                            <h4 className="font-medium text-gray-900">Mantenimiento</h4>
                          </div>
                          <p className="text-sm text-gray-600">
                            Servicio de mantenimiento anual para garantizar el óptimo rendimiento de su sistema.
                          </p>
                        </div>

                        <div className="bg-white p-4 rounded-lg border border-gray-200">
                          <div className="flex items-center mb-2">
                            <Percent className="h-5 w-5 text-[#ff6a00] mr-2" />
                            <h4 className="font-medium text-gray-900">100% de Ahorro</h4>
                          </div>
                          <p className="text-sm text-gray-600">
                            Elimine completamente su factura de electricidad y genere ingresos adicionales.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("financiero")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Análisis Financiero
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Análisis Financiero */}
              {activeSection === "financiero" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <DollarSign className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Análisis Financiero
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Inversión y Retorno</h3>
                    <p className="text-gray-700 mb-6">
                      La inversión total para su sistema solar de 24.28 kW es de <strong>B/. 24,280.00</strong>, con un
                      retorno de inversión estimado en tan solo <strong>3 años</strong>.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Inversión Total</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">B/. 24,280.00</p>
                        <p className="text-sm text-gray-600">Sistema completo instalado</p>
                      </div>

                      <div className="bg-[#fff5f0] p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                          <h3 className="font-semibold text-gray-900">Ahorro Mensual</h3>
                        </div>
                        <p className="text-2xl font-bold text-[#ff6a00]">B/. 670.88</p>
                        <p className="text-sm text-gray-600">Promedio mensual</p>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Proyección de Ahorros</h3>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Año
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Ahorro Anual (B/.)
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Ahorro Acumulado (B/.)
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              ROI (%)
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 8,050.54</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 8,050.54</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">33%</td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 8,292.06</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 16,342.60</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">67%</td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">3</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 8,540.82</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 24,883.42</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">102%</td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">5</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 9,061.05</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 42,985.29</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">177%</td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">10</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 10,500.82</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 94,268.35</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">388%</td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">25</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 16,101.08</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">B/. 303,775.50</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1251%</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800 text-sm">
                        <strong>Beneficios a largo plazo:</strong> Después de recuperar su inversión inicial en el año
                        3, continuará disfrutando de ahorros significativos durante los próximos 25+ años de vida útil
                        del sistema.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("planes")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Planes de Pago
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Planes de Pago */}
              {activeSection === "planes" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <DollarSign className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Planes de Pago
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Ofrecemos diferentes opciones de pago para que pueda elegir la que mejor se adapte a sus
                      necesidades financieras.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div
                        className={`bg-white p-6 rounded-xl border-2 ${selectedPlan === 1 ? "border-[#ff6a00]" : "border-gray-200"} transition-colors cursor-pointer hover:border-[#ff6a00]/70`}
                        onClick={() => setSelectedPlan(1)}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">Plan Estándar</h3>
                            <p className="text-sm text-gray-600">Pago único con descuento</p>
                          </div>
                          <div className="h-6 w-6 rounded-full border-2 flex items-center justify-center">
                            {selectedPlan === 1 && <div className="h-3 w-3 rounded-full bg-[#ff6a00]"></div>}
                          </div>
                        </div>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-[#ff6a00]">B/. 24,280.00</span>
                          <span className="text-sm text-gray-500 ml-2">pago único</span>
                        </div>
                        <ul className="space-y-2 mb-4">
                          <li className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>5% de descuento por pago al contado</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Instalación prioritaria</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Mantenimiento gratuito por 2 años</span>
                          </li>
                        </ul>
                        <div className="p-3 bg-gray-50 rounded-lg text-sm text-gray-600">
                          Ahorro total: <strong>B/. 1,214.00</strong> comparado con el precio regular
                        </div>
                      </div>

                      <div
                        className={`bg-white p-6 rounded-xl border-2 ${selectedPlan === 2 ? "border-[#ff6a00]" : "border-gray-200"} transition-colors cursor-pointer hover:border-[#ff6a00]/70`}
                        onClick={() => setSelectedPlan(2)}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">Plan Financiado</h3>
                            <p className="text-sm text-gray-600">Pagos mensuales cómodos</p>
                          </div>
                          <div className="h-6 w-6 rounded-full border-2 flex items-center justify-center">
                            {selectedPlan === 2 && <div className="h-3 w-3 rounded-full bg-[#ff6a00]"></div>}
                          </div>
                        </div>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-[#ff6a00]">B/. 674.44</span>
                          <span className="text-sm text-gray-500 ml-2">/mes</span>
                        </div>
                        <ul className="space-y-2 mb-4">
                          <li className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Financiamiento a 48 meses (4 años)</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Sin pago inicial</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Tasa de interés preferencial del 7.5%</span>
                          </li>
                        </ul>
                        <div className="p-3 bg-green-50 rounded-lg text-sm text-green-700">
                          <strong>¡Ahorro inmediato!</strong> Su pago mensual es menor que su factura actual de
                          electricidad
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#fff5f0] p-4 rounded-lg mb-6">
                      <h3 className="text-lg font-semibold mb-2 text-gray-900">Comparación de Flujo de Caja</h3>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-white">
                            <tr>
                              <th
                                scope="col"
                                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Concepto
                              </th>
                              <th
                                scope="col"
                                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Sin Sistema Solar
                              </th>
                              <th
                                scope="col"
                                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Con Plan Financiado
                              </th>
                              <th
                                scope="col"
                                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Ahorro
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Pago mensual</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">B/. 446.36</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">B/. 674.44</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-red-500">-B/. 228.08</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Pago a 4 años</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">B/. 21,425.28</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">B/. 32,373.12</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-red-500">-B/. 10,947.84</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Pago a 25 años</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">B/. 133,908.00</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">B/. 32,373.12</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-green-500">+B/. 101,534.88</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-blue-800 text-sm">
                        <strong>Nota importante:</strong> Aunque el pago mensual inicial es mayor que su factura actual,
                        después de 4 años sus pagos se reducen a cero, mientras que sin sistema solar seguiría pagando
                        indefinidamente. El ahorro a largo plazo es sustancial.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={() => setActiveSection("pasos")}
                      className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                    >
                      Ver Próximos Pasos
                      <ArrowRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Próximos Pasos */}
              {activeSection === "pasos" && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                    <ArrowRight className="mr-2 h-6 w-6 text-[#ff6a00]" />
                    Próximos Pasos
                  </h2>

                  <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                    <p className="text-gray-700 mb-6">
                      Para avanzar con la implementación de su sistema solar, le invitamos a seguir estos sencillos
                      pasos:
                    </p>

                    <div className="space-y-6 mb-8">
                      <div className="flex items-start">
                        <div className="h-10 w-10 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-4 flex-shrink-0">
                          1
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg flex-grow">
                          <h3 className="font-semibold text-gray-900 mb-2">Aceptación de la Propuesta</h3>
                          <p className="text-gray-700">
                            Revise detenidamente los términos y condiciones de esta propuesta y confirme su aceptación
                            mediante la firma del contrato.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <div className="h-10 w-10 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-4 flex-shrink-0">
                          2
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg flex-grow">
                          <h3 className="font-semibold text-gray-900 mb-2">Inspección Técnica</h3>
                          <p className="text-gray-700">
                            Nuestro equipo técnico realizará una visita a su propiedad para verificar las condiciones
                            del techo y confirmar los detalles de la instalación.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <div className="h-10 w-10 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-4 flex-shrink-0">
                          3
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg flex-grow">
                          <h3 className="font-semibold text-gray-900 mb-2">Trámites y Permisos</h3>
                          <p className="text-gray-700">
                            Nos encargamos de todos los trámites necesarios con la empresa distribuidora de electricidad
                            y las autoridades competentes.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <div className="h-10 w-10 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-4 flex-shrink-0">
                          4
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg flex-grow">
                          <h3 className="font-semibold text-gray-900 mb-2">Instalación</h3>
                          <p className="text-gray-700">
                            Programaremos la instalación de su sistema solar en la fecha más conveniente para usted. El
                            proceso de instalación toma aproximadamente 2-3 días.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <div className="h-10 w-10 rounded-full bg-[#ff6a00]/10 text-[#ff6a00] flex items-center justify-center mr-4 flex-shrink-0">
                          5
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg flex-grow">
                          <h3 className="font-semibold text-gray-900 mb-2">Puesta en Marcha y Capacitación</h3>
                          <p className="text-gray-700">
                            Una vez instalado el sistema, realizaremos la puesta en marcha y le proporcionaremos una
                            capacitación completa sobre su funcionamiento y monitoreo.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#fff5f0] p-4 rounded-lg mb-6">
                      <h3 className="text-lg font-semibold mb-2 text-gray-900">Cronograma Estimado</h3>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-white">
                            <tr>
                              <th
                                scope="col"
                                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Etapa
                              </th>
                              <th
                                scope="col"
                                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Duración
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Firma de contrato</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">1 día</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Inspección técnica</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">1-2 días</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Trámites y permisos</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">2-3 semanas</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Instalación</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">2-3 días</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">Puesta en marcha</td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">1 día</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800 text-sm">
                        <strong>Soporte continuo:</strong> Estaremos a su disposición para brindarle soporte técnico y
                        resolver cualquier duda o inquietud que pueda surgir durante la vida útil del sistema.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2">
                      Contactar Ahora
                      <Phone className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </main>

          {/* Footer */}
          <footer className="bg-gray-50 border-t border-gray-200 py-8">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto text-center">
                <h2 className="text-xl font-bold mb-4">
                  Solar<span className="text-[#ff6a00]">Mente</span>
                  <span className="text-[#ff6a00] font-light">.AI</span>
                </h2>
                <p className="text-gray-600 mb-6">Soluciones Energéticas Renovables con Inteligencia Artificial</p>
                <div className="flex justify-center space-x-4 mb-6">
                  <a
                    href="https://www.facebook.com/SolarMenteAI/"
                    className="text-gray-500 hover:text-[#ff6a00] transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                    </svg>
                  </a>
                  <a href="#" className="text-gray-500 hover:text-[#ff6a00] transition-colors">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                    </svg>
                  </a>
                  <a href="#" className="text-gray-500 hover:text-[#ff6a00] transition-colors">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                    </svg>
                  </a>
                </div>
                <p className="text-sm text-gray-500">© 2025 SolarMente. Todos los derechos reservados.</p>
              </div>
            </div>
          </footer>
        </>
      )}
    </div>
  )
}
