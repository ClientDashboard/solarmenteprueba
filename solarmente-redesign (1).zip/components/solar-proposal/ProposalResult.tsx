"use client"

import type { ProposalData } from "./types"
import PropuestaCliente from "./PropuestaCliente"

interface ProposalResultProps {
  data: ProposalData
}

export default function ProposalResult({ data }: ProposalResultProps) {
  return <PropuestaCliente data={data} />
}
