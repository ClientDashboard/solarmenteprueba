"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  ChevronRight,
  ChevronLeft,
  Zap,
  Sun,
  DollarSign,
  Home,
  CalendarDays,
  BarChart3,
  Shield,
  ArrowRight,
  Calendar,
  User,
  Hash,
  CreditCard,
  Bolt,
  FileText,
} from "lucide-react"

// Componente para las diapositivas
const Slide = ({ children, className = "" }) => {
  return (
    <div className={`min-h-screen w-full flex flex-col justify-center items-center p-6 md:p-12 ${className}`}>
      {children}
    </div>
  )
}

// Modificar el componente SolarPanelBackground para eliminar los puntos de energía y la línea diagonal
const SolarPanelBackground = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Grid de paneles solares */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
          <pattern id="solarpanel" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <rect x="0" y="0" width="20" height="20" fill="none" stroke="rgba(100, 100, 100, 0.2)" strokeWidth="0.5" />
            <line x1="0" y1="5" x2="20" y2="5" stroke="rgba(100, 100, 100, 0.1)" strokeWidth="0.3" />
            <line x1="0" y1="10" x2="20" y2="10" stroke="rgba(100, 100, 100, 0.1)" strokeWidth="0.3" />
            <line x1="0" y1="15" x2="20" y2="15" stroke="rgba(100, 100, 100, 0.1)" strokeWidth="0.3" />
            <line x1="5" y1="0" x2="5" y2="20" stroke="rgba(100, 100, 100, 0.1)" strokeWidth="0.3" />
            <line x1="10" y1="0" x2="10" y2="20" stroke="rgba(100, 100, 100, 0.1)" strokeWidth="0.3" />
            <line x1="15" y1="0" x2="15" y2="20" stroke="rgba(100, 100, 100, 0.1)" strokeWidth="0.3" />
          </pattern>
          <rect x="0" y="0" width="100%" height="100%" fill="url(#solarpanel)" />
        </svg>
      </div>

      {/* Líneas naranjas animadas horizontales */}
      {[...Array(6)].map((_, i) => (
        <div
          key={`h-line-${i}`}
          className="absolute h-[1px] bg-gradient-to-r from-transparent via-[#ff6a00]/40 to-transparent"
          style={{
            top: `${15 + i * 12}%`,
            left: "0",
            width: "100%",
            animation: `flowHorizontal ${8 + i * 2}s linear infinite ${i * 0.5}s`,
          }}
        />
      ))}

      {/* Líneas naranjas animadas verticales */}
      {[...Array(6)].map((_, i) => (
        <div
          key={`v-line-${i}`}
          className="absolute w-[1px] bg-gradient-to-b from-transparent via-[#ff6a00]/40 to-transparent"
          style={{
            left: `${15 + i * 12}%`,
            top: "0",
            height: "100%",
            animation: `flowVertical ${8 + i * 2}s linear infinite ${i * 0.5}s`,
          }}
        />
      ))}
    </div>
  )
}

// Componente para las tarjetas de estadísticas
const StatCard = ({ icon: Icon, value, label }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5 text-center relative overflow-hidden">
      {/* Fondo diagonal en tono melocotón claro */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-[#fff5f0] z-0"></div>

      <div className="mb-4 flex justify-center relative z-10">
        <div className="w-12 h-12 rounded-full bg-[#ff6a00] flex items-center justify-center">
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>

      <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1 relative z-10">{value}</h3>
      <p className="text-sm text-gray-600 relative z-10">{label}</p>

      {/* Puntos decorativos */}
      <div className="absolute top-4 left-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
      <div className="absolute bottom-4 right-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
    </div>
  )
}

// Componente para las tarjetas de proyectos
const ProjectCard = ({ image, title, capacity, description }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden group transition-all duration-300 hover:shadow-lg h-full flex flex-col">
      <div className="h-48 overflow-hidden relative">
        <div
          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700 bg-cover bg-center"
          style={{ backgroundImage: `url(${image})` }}
        ></div>
        <div className="absolute top-3 right-3 bg-[#ff6a00] text-white text-xs font-medium px-2 py-1 rounded-full">
          {capacity}
        </div>
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
        <p className="text-sm text-gray-600 flex-grow">{description}</p>
      </div>
    </div>
  )
}

// Modificar el componente PdfViewer para que abra el PDF directamente en una nueva pestaña
const PdfViewer = ({ title, pdfUrl }) => {
  return (
    <div className="mt-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-medium text-gray-700 flex items-center">
          <FileText className="h-4 w-4 text-[#ff6a00] mr-2" />
          {title}
        </h4>
        <a
          href={pdfUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-white bg-[#ff6a00] hover:bg-[#ff9500] px-3 py-1.5 rounded-lg text-xs font-medium flex items-center transition-colors"
        >
          <FileText className="h-3 w-3 mr-1.5" />
          Ver PDF
        </a>
      </div>
    </div>
  )
}

// Modificar el componente BillCard para agregar la sección de comparación de pagos y tabla de consumo
const BillCard = ({
  title,
  client,
  amount,
  date,
  nac,
  amountLabel,
  beforeAmount,
  afterAmount,
  consumptionHistory = [], // Array de objetos con {month, kWh}
  pdfUrl,
}) => {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 h-full flex flex-col">
      <div className="p-5 flex-grow flex flex-col">
        {/* Sección de cliente */}
        <div className="mb-4 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <User className="h-4 w-4 text-[#ff6a00]" />
            <span className="text-sm font-medium text-gray-700">Cliente</span>
          </div>
          <p className="text-base font-semibold text-gray-900">{client}</p>
        </div>

        {/* Sección de NAC */}
        <div className="mb-4 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <Hash className="h-4 w-4 text-[#ff6a00]" />
            <span className="text-sm font-medium text-gray-700">NAC</span>
          </div>
          <p className="text-base text-gray-900">{nac}</p>
        </div>

        {/* Sección de fecha */}
        <div className="mb-4 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="h-4 w-4 text-[#ff6a00]" />
            <span className="text-sm font-medium text-gray-700">Fecha de emisión</span>
          </div>
          <p className="text-base text-gray-900">{date}</p>
        </div>

        {/* NUEVA SECCIÓN: Comparación de pagos */}
        <div className="mb-4 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="h-4 w-4 text-[#ff6a00]" />
            <span className="text-sm font-medium text-gray-700">Comparación de pagos</span>
          </div>
          <div className="flex justify-between items-center">
            <div>
              <p className="text-xs text-gray-500">Antes:</p>
              <p className="text-sm font-medium text-gray-900">{beforeAmount || "N/A"}</p>
            </div>
            <ArrowRight className="h-4 w-4 text-gray-400 mx-2" />
            <div>
              <p className="text-xs text-gray-500">Ahora:</p>
              <p className="text-sm font-medium text-green-600">{afterAmount || "N/A"}</p>
            </div>
          </div>
        </div>

        {/* NUEVA SECCIÓN: Historial de consumo en kWh */}
        {consumptionHistory && consumptionHistory.length > 0 && (
          <div className="mb-4 pb-4 border-b border-gray-100">
            <div className="flex items-center gap-2 mb-2">
              <Bolt className="h-4 w-4 text-[#ff6a00]" />
              <span className="text-sm font-medium text-gray-700">Historial de consumo</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr>
                    <th className="text-left text-gray-500 py-1">Fecha</th>
                    <th className="text-right text-gray-500 py-1">kWh</th>
                  </tr>
                </thead>
                <tbody>
                  {consumptionHistory.map((item, index) => (
                    <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : ""}>
                      <td className="py-1">{item.month}</td>
                      <td className="text-right py-1 font-medium">{item.kWh}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Espacio flexible para empujar el total a pagar hacia abajo */}
        <div className="flex-grow"></div>

        {/* Sección de monto - ahora con mt-auto para alinear al final */}
        <div className="mt-auto">
          <div className="flex items-center gap-2 mb-2">
            <CreditCard className="h-4 w-4 text-[#ff6a00]" />
            <span className="text-sm font-medium text-gray-700">{amountLabel || "Total a pagar"}</span>
          </div>
          <p className="text-xl font-bold text-gray-900">{amount}</p>
        </div>

        {/* Sección de PDF */}
        {pdfUrl && <PdfViewer title="Detalles de la factura" pdfUrl={pdfUrl} />}
      </div>
    </div>
  )
}

export default function PresentacionClient() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)
  const slidesRef = useRef([])
  const router = useRouter()

  const totalSlides = 5

  // Datos de historial de consumo para cada cliente
  const almacenadoraHistory = [
    { month: "06/03/2025", kWh: "0" },
    { month: "04/02/2025", kWh: "350" },
    { month: "04/01/2025", kWh: "17,150" },
    { month: "05/12/2024", kWh: "18,550" },
    { month: "05/11/2024", kWh: "20,650" },
    { month: "05/10/2024", kWh: "22,050" },
    { month: "05/09/2024", kWh: "23,100" },
  ]

  // Actualizar el historial de consumo para VALLADARES INTERNACIONAL, S.A.
  const valladaresHistory = [
    { month: "26/03/2025", kWh: "0" },
    { month: "23/02/2025", kWh: "6,240" },
    { month: "25/01/2025", kWh: "7,080" },
    { month: "25/12/2024", kWh: "7,920" },
  ]

  const g4History = [
    { month: "27/03/2025", kWh: "0" },
    { month: "25/02/2025", kWh: "1,306" },
    { month: "28/01/2025", kWh: "1,576" },
    { month: "28/12/2024", kWh: "1,593" },
    { month: "27/11/2024", kWh: "1,439" },
    { month: "28/10/2024", kWh: "1,602" },
    { month: "27/09/2024", kWh: "1,611" },
  ]

  useEffect(() => {
    // Efecto para la animación inicial
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 500)

    // Manejar navegación con teclado
    const handleKeyDown = (e) => {
      if (e.key === "ArrowRight" || e.key === "ArrowDown") {
        nextSlide()
      } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
        prevSlide()
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    return () => {
      clearTimeout(timer)
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])

  // Añadir estilos para las animaciones
  useEffect(() => {
    // Crear estilos para las animaciones
    const style = document.createElement("style")
    style.textContent = `
  @keyframes flowHorizontal {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
  }
  
  @keyframes flowVertical {
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
  }
`
    document.head.appendChild(style)

    return () => {
      document.head.removeChild(style)
    }
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev < totalSlides - 1 ? prev + 1 : prev))
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev > 0 ? prev - 1 : prev))
  }

  const goToSlide = (index) => {
    setCurrentSlide(index)
  }

  // Función para compartir la presentación
  const sharePresentacion = () => {
    if (navigator.share) {
      navigator.share({
        title: "SolarMente - Presentación Corporativa",
        text: "Conoce más sobre SolarMente, líder en energía solar en Panamá",
        url: window.location.href,
      })
    } else {
      // Fallback para navegadores que no soportan Web Share API
      navigator.clipboard.writeText(window.location.href)
      alert("Enlace copiado al portapapeles")
    }
  }

  return (
    <div className="relative bg-gray-50 overflow-hidden">
      {/* Controles de navegación */}
      <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center items-center gap-2">
        <div className="bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full border border-gray-200 shadow-lg flex items-center gap-3">
          <button
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className={`p-2 rounded-full ${currentSlide === 0 ? "text-gray-400" : "text-gray-700 hover:bg-gray-100"}`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {[...Array(totalSlides)].map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2.5 h-2.5 rounded-full transition-all ${currentSlide === index ? "bg-[#ff6a00] w-4" : "bg-gray-300 hover:bg-gray-400"}`}
            />
          ))}

          <button
            onClick={nextSlide}
            disabled={currentSlide === totalSlides - 1}
            className={`p-2 rounded-full ${currentSlide === totalSlides - 1 ? "text-gray-400" : "text-gray-700 hover:bg-gray-100"}`}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Botones de acción */}
      <div className="fixed top-6 right-6 z-50 flex gap-2">
        <button
          onClick={sharePresentacion}
          className="bg-white/80 backdrop-blur-sm p-2 rounded-full border border-gray-200 shadow-lg text-gray-700 hover:bg-gray-100"
          title="Compartir presentación"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="18" cy="5" r="3"></circle>
            <circle cx="6" cy="12" r="3"></circle>
            <circle cx="18" cy="19" r="3"></circle>
            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
          </svg>
        </button>
        <Link
          href="/"
          className="bg-white/80 backdrop-blur-sm p-2 rounded-full border border-gray-200 shadow-lg text-gray-700 hover:bg-gray-100"
          title="Volver al inicio"
        >
          <Home className="w-5 h-5" />
        </Link>
      </div>

      {/* Contenedor de diapositivas */}
      <div
        className="transition-transform duration-700 ease-in-out"
        style={{ transform: `translateY(-${currentSlide * 100}vh)` }}
      >
        {/* Diapositiva 1: Portada */}
        <Slide className="bg-gradient-to-br from-white to-gray-100 relative">
          {/* Fondo de paneles solares con líneas animadas */}
          <SolarPanelBackground />

          <div
            className={`text-center max-w-4xl mx-auto transition-all duration-1000 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"} relative z-10`}
          >
            <div className="mb-6 inline-block bg-white/80 backdrop-blur-md px-4 py-1 rounded-full border border-[#ff6a00]/20">
              <span className="text-sm text-gray-700 flex items-center justify-center gap-2">
                <span className="w-2 h-2 bg-[#ff6a00] rounded-full"></span>
                Primera empresa solar en Panamá con IA
              </span>
            </div>

            <h1 className="text-5xl sm:text-7xl font-bold mb-4 tracking-tight text-gray-900">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h1>

            <h2 className="text-2xl sm:text-3xl mb-8 font-light text-gray-700">Presentación Corporativa</h2>

            <div className="flex justify-center mb-12">
              <div className="h-1 w-24 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full"></div>
            </div>

            <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
              Cambiando la forma de cotizar, comprar e instalar paneles solares con tecnología de Inteligencia
              Artificial
            </p>

            <div className="flex justify-center">
              <div className="animate-bounce bg-white p-2 w-10 h-10 ring-1 ring-gray-200 shadow-lg rounded-full flex items-center justify-center">
                <ChevronRight className="w-6 h-6 text-[#ff6a00]" />
              </div>
            </div>
          </div>
        </Slide>

        {/* Diapositiva 2: Resultados */}
        <Slide className="bg-white">
          <div className="w-full max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-2 text-gray-900">
              Resultados <span className="text-[#ff6a00]">Destacados</span>
            </h2>
            <div className="flex justify-center mb-12">
              <div className="h-1 w-24 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full"></div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
              <StatCard icon={Zap} value="30s" label="Propuesta IA" />
              <StatCard icon={DollarSign} value="100%" label="Ahorro Posible" />
              <StatCard icon={Home} value="180+" label="Instalaciones" />
              <StatCard icon={CalendarDays} value="12" label="Años Experiencia" />
            </div>

            <div className="bg-gray-50 rounded-xl p-8 border border-gray-200">
              <h3 className="text-2xl font-bold mb-6 text-gray-900">Impacto Ambiental</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg border border-gray-200 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sun className="h-6 w-6 text-green-600" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-1">2.5M kWh</h4>
                  <p className="text-sm text-gray-600">Energía limpia generada</p>
                </div>
                <div className="bg-white p-6 rounded-lg border border-gray-200 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="h-6 w-6 text-green-600" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-1">1,750 ton</h4>
                  <p className="text-sm text-gray-600">CO₂ evitado</p>
                </div>
                <div className="bg-white p-6 rounded-lg border border-gray-200 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-6 w-6 text-green-600" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-1">28,500</h4>
                  <p className="text-sm text-gray-600">Árboles equivalentes</p>
                </div>
              </div>
            </div>
          </div>
        </Slide>

        {/* Diapositiva 3: Proyectos Destacados */}
        <Slide className="bg-gray-50">
          <div className="w-full max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-2 text-gray-900">
              Proyectos <span className="text-[#ff6a00]">Destacados</span>
            </h2>
            <div className="flex justify-center mb-12">
              <div className="h-1 w-24 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <ProjectCard
                image="/images/38.jpg"
                title="Proyecto Comercial - DSV"
                capacity="218.36 kW"
                description="367 paneles solares de última generación con sistema de monitoreo en tiempo real."
              />
              <ProjectCard
                image="/images/14.jpg"
                title="Proyecto Comercial - SUNSAVE"
                capacity="98.28 kW"
                description="168 paneles solares de última generación con sistema de monitoreo en tiempo real."
              />
              <ProjectCard
                image="/images/DJI_0248.JPG"
                title="Proyecto Comercial - HOTEL LA CUBANA"
                capacity="87.75 kW"
                description="150 paneles solares con sistema de monitoreo inteligente vía app móvil."
              />
            </div>

            <div className="mt-12 text-center">
              <p className="text-gray-600 mb-6">
                Más de 180 instalaciones residenciales y comerciales respaldan nuestra experiencia.
              </p>
              <Link
                href="https://www.solarmente.io/proyectos"
                className="inline-flex items-center text-[#ff6a00] font-medium hover:text-[#ff9500] transition-colors"
              >
                Ver todos los proyectos
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          </div>
        </Slide>

        {/* Diapositiva 4: Marcas y Resultados */}
        <Slide className="bg-white">
          <div className="w-full max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-2 text-gray-900">
              Marcas de <span className="text-[#ff6a00]">Confianza</span>
            </h2>
            <div className="flex justify-center mb-12">
              <div className="h-1 w-24 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full"></div>
            </div>

            {/* Logos de marcas que usamos */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/logo-solis.png" alt="Logo Solis" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/sungrow-logo.png" alt="Logo Sungrow" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/apsystems-logo.png" alt="Logo APsystems" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/longi-logo.png" alt="Logo LONGi" className="max-h-16" />
              </div>
            </div>

            <h2 className="text-3xl md:text-4xl font-bold text-center mb-2 text-gray-900">
              Empresas que <span className="text-[#ff6a00]">Confían</span> en Nosotros
            </h2>
            <div className="flex justify-center mb-12">
              <div className="h-1 w-24 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full"></div>
            </div>

            {/* Logos de empresas donde hemos instalado - Primera fila */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/dsv.jpeg" alt="DSV Global Transport" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/sunsave.png" alt="Sunsave" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/reinadelmar.png" alt="Reina del Mar" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/panamamusic.jpeg" alt="Panama Music" className="max-h-16" />
              </div>
            </div>

            {/* Segunda fila de logos */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/play-motel.jpeg" alt="Play Love Motels" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/diocesis-chitre.png" alt="Diócesis de Chitré" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/panafarma.png" alt="Panafarma" className="max-h-16" />
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/autonitro.png" alt="Servicentro Autonitro" className="max-h-16" />
              </div>
            </div>

            {/* Tercera fila de logos */}
            <div className="grid grid-cols-1 md:grid-cols-1 gap-8 mb-16 max-w-xs mx-auto">
              <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-32">
                <img src="/images/panama-maritime.png" alt="Panama Maritime International" className="max-h-16" />
              </div>
            </div>

            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 text-gray-900">
              Este puede ser usted <span className="text-[#ff6a00]">ahorrando al 100%</span> y no pagar luz!
              <br />
              En SolarMente te <span className="text-[#ff6a00]">garantizamos</span> el ahorro.
            </h2>

            {/* Cards de facturas actualizadas con datos reales */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <BillCard
                title="Factura Antes"
                client="ALMACENADORA MERCANTIL, S.A."
                amount="B/. 543.75"
                date="12 de Marzo de 2025"
                nac="21197371"
                amountLabel="Se paga por demanda solamente. Consumo vino en $0"
                beforeAmount="B/. 3,442.97"
                afterAmount="B/. 543.75"
                consumptionHistory={almacenadoraHistory}
                pdfUrl="/pdfs/almacenadora.pdf"
              />

              <BillCard
                title="Factura Después"
                client="VALLADARES INTERNACIONAL, S.A."
                amount="B/. -1,098.32"
                date="31 de Marzo de 2025"
                nac="21439939"
                beforeAmount="B/. 2,016.16"
                afterAmount="B/. -1,098.32"
                consumptionHistory={valladaresHistory}
                pdfUrl="/pdfs/valladares.pdf"
              />

              <BillCard
                title="Ahorro Anual"
                client="G4 MANAGEMENT, S.A."
                amount="B/. -19.09"
                date="30 de Marzo de 2025"
                nac="21353226"
                beforeAmount="B/. 875.32"
                afterAmount="B/. -19.09"
                consumptionHistory={g4History}
                pdfUrl="/pdfs/g4.pdf"
              />
            </div>
          </div>
        </Slide>

        {/* Diapositiva 5: Contacto */}
        <Slide className="bg-white">
          <div className="w-full max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-2 text-gray-900">
              Contáctanos <span className="text-[#ff6a00]">Hoy</span>
            </h2>
            <div className="flex justify-center mb-12">
              <div className="h-1 w-24 bg-gradient-to-r from-[#ff6a00] to-[#ff9500] rounded-full"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-semibold mb-6 text-gray-900">
                  ¿Listo para cambiar a energía solar inteligente?
                </h3>
                <p className="text-gray-600 mb-8">
                  Solicita una cotización personalizada generada por IA y descubre cuánto puedes ahorrar con energía
                  solar.
                </p>

                <div className="flex justify-center mb-8">
                  <Link
                    href="https://www.solarmente.io/propuesta"
                    className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] py-3 px-6 text-white font-bold rounded-lg shadow-lg transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <Zap className="h-5 w-5" />
                    <span>Cotizador IA</span>
                  </Link>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-8 shadow-lg hover:shadow-xl transition-all duration-300 group relative overflow-hidden">
                <div className="flex flex-col items-center gap-6 relative z-10">
                  <h3 className="text-xl font-bold text-gray-900">Contáctanos</h3>

                  <div className="flex flex-col gap-4 w-full">
                    <a
                      href="https://wa.me/50764143255"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-lg transition-colors duration-300 flex items-center justify-center"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-2"
                      >
                        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                      </svg>
                      WhatsApp: +507 6414-3255
                    </a>

                    <a
                      href="mailto:ventas@solarmente.io"
                      className="bg-[#ff6a00] hover:bg-[#ff9500] text-white px-4 py-3 rounded-lg transition-colors duration-300 flex items-center justify-center"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-2"
                      >
                        <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                        <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                      </svg>
                      ventas@solarmente.io
                    </a>
                  </div>
                </div>

                <div className="mt-16 text-center text-sm text-gray-500">
                  <p>© 2025 SolarMente. Todos los derechos reservados.</p>
                  <p>Especialistas en energía solar con tecnología de Inteligencia Artificial.</p>
                </div>
              </div>
            </div>

            <div className="mt-16 text-center text-sm text-gray-500">
              <p>© 2025 SolarMente. Todos los derechos reservados.</p>
              <p>Especialistas en energía solar con tecnología de Inteligencia Artificial.</p>
            </div>
          </div>
        </Slide>
      </div>
    </div>
  )
}
