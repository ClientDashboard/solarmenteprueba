"use client"

import { Zap, DollarSign, Home, CalendarDays, ChevronDown } from "lucide-react"

{
  /* Stats con diseño minimalista como en la imagen */
}
;<div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-16">
  {/* Card 1 - Propuesta IA */}
  <div className="bg-white border border-gray-200 rounded-xl p-5 text-center relative overflow-hidden">
    {/* Fondo diagonal en tono melocotón claro */}
    <div className="absolute top-0 right-0 w-1/2 h-full bg-[#fff5f0] z-0"></div>

    <div className="mb-4 flex justify-center relative z-10">
      <div className="w-12 h-12 rounded-full bg-[#ff6a00] flex items-center justify-center">
        <Zap className="h-6 w-6 text-white" />
      </div>
    </div>

    <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1 relative z-10">30s</h3>
    <p className="text-sm text-gray-600 relative z-10">Propuesta IA</p>

    {/* Puntos decorativos */}
    <div className="absolute top-4 left-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
    <div className="absolute bottom-4 right-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
  </div>

  {/* Card 2 - Ahorro Posible */}
  <div className="bg-white border border-gray-200 rounded-xl p-5 text-center relative overflow-hidden">
    {/* Fondo diagonal en tono melocotón claro */}
    <div className="absolute top-0 right-0 w-1/2 h-full bg-[#fff5f0] z-0"></div>

    <div className="mb-4 flex justify-center relative z-10">
      <div className="w-12 h-12 rounded-full bg-[#ff6a00] flex items-center justify-center">
        <DollarSign className="h-6 w-6 text-white" />
      </div>
    </div>

    <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1 relative z-10">100%</h3>
    <p className="text-sm text-gray-600 relative z-10">Ahorro Posible</p>

    {/* Puntos decorativos */}
    <div className="absolute top-4 left-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
    <div className="absolute bottom-4 right-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
  </div>

  {/* Card 3 - Instalaciones */}
  <div className="bg-white border border-gray-200 rounded-xl p-5 text-center relative overflow-hidden">
    {/* Fondo diagonal en tono melocotón claro */}
    <div className="absolute top-0 right-0 w-1/2 h-full bg-[#fff5f0] z-0"></div>

    <div className="mb-4 flex justify-center relative z-10">
      <div className="w-12 h-12 rounded-full bg-[#ff6a00] flex items-center justify-center">
        <Home className="h-6 w-6 text-white" />
      </div>
    </div>

    <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1 relative z-10">180+</h3>
    <p className="text-sm text-gray-600 relative z-10">Instalaciones</p>

    {/* Puntos decorativos */}
    <div className="absolute top-4 left-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
    <div className="absolute bottom-4 right-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
  </div>

  {/* Card 4 - Años Experiencia */}
  <div className="bg-white border border-gray-200 rounded-xl p-5 text-center relative overflow-hidden">
    {/* Fondo diagonal en tono melocotón claro */}
    <div className="absolute top-0 right-0 w-1/2 h-full bg-[#fff5f0] z-0"></div>

    <div className="mb-4 flex justify-center relative z-10">
      <div className="w-12 h-12 rounded-full bg-[#ff6a00] flex items-center justify-center">
        <CalendarDays className="h-6 w-6 text-white" />
      </div>
    </div>

    <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1 relative z-10">12</h3>
    <p className="text-sm text-gray-600 relative z-10">Años Experiencia</p>

    {/* Puntos decorativos */}
    <div className="absolute top-4 left-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
    <div className="absolute bottom-4 right-4 w-1 h-1 bg-[#ff6a00]/30 rounded-full"></div>
  </div>
</div>

{
  /* Flecha circular separada de las tarjetas */
}
;<div className="flex justify-center mb-16">
  <div className="w-10 h-10 flex items-center justify-center text-gray-500 bg-white rounded-full border border-gray-200 shadow-sm">
    <ChevronDown className="w-5 h-5" />
  </div>
</div>

export default function HomeClient() {
  return <div>HomeClient</div>
}
