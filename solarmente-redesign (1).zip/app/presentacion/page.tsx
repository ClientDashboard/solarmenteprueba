import PresentacionClient from "@/components/presentacion-client"

export const metadata = {
  title: "SolarMente | Presentación Corporativa",
  description: "Resultados y proyectos destacados de SolarMente, líder en energía solar en Panamá",
  openGraph: {
    title: "SolarMente | Presentación Corporativa",
    description: "Resultados y proyectos destacados de SolarMente, líder en energía solar en Panamá",
    url: "https://presentacion-solarmente-3c2cp8dqv.vercel.app/presentacion",
    siteName: "SolarMente",
    images: [
      {
        url: "https://presentacion-solarmente-3c2cp8dqv.vercel.app/images/38.jpg",
        width: 1200,
        height: 630,
        alt: "SolarMente Presentación Corporativa",
      },
    ],
    locale: "es_PA",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SolarMente | Presentación Corporativa",
    description: "Resultados y proyectos destacados de SolarMente, líder en energía solar en Panamá",
    images: ["https://presentacion-solarmente-3c2cp8dqv.vercel.app/images/38.jpg"],
  },
}

export default function PresentacionPage() {
  return <PresentacionClient />
}
