import "./globals.css"
import "./presentacion/presentacion.css"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "SolarMente | Presentación Corporativa",
  description: "Resultados y proyectos destacados de SolarMente, líder en energía solar en Panamá",
  openGraph: {
    title: "SolarMente | Presentación Corporativa",
    description: "Resultados y proyectos destacados de SolarMente, líder en energía solar en Panamá",
    url: "https://presentacion-solarmente-3c2cp8dqv.vercel.app/",
    siteName: "SolarMente",
    images: [
      {
        url: "https://presentacion-solarmente-3c2cp8dqv.vercel.app/images/38.jpg",
        width: 1200,
        height: 630,
        alt: "SolarMente Presentación Corporativa",
      },
    ],
    locale: "es_PA",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SolarMente | Presentación Corporativa",
    description: "Resultados y proyectos destacados de SolarMente, líder en energía solar en Panamá",
    images: ["https://presentacion-solarmente-3c2cp8dqv.vercel.app/images/38.jpg"],
  },
    generator: 'v0.dev'
}

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}


import './globals.css'