import PropuestaCliente from "@/components/PropuestaCliente"

export default function Home() {
  return <PropuestaCliente />
}
