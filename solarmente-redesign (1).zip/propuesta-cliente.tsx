"use client"

import { useState } from "react"
import {
  Sun,
  Zap,
  DollarSign,
  BarChart3,
  Calendar,
  ArrowRight,
  CheckCircle2,
  FileText,
  ChevronDown,
  ChevronUp,
  Download,
  Phone,
  Mail,
  Clock,
  Shield,
} from "lucide-react"

export default function PropuestaCliente() {
  const [activeSection, setActiveSection] = useState("resumen")
  const [openAccordion, setOpenAccordion] = useState<string | null>("consumo")

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id)
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-[Mulish,sans-serif]">
      {/* Header con logo */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h1>
            <span className="ml-4 text-sm text-gray-500">Soluciones Energéticas Renovables</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 border border-gray-300 rounded-lg flex items-center gap-2 text-sm">
              <Download className="h-4 w-4" />
              Descargar PDF
            </button>
            <button className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-2 px-4 rounded-lg flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4" />
              Contactar
            </button>
          </div>
        </div>
      </header>

      {/* Portada */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-12 md:py-20">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6 inline-block bg-[#fff5f0] px-4 py-1 rounded-full">
              <span className="text-sm text-[#ff6a00] font-medium">PROPUESTA PERSONALIZADA</span>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
              Recomendación de Sistema Solar Fotovoltaico
            </h1>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <h2 className="text-lg font-medium text-gray-500 mb-2">CLIENTE</h2>
                <p className="text-2xl font-bold text-gray-900">ARCE AVICOLA S.A.</p>
              </div>
              <div>
                <h2 className="text-lg font-medium text-gray-500 mb-2">FECHA</h2>
                <p className="text-2xl font-bold text-gray-900">12 de abril de 2025</p>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 mb-8">
              <p className="text-gray-700 leading-relaxed">Estimado cliente:</p>
              <p className="text-gray-700 leading-relaxed mt-4">
                Hemos analizado detalladamente su factura eléctrica de ENSA correspondiente al mes de febrero de 2025, y
                queremos compartirle nuestra recomendación profesional sobre la solución solar que mejor se adapta a las
                necesidades energéticas de su empresa.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => setActiveSection("resumen")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === "resumen"
                    ? "bg-[#ff6a00] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Resumen Ejecutivo
              </button>
              <button
                onClick={() => setActiveSection("analisis")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === "analisis"
                    ? "bg-[#ff6a00] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Análisis de Consumo
              </button>
              <button
                onClick={() => setActiveSection("sistema")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === "sistema"
                    ? "bg-[#ff6a00] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Sistema Recomendado
              </button>
              <button
                onClick={() => setActiveSection("financiero")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === "financiero"
                    ? "bg-[#ff6a00] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Análisis Financiero
              </button>
              <button
                onClick={() => setActiveSection("pasos")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === "pasos" ? "bg-[#ff6a00] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Próximos Pasos
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Resumen Ejecutivo */}
          {activeSection === "resumen" && (
            <div className="animate-in fade-in duration-300">
              <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                Resumen Ejecutivo
              </h2>

              <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-[#fff5f0] p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <h3 className="font-semibold text-gray-900">Capacidad del Sistema</h3>
                    </div>
                    <p className="text-2xl font-bold text-[#ff6a00]">350 kWp</p>
                    <p className="text-sm text-gray-600">Sistema fotovoltaico</p>
                  </div>

                  <div className="bg-[#fff5f0] p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <h3 className="font-semibold text-gray-900">Ahorro Anual</h3>
                    </div>
                    <p className="text-2xl font-bold text-[#ff6a00]">B/. 41,916</p>
                    <p className="text-sm text-gray-600">Estimado primer año</p>
                  </div>

                  <div className="bg-[#fff5f0] p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <h3 className="font-semibold text-gray-900">Retorno de Inversión</h3>
                    </div>
                    <p className="text-2xl font-bold text-[#ff6a00]">4.2 años</p>
                    <p className="text-sm text-gray-600">ROI estimado</p>
                  </div>
                </div>

                <h3 className="text-lg font-semibold mb-4 text-gray-900">Puntos Clave</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>
                      Sistema dimensionado para su consumo máximo de <strong>158,448 kWh</strong> mensuales, optimizando
                      su inversión.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>
                      Aprovechamiento del programa de compensación por excedentes, vendiendo hasta un 25% de excedente a
                      B/. 0.08 por kWh.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>
                      Reducción significativa en el cargo por consumo de energía (B/. 3,493.03 en su factura actual).
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>
                      Mayor seguridad energética para su negocio y protección contra futuras alzas en las tarifas
                      eléctricas.
                    </span>
                  </li>
                </ul>

                <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Nota importante:</strong> El cargo por demanda (B/. 3,819.46 en su factura actual)
                    permanecerá, ya que este depende de la potencia instantánea utilizada y no del consumo total.
                  </p>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setActiveSection("analisis")}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                >
                  Ver Análisis de Consumo
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {/* Análisis de Consumo */}
          {activeSection === "analisis" && (
            <div className="animate-in fade-in duration-300">
              <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                <BarChart3 className="mr-2 h-6 w-6 text-[#ff6a00]" />
                Análisis de su Consumo Eléctrico
              </h2>

              <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                <p className="text-gray-700 mb-6">
                  Observamos que su patrón de consumo muestra una variabilidad estacional significativa, con:
                </p>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <div className="h-5 w-5 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-0.5"></div>
                    <span>Aproximadamente 6 meses de consumo elevado (picos de hasta 158,448 kWh)</span>
                  </li>
                  <li className="flex items-start">
                    <div className="h-5 w-5 rounded-full bg-[#ff9500] mr-2 flex-shrink-0 mt-0.5"></div>
                    <span>Aproximadamente 6 meses de consumo más reducido</span>
                  </li>
                </ul>

                <p className="text-gray-700 mb-6">
                  Este patrón es común en empresas como la suya y representa una oportunidad importante para optimizar
                  su inversión en energía solar.
                </p>

                <div className="mb-8">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">Consumo Mensual (kWh)</h3>
                  <div className="bg-gray-50 p-4 rounded-lg overflow-hidden">
                    <div className="h-64 relative">
                      {/* Simulación de gráfico de barras */}
                      <div className="absolute bottom-0 left-0 w-full h-full flex items-end justify-between px-2">
                        {[158448, 145000, 138000, 92000, 85000, 78000, 75000, 82000, 90000, 130000, 142000, 155000].map(
                          (value, index) => (
                            <div key={index} className="w-[7%] relative group">
                              <div
                                className={`${index < 6 ? "bg-[#ff6a00]" : "bg-[#ff9500]"} rounded-t-sm transition-all duration-300 group-hover:opacity-80`}
                                style={{ height: `${(value / 160000) * 100}%` }}
                              ></div>
                              <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                {value.toLocaleString()} kWh
                              </div>
                            </div>
                          ),
                        )}
                      </div>

                      {/* Líneas de referencia */}
                      <div className="absolute bottom-0 left-0 w-full h-full flex flex-col justify-between pointer-events-none">
                        <div className="border-b border-gray-200 relative h-0">
                          <span className="absolute -top-3 -left-14 text-xs text-gray-500">160,000</span>
                        </div>
                        <div className="border-b border-gray-200 relative h-0">
                          <span className="absolute -top-3 -left-14 text-xs text-gray-500">120,000</span>
                        </div>
                        <div className="border-b border-gray-200 relative h-0">
                          <span className="absolute -top-3 -left-14 text-xs text-gray-500">80,000</span>
                        </div>
                        <div className="border-b border-gray-200 relative h-0">
                          <span className="absolute -top-3 -left-14 text-xs text-gray-500">40,000</span>
                        </div>
                        <div className="border-b border-gray-200 relative h-0">
                          <span className="absolute -top-3 -left-14 text-xs text-gray-500">0</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between mt-2 px-2">
                      {["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"].map(
                        (month, index) => (
                          <div key={index} className="text-xs text-gray-500 w-[7%] text-center">
                            {month}
                          </div>
                        ),
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-[#fff5f0] p-4 rounded-lg mb-6">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">Detalles de su Factura Actual</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Cargo por consumo:</p>
                      <p className="text-lg font-bold text-gray-900">B/. 3,493.03</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Cargo por demanda:</p>
                      <p className="text-lg font-bold text-gray-900">B/. 3,819.46</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Nota importante:</strong> El cargo por demanda permanecerá, ya que este depende de la
                    potencia instantánea utilizada y no del consumo total. Los paneles solares reducirán principalmente
                    el cargo por consumo de energía.
                  </p>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setActiveSection("sistema")}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                >
                  Ver Sistema Recomendado
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {/* Sistema Recomendado */}
          {activeSection === "sistema" && (
            <div className="animate-in fade-in duration-300">
              <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                <Sun className="mr-2 h-6 w-6 text-[#ff6a00]" />
                Sistema Recomendado
              </h2>

              <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                <h3 className="text-lg font-semibold mb-4 text-gray-900">Nuestra Recomendación</h3>
                <p className="text-gray-700 mb-6">
                  Después de evaluar cuidadosamente sus datos de consumo, recomendamos un sistema solar dimensionado
                  para su consumo máximo en lugar de un sistema basado en el promedio anual.
                </p>

                <div className="mb-8">
                  <button
                    className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                    onClick={() => toggleAccordion("consumo")}
                  >
                    <div className="flex items-center">
                      <Zap className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <span className="font-medium text-gray-900">Maximización de ahorros durante todo el año</span>
                    </div>
                    {openAccordion === "consumo" ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>

                  {openAccordion === "consumo" && (
                    <div className="p-4 border-t border-gray-100">
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>
                            Durante los meses de alto consumo, su sistema cubrirá la mayor parte de sus necesidades
                            energéticas.
                          </span>
                        </li>
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>En los meses de menor consumo, generará excedentes que serán aprovechados.</span>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>

                <div className="mb-8">
                  <button
                    className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                    onClick={() => toggleAccordion("excedentes")}
                  >
                    <div className="flex items-center">
                      <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <span className="font-medium text-gray-900">
                        Aprovechamiento del programa de compensación por excedentes
                      </span>
                    </div>
                    {openAccordion === "excedentes" ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>

                  {openAccordion === "excedentes" && (
                    <div className="p-4 border-t border-gray-100">
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>
                            En Panamá, puede vender a la red hasta un 25% de excedente de energía a B/. 0.08 por kWh.
                          </span>
                        </li>
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>
                            Los excedentes generados durante los meses de menor consumo se convertirán en créditos en su
                            factura.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>

                <div className="mb-8">
                  <button
                    className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                    onClick={() => toggleAccordion("seguridad")}
                  >
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <span className="font-medium text-gray-900">Mayor seguridad energética para su negocio</span>
                    </div>
                    {openAccordion === "seguridad" ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>

                  {openAccordion === "seguridad" && (
                    <div className="p-4 border-t border-gray-100">
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>Un sistema más grande garantiza mayor independencia de la red eléctrica.</span>
                        </li>
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>Protección contra futuras alzas en las tarifas eléctricas de ENSA.</span>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>

                <div className="mb-8">
                  <button
                    className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                    onClick={() => toggleAccordion("roi")}
                  >
                    <div className="flex items-center">
                      <BarChart3 className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <span className="font-medium text-gray-900">Optimización del retorno de inversión</span>
                    </div>
                    {openAccordion === "roi" ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>

                  {openAccordion === "roi" && (
                    <div className="p-4 border-t border-gray-100">
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>
                            El programa de compensación por excedentes mejora significativamente el tiempo de
                            recuperación de su inversión.
                          </span>
                        </li>
                        <li className="flex items-start">
                          <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                          <span>
                            La venta de excedentes convierte lo que podría ser capacidad subutilizada en ingresos
                            adicionales.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">Especificaciones del Sistema</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-gray-700 mb-2">Componentes Principales</h4>
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            <strong>700 paneles</strong> solares de 500W (Tier 1)
                          </span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            <strong>5 inversores</strong> trifásicos de 70kW
                          </span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Sistema de monitoreo en tiempo real</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Estructura de montaje en aluminio anodizado</span>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium text-gray-700 mb-2">Características Técnicas</h4>
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            Capacidad total: <strong>350 kWp</strong>
                          </span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            Generación anual estimada: <strong>560,000 kWh</strong>
                          </span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            Área requerida: <strong>~2,100 m²</strong>
                          </span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle2 className="h-4 w-4 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            Garantía de paneles: <strong>25 años</strong>
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setActiveSection("financiero")}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                >
                  Ver Análisis Financiero
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {/* Análisis Financiero */}
          {activeSection === "financiero" && (
            <div className="animate-in fade-in duration-300">
              <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                <DollarSign className="mr-2 h-6 w-6 text-[#ff6a00]" />
                Análisis Financiero
              </h2>

              <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-[#fff5f0] p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <h3 className="font-semibold text-gray-900">Inversión Total</h3>
                    </div>
                    <p className="text-2xl font-bold text-[#ff6a00]">B/. 175,000</p>
                    <p className="text-sm text-gray-600">Sistema completo instalado</p>
                  </div>

                  <div className="bg-[#fff5f0] p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <DollarSign className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <h3 className="font-semibold text-gray-900">Ahorro Anual</h3>
                    </div>
                    <p className="text-2xl font-bold text-[#ff6a00]">B/. 41,916</p>
                    <p className="text-sm text-gray-600">Estimado primer año</p>
                  </div>

                  <div className="bg-[#fff5f0] p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Calendar className="h-5 w-5 text-[#ff6a00] mr-2" />
                      <h3 className="font-semibold text-gray-900">Retorno de Inversión</h3>
                    </div>
                    <p className="text-2xl font-bold text-[#ff6a00]">4.2 años</p>
                    <p className="text-sm text-gray-600">ROI estimado</p>
                  </div>
                </div>

                <h3 className="text-lg font-semibold mb-4 text-gray-900">Proyección Financiera a 25 Años</h3>

                <div className="overflow-x-auto mb-6">
                  <table className="min-w-full bg-white">
                    <thead>
                      <tr className="bg-gray-50 text-gray-700">
                        <th className="py-2 px-3 text-left text-sm font-medium">Año</th>
                        <th className="py-2 px-3 text-right text-sm font-medium">Ahorro Anual</th>
                        <th className="py-2 px-3 text-right text-sm font-medium">Ahorro Acumulado</th>
                        <th className="py-2 px-3 text-right text-sm font-medium">ROI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">1</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 41,916</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 41,916</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">24%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">2</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 43,173</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 85,089</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">49%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">3</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 44,469</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 129,558</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">74%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">4</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 45,803</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 175,361</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">100%</td>
                      </tr>
                      <tr className="bg-green-50">
                        <td className="py-2 px-3 text-sm font-medium text-green-800">5</td>
                        <td className="py-2 px-3 text-sm font-medium text-green-800 text-right">B/. 47,177</td>
                        <td className="py-2 px-3 text-sm font-medium text-green-800 text-right">B/. 222,538</td>
                        <td className="py-2 px-3 text-sm font-medium text-green-800 text-right">127%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">10</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 54,685</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 487,538</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">279%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">15</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 63,380</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 798,538</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">456%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">20</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 73,440</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 1,165,538</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">666%</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 text-sm text-gray-700">25</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 85,110</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">B/. 1,598,538</td>
                        <td className="py-2 px-3 text-sm text-gray-700 text-right">914%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">Supuestos del Análisis</h3>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start">
                      <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                      <span>Incremento anual del 3% en el costo de la electricidad</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                      <span>Degradación anual de los paneles del 0.5%</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-2 w-2 rounded-full bg-[#ff6a00] mr-2 flex-shrink-0 mt-2"></div>
                      <span>Mantenimiento anual incluido en la proyección</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-[#fff5f0] p-4 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">Beneficios Adicionales</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                      <span>
                        Reducción de la huella de carbono: <strong>~280 toneladas de CO₂</strong> al año
                      </span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                      <span>Mejora de la imagen corporativa como empresa comprometida con el medio ambiente</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-[#ff6a00] mr-2 flex-shrink-0 mt-0.5" />
                      <span>Protección contra la volatilidad de los precios de la energía</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setActiveSection("pasos")}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                >
                  Ver Próximos Pasos
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {/* Próximos Pasos */}
          {activeSection === "pasos" && (
            <div className="animate-in fade-in duration-300">
              <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                <ArrowRight className="mr-2 h-6 w-6 text-[#ff6a00]" />
                Próximos Pasos
              </h2>

              <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
                <div className="relative">
                  <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>

                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 top-1 w-8 h-8 rounded-full bg-[#ff6a00] flex items-center justify-center text-white font-bold">
                      1
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-900">Visita Técnica</h3>
                    <p className="text-gray-700 mb-2">
                      Realizaremos una visita a sus instalaciones para evaluar el espacio disponible, verificar la
                      estructura del techo y confirmar los detalles técnicos.
                    </p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Duración estimada: 1-2 horas</span>
                    </div>
                  </div>

                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 top-1 w-8 h-8 rounded-full bg-[#ff6a00] flex items-center justify-center text-white font-bold">
                      2
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-900">Propuesta Detallada</h3>
                    <p className="text-gray-700 mb-2">
                      Basándonos en la visita técnica, elaboraremos una propuesta detallada con planos, especificaciones
                      exactas y cronograma de instalación.
                    </p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Tiempo de entrega: 3-5 días hábiles</span>
                    </div>
                  </div>

                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 top-1 w-8 h-8 rounded-full bg-[#ff6a00] flex items-center justify-center text-white font-bold">
                      3
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-900">Firma de Contrato</h3>
                    <p className="text-gray-700 mb-2">
                      Una vez aprobada la propuesta, procederemos a la firma del contrato y estableceremos el calendario
                      de pagos.
                    </p>
                    <div className="flex items-center text-sm text-gray-500">
                      <FileText className="h-4 w-4 mr-1" />
                      <span>Documentos necesarios: RUC, cédula del representante legal, recibo de luz</span>
                    </div>
                  </div>

                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 top-1 w-8 h-8 rounded-full bg-[#ff6a00] flex items-center justify-center text-white font-bold">
                      4
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-900">Instalación</h3>
                    <p className="text-gray-700 mb-2">
                      Nuestro equipo técnico realizará la instalación completa del sistema, minimizando cualquier
                      interrupción en sus operaciones.
                    </p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Tiempo estimado: 3-4 semanas</span>
                    </div>
                  </div>

                  <div className="relative pl-12">
                    <div className="absolute left-0 top-1 w-8 h-8 rounded-full bg-[#ff6a00] flex items-center justify-center text-white font-bold">
                      5
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-900">Puesta en Marcha y Capacitación</h3>
                    <p className="text-gray-700 mb-2">
                      Realizaremos la conexión final, pruebas de funcionamiento y le capacitaremos en el uso del sistema
                      de monitoreo.
                    </p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Duración: 1 día</span>
                    </div>
                  </div>
                </div>

                <div className="mt-12 p-6 bg-[#fff5f0] rounded-lg">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">¿Listo para dar el siguiente paso?</h3>
                  <p className="text-gray-700 mb-6">
                    Estamos a su disposición para resolver cualquier duda adicional y coordinar la visita técnica en la
                    fecha que mejor le convenga.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <div className="flex items-center mb-2">
                        <Phone className="h-5 w-5 text-[#ff6a00] mr-2" />
                        <h4 className="font-medium text-gray-900">Llámenos</h4>
                      </div>
                      <p className="text-gray-700">(+507) 6414-3255</p>
                      <p className="text-gray-700">(+507) 236-3255</p>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <div className="flex items-center mb-2">
                        <Mail className="h-5 w-5 text-[#ff6a00] mr-2" />
                        <h4 className="font-medium text-gray-900">Escríbanos</h4>
                      </div>
                      <p className="text-gray-700">ventas@solarmente.io</p>
                      <p className="text-gray-700">info@solarmente.io</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setActiveSection("resumen")}
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff9500] hover:from-[#ff7b00] hover:to-[#ffa700] text-white font-medium py-3 px-6 rounded-lg flex items-center gap-2"
                >
                  Volver al Resumen
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-xl font-bold mb-4">
              Solar<span className="text-[#ff6a00]">Mente</span>
              <span className="text-[#ff6a00] font-light">.AI</span>
            </h2>
            <p className="text-gray-600 mb-6">Soluciones Energéticas Renovables con Inteligencia Artificial</p>
            <div className="flex justify-center space-x-4 mb-6">
              <a href="#" className="text-gray-500 hover:text-[#ff6a00] transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a href="#" className="text-gray-500 hover:text-[#ff6a00] transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </a>
              <a href="#" className="text-gray-500 hover:text-[#ff6a00] transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </a>
            </div>
            <p className="text-sm text-gray-500">© 2025 SolarMente. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
